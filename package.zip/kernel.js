(function() {
  "use strict";
  const success = (data) => ({
    code: 200,
    message: "success",
    data: data === void 0 ? null : data
  });
  const failure = (message, code = 500, data = null) => ({
    code,
    message: message || "error",
    data
  });
  const jsonResponse = (payload, statusCode = 200) => ({
    statusCode,
    headers: {
      "Content-Type": ["application/json; charset=utf-8"]
    },
    body: {
      data: {
        type: "JSON",
        data: payload
      }
    }
  });
  const textResponse = (text, statusCode = 200, contentType = "text/plain; charset=utf-8") => ({
    statusCode,
    headers: {
      "Content-Type": [contentType]
    },
    body: {
      string: {
        format: "%s",
        values: [String(text || "")]
      }
    }
  });
  const proxyResponse = (url, headers = {}, method = "") => {
    const normalizedHeaders = {};
    for (const [key, value] of Object.entries(headers || {})) {
      if (value === void 0 || value === null || value === "") continue;
      normalizedHeaders[key] = Array.isArray(value) ? value.map(String) : [String(value)];
    }
    const proxy = {
      url,
      headers: normalizedHeaders
    };
    if (method) proxy.method = method;
    return {
      statusCode: 200,
      headers: {},
      body: { proxy }
    };
  };
  const PRIVATE_BASE = "/plugin/private/siyuan-media-player";
  const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
  const BILI_HEADERS = {
    "User-Agent": USER_AGENT,
    Referer: "https://www.bilibili.com/",
    Origin: "https://www.bilibili.com"
  };
  const BILI_CDN_HEADERS = {
    "User-Agent": USER_AGENT,
    Referer: "https://www.bilibili.com/",
    "Accept-Encoding": "identity"
  };
  const API = {
    www: "https://www.bilibili.com",
    nav: "https://api.bilibili.com/x/web-interface/nav",
    qrLogin: "https://passport.bilibili.com/x/passport-login/web/qrcode/generate",
    qrPoll: "https://passport.bilibili.com/x/passport-login/web/qrcode/poll",
    view: "https://api.bilibili.com/x/web-interface/view",
    playUrl: "https://api.bilibili.com/x/player/wbi/playurl",
    playerInfo: "https://api.bilibili.com/x/player/wbi/v2",
    aiSummary: "https://api.bilibili.com/x/web-interface/view/conclusion/get",
    commentXml: "https://comment.bilibili.com/{cid}.xml",
    popular: "https://api.bilibili.com/x/web-interface/popular",
    recommend: "https://api.bilibili.com/x/web-interface/wbi/index/top/feed/rcmd",
    regionLatest: "https://api.bilibili.com/x/web-interface/dynamic/region",
    related: "https://api.bilibili.com/x/web-interface/archive/related",
    pgcSeason: "https://api.bilibili.com/pgc/view/web/season",
    pgcPlayUrl: "https://api.bilibili.com/pgc/player/web/playurl",
    pgcFollowList: "https://api.bilibili.com/pgc/web/follow/list",
    pgcBangumiPage: "https://api.bilibili.com/pgc/season/index/result",
    pgcCinemaPage: "https://api.bilibili.com/pgc/season/index/result",
    dynamicAllVideo: "https://api.bilibili.com/x/polymer/web-dynamic/v1/feed/all",
    spaceArcSearch: "https://api.bilibili.com/x/space/wbi/arc/search",
    historyCursor: "https://api.bilibili.com/x/web-interface/history/cursor",
    toView: "https://api.bilibili.com/x/v2/history/toview/web",
    likeVideo: "https://api.bilibili.com/x/space/like/video",
    relationStat: "https://api.bilibili.com/x/relation/stat",
    upStat: "https://api.bilibili.com/x/space/upstat",
    favFolders: "https://api.bilibili.com/x/v3/fav/folder/created/list-all",
    favResources: "https://api.bilibili.com/x/v3/fav/resource/list",
    favResourceDeal: "https://api.bilibili.com/x/v3/fav/resource/deal",
    searchTypeWbi: "https://api.bilibili.com/x/web-interface/wbi/search/type",
    searchType: "https://api.bilibili.com/x/web-interface/search/type",
    searchSuggest: "https://s.search.bilibili.com/main/suggest",
    searchHotword: "https://s.search.bilibili.com/main/hotword",
    socialLike: "https://api.bilibili.com/x/web-interface/archive/like",
    socialCoinState: "https://api.bilibili.com/x/web-interface/archive/coins",
    socialCoin: "https://api.bilibili.com/x/web-interface/coin/add",
    reply: "https://api.bilibili.com/x/v2/reply",
    replyReplies: "https://api.bilibili.com/x/v2/reply/reply",
    liveAreaList: "https://api.live.bilibili.com/xlive/web-interface/v1/index/getWebAreaList",
    liveAreaRooms: "https://api.live.bilibili.com/xlive/web-interface/v1/second/getList",
    liveFollowing: "https://api.live.bilibili.com/xlive/web-ucenter/user/following",
    liveRecommendIndex: "https://api.live.bilibili.com/xlive/web-interface/v1/webMain/getList",
    liveRecommendMore: "https://api.live.bilibili.com/xlive/web-interface/v1/webMain/getMoreRecList",
    liveRoomInfo: "https://api.live.bilibili.com/xlive/web-room/v1/index/getInfoByRoom",
    livePlayInfo: "https://api.live.bilibili.com/xlive/web-room/v2/index/getRoomPlayInfo"
  };
  const now$2 = () => Date.now();
  const withQuery = (url, params = {}) => {
    const target = new URL(url);
    for (const [key, value] of Object.entries(params)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    return target.toString();
  };
  const buildHeaders = (cookie = "", headers = {}) => ({
    ...BILI_HEADERS,
    ...headers,
    ...cookie ? { Cookie: cookie } : {}
  });
  const stripHtmlTags = (value = "") => String(value || "").replace(/<[^>]+>/g, "").replace(/&quot;/g, '"').replace(/&amp;/g, "&").trim();
  const parseDuration = (value = "") => String(value || "").split(":").reduce((acc, part) => acc * 60 + (parseInt(part, 10) || 0), 0);
  const cookieValue = (cookie = "", name = "") => {
    var _a;
    const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return decodeURIComponent(((_a = String(cookie || "").match(new RegExp(`(?:^|;\\s*)${escaped}=([^;]*)`))) == null ? void 0 : _a[1]) || "");
  };
  const csrfOf = (cookie = "") => cookieValue(cookie, "bili_jct");
  const currentUid = (cookie = "", fallback = "") => cookieValue(cookie, "DedeUserID") || fallback || "";
  const ensureCookie = (payload) => {
    const cookie = String((payload == null ? void 0 : payload.cookie) || "").trim();
    if (!cookie) throw new Error("missing bilibili cookie");
    return cookie;
  };
  const formBody = (data = {}) => new URLSearchParams(Object.entries(data).filter(([, value]) => value !== void 0 && value !== null).map(([key, value]) => [key, String(value)])).toString();
  const checkApiResponse = (json, message) => {
    if (!json || json.code !== 0) throw new Error(`${message}: ${(json == null ? void 0 : json.message) || (json == null ? void 0 : json.msg) || (json == null ? void 0 : json.code) || "unknown"}`);
  };
  function getDefaultExportFromCjs(x) {
    return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
  }
  var browser = {};
  var canPromise$1 = function() {
    return typeof Promise === "function" && Promise.prototype && Promise.prototype.then;
  };
  var qrcode = {};
  var utils$1 = {};
  let toSJISFunction;
  const CODEWORDS_COUNT = [
    0,
    // Not used
    26,
    44,
    70,
    100,
    134,
    172,
    196,
    242,
    292,
    346,
    404,
    466,
    532,
    581,
    655,
    733,
    815,
    901,
    991,
    1085,
    1156,
    1258,
    1364,
    1474,
    1588,
    1706,
    1828,
    1921,
    2051,
    2185,
    2323,
    2465,
    2611,
    2761,
    2876,
    3034,
    3196,
    3362,
    3532,
    3706
  ];
  utils$1.getSymbolSize = function getSymbolSize2(version2) {
    if (!version2) throw new Error('"version" cannot be null or undefined');
    if (version2 < 1 || version2 > 40) throw new Error('"version" should be in range from 1 to 40');
    return version2 * 4 + 17;
  };
  utils$1.getSymbolTotalCodewords = function getSymbolTotalCodewords(version2) {
    return CODEWORDS_COUNT[version2];
  };
  utils$1.getBCHDigit = function(data) {
    let digit = 0;
    while (data !== 0) {
      digit++;
      data >>>= 1;
    }
    return digit;
  };
  utils$1.setToSJISFunction = function setToSJISFunction(f) {
    if (typeof f !== "function") {
      throw new Error('"toSJISFunc" is not a valid function.');
    }
    toSJISFunction = f;
  };
  utils$1.isKanjiModeEnabled = function() {
    return typeof toSJISFunction !== "undefined";
  };
  utils$1.toSJIS = function toSJIS(kanji2) {
    return toSJISFunction(kanji2);
  };
  var errorCorrectionLevel = {};
  (function(exports) {
    exports.L = { bit: 1 };
    exports.M = { bit: 0 };
    exports.Q = { bit: 3 };
    exports.H = { bit: 2 };
    function fromString(string) {
      if (typeof string !== "string") {
        throw new Error("Param is not a string");
      }
      const lcStr = string.toLowerCase();
      switch (lcStr) {
        case "l":
        case "low":
          return exports.L;
        case "m":
        case "medium":
          return exports.M;
        case "q":
        case "quartile":
          return exports.Q;
        case "h":
        case "high":
          return exports.H;
        default:
          throw new Error("Unknown EC Level: " + string);
      }
    }
    exports.isValid = function isValid(level) {
      return level && typeof level.bit !== "undefined" && level.bit >= 0 && level.bit < 4;
    };
    exports.from = function from(value, defaultValue) {
      if (exports.isValid(value)) {
        return value;
      }
      try {
        return fromString(value);
      } catch (e) {
        return defaultValue;
      }
    };
  })(errorCorrectionLevel);
  function BitBuffer$1() {
    this.buffer = [];
    this.length = 0;
  }
  BitBuffer$1.prototype = {
    get: function(index) {
      const bufIndex = Math.floor(index / 8);
      return (this.buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
    },
    put: function(num, length) {
      for (let i = 0; i < length; i++) {
        this.putBit((num >>> length - i - 1 & 1) === 1);
      }
    },
    getLengthInBits: function() {
      return this.length;
    },
    putBit: function(bit) {
      const bufIndex = Math.floor(this.length / 8);
      if (this.buffer.length <= bufIndex) {
        this.buffer.push(0);
      }
      if (bit) {
        this.buffer[bufIndex] |= 128 >>> this.length % 8;
      }
      this.length++;
    }
  };
  var bitBuffer = BitBuffer$1;
  function BitMatrix$1(size) {
    if (!size || size < 1) {
      throw new Error("BitMatrix size must be defined and greater than 0");
    }
    this.size = size;
    this.data = new Uint8Array(size * size);
    this.reservedBit = new Uint8Array(size * size);
  }
  BitMatrix$1.prototype.set = function(row, col, value, reserved) {
    const index = row * this.size + col;
    this.data[index] = value;
    if (reserved) this.reservedBit[index] = true;
  };
  BitMatrix$1.prototype.get = function(row, col) {
    return this.data[row * this.size + col];
  };
  BitMatrix$1.prototype.xor = function(row, col, value) {
    this.data[row * this.size + col] ^= value;
  };
  BitMatrix$1.prototype.isReserved = function(row, col) {
    return this.reservedBit[row * this.size + col];
  };
  var bitMatrix = BitMatrix$1;
  var alignmentPattern = {};
  (function(exports) {
    const getSymbolSize2 = utils$1.getSymbolSize;
    exports.getRowColCoords = function getRowColCoords(version2) {
      if (version2 === 1) return [];
      const posCount = Math.floor(version2 / 7) + 2;
      const size = getSymbolSize2(version2);
      const intervals = size === 145 ? 26 : Math.ceil((size - 13) / (2 * posCount - 2)) * 2;
      const positions = [size - 7];
      for (let i = 1; i < posCount - 1; i++) {
        positions[i] = positions[i - 1] - intervals;
      }
      positions.push(6);
      return positions.reverse();
    };
    exports.getPositions = function getPositions(version2) {
      const coords = [];
      const pos = exports.getRowColCoords(version2);
      const posLength = pos.length;
      for (let i = 0; i < posLength; i++) {
        for (let j = 0; j < posLength; j++) {
          if (i === 0 && j === 0 || // top-left
          i === 0 && j === posLength - 1 || // bottom-left
          i === posLength - 1 && j === 0) {
            continue;
          }
          coords.push([pos[i], pos[j]]);
        }
      }
      return coords;
    };
  })(alignmentPattern);
  var finderPattern = {};
  const getSymbolSize = utils$1.getSymbolSize;
  const FINDER_PATTERN_SIZE = 7;
  finderPattern.getPositions = function getPositions(version2) {
    const size = getSymbolSize(version2);
    return [
      // top-left
      [0, 0],
      // top-right
      [size - FINDER_PATTERN_SIZE, 0],
      // bottom-left
      [0, size - FINDER_PATTERN_SIZE]
    ];
  };
  var maskPattern = {};
  (function(exports) {
    exports.Patterns = {
      PATTERN000: 0,
      PATTERN001: 1,
      PATTERN010: 2,
      PATTERN011: 3,
      PATTERN100: 4,
      PATTERN101: 5,
      PATTERN110: 6,
      PATTERN111: 7
    };
    const PenaltyScores = {
      N1: 3,
      N2: 3,
      N3: 40,
      N4: 10
    };
    exports.isValid = function isValid(mask) {
      return mask != null && mask !== "" && !isNaN(mask) && mask >= 0 && mask <= 7;
    };
    exports.from = function from(value) {
      return exports.isValid(value) ? parseInt(value, 10) : void 0;
    };
    exports.getPenaltyN1 = function getPenaltyN1(data) {
      const size = data.size;
      let points = 0;
      let sameCountCol = 0;
      let sameCountRow = 0;
      let lastCol = null;
      let lastRow = null;
      for (let row = 0; row < size; row++) {
        sameCountCol = sameCountRow = 0;
        lastCol = lastRow = null;
        for (let col = 0; col < size; col++) {
          let module = data.get(row, col);
          if (module === lastCol) {
            sameCountCol++;
          } else {
            if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
            lastCol = module;
            sameCountCol = 1;
          }
          module = data.get(col, row);
          if (module === lastRow) {
            sameCountRow++;
          } else {
            if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
            lastRow = module;
            sameCountRow = 1;
          }
        }
        if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
        if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
      }
      return points;
    };
    exports.getPenaltyN2 = function getPenaltyN2(data) {
      const size = data.size;
      let points = 0;
      for (let row = 0; row < size - 1; row++) {
        for (let col = 0; col < size - 1; col++) {
          const last = data.get(row, col) + data.get(row, col + 1) + data.get(row + 1, col) + data.get(row + 1, col + 1);
          if (last === 4 || last === 0) points++;
        }
      }
      return points * PenaltyScores.N2;
    };
    exports.getPenaltyN3 = function getPenaltyN3(data) {
      const size = data.size;
      let points = 0;
      let bitsCol = 0;
      let bitsRow = 0;
      for (let row = 0; row < size; row++) {
        bitsCol = bitsRow = 0;
        for (let col = 0; col < size; col++) {
          bitsCol = bitsCol << 1 & 2047 | data.get(row, col);
          if (col >= 10 && (bitsCol === 1488 || bitsCol === 93)) points++;
          bitsRow = bitsRow << 1 & 2047 | data.get(col, row);
          if (col >= 10 && (bitsRow === 1488 || bitsRow === 93)) points++;
        }
      }
      return points * PenaltyScores.N3;
    };
    exports.getPenaltyN4 = function getPenaltyN4(data) {
      let darkCount = 0;
      const modulesCount = data.data.length;
      for (let i = 0; i < modulesCount; i++) darkCount += data.data[i];
      const k = Math.abs(Math.ceil(darkCount * 100 / modulesCount / 5) - 10);
      return k * PenaltyScores.N4;
    };
    function getMaskAt(maskPattern2, i, j) {
      switch (maskPattern2) {
        case exports.Patterns.PATTERN000:
          return (i + j) % 2 === 0;
        case exports.Patterns.PATTERN001:
          return i % 2 === 0;
        case exports.Patterns.PATTERN010:
          return j % 3 === 0;
        case exports.Patterns.PATTERN011:
          return (i + j) % 3 === 0;
        case exports.Patterns.PATTERN100:
          return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
        case exports.Patterns.PATTERN101:
          return i * j % 2 + i * j % 3 === 0;
        case exports.Patterns.PATTERN110:
          return (i * j % 2 + i * j % 3) % 2 === 0;
        case exports.Patterns.PATTERN111:
          return (i * j % 3 + (i + j) % 2) % 2 === 0;
        default:
          throw new Error("bad maskPattern:" + maskPattern2);
      }
    }
    exports.applyMask = function applyMask(pattern, data) {
      const size = data.size;
      for (let col = 0; col < size; col++) {
        for (let row = 0; row < size; row++) {
          if (data.isReserved(row, col)) continue;
          data.xor(row, col, getMaskAt(pattern, row, col));
        }
      }
    };
    exports.getBestMask = function getBestMask(data, setupFormatFunc) {
      const numPatterns = Object.keys(exports.Patterns).length;
      let bestPattern = 0;
      let lowerPenalty = Infinity;
      for (let p = 0; p < numPatterns; p++) {
        setupFormatFunc(p);
        exports.applyMask(p, data);
        const penalty = exports.getPenaltyN1(data) + exports.getPenaltyN2(data) + exports.getPenaltyN3(data) + exports.getPenaltyN4(data);
        exports.applyMask(p, data);
        if (penalty < lowerPenalty) {
          lowerPenalty = penalty;
          bestPattern = p;
        }
      }
      return bestPattern;
    };
  })(maskPattern);
  var errorCorrectionCode = {};
  const ECLevel$1 = errorCorrectionLevel;
  const EC_BLOCKS_TABLE = [
    // L  M  Q  H
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    2,
    1,
    2,
    2,
    4,
    1,
    2,
    4,
    4,
    2,
    4,
    4,
    4,
    2,
    4,
    6,
    5,
    2,
    4,
    6,
    6,
    2,
    5,
    8,
    8,
    4,
    5,
    8,
    8,
    4,
    5,
    8,
    11,
    4,
    8,
    10,
    11,
    4,
    9,
    12,
    16,
    4,
    9,
    16,
    16,
    6,
    10,
    12,
    18,
    6,
    10,
    17,
    16,
    6,
    11,
    16,
    19,
    6,
    13,
    18,
    21,
    7,
    14,
    21,
    25,
    8,
    16,
    20,
    25,
    8,
    17,
    23,
    25,
    9,
    17,
    23,
    34,
    9,
    18,
    25,
    30,
    10,
    20,
    27,
    32,
    12,
    21,
    29,
    35,
    12,
    23,
    34,
    37,
    12,
    25,
    34,
    40,
    13,
    26,
    35,
    42,
    14,
    28,
    38,
    45,
    15,
    29,
    40,
    48,
    16,
    31,
    43,
    51,
    17,
    33,
    45,
    54,
    18,
    35,
    48,
    57,
    19,
    37,
    51,
    60,
    19,
    38,
    53,
    63,
    20,
    40,
    56,
    66,
    21,
    43,
    59,
    70,
    22,
    45,
    62,
    74,
    24,
    47,
    65,
    77,
    25,
    49,
    68,
    81
  ];
  const EC_CODEWORDS_TABLE = [
    // L  M  Q  H
    7,
    10,
    13,
    17,
    10,
    16,
    22,
    28,
    15,
    26,
    36,
    44,
    20,
    36,
    52,
    64,
    26,
    48,
    72,
    88,
    36,
    64,
    96,
    112,
    40,
    72,
    108,
    130,
    48,
    88,
    132,
    156,
    60,
    110,
    160,
    192,
    72,
    130,
    192,
    224,
    80,
    150,
    224,
    264,
    96,
    176,
    260,
    308,
    104,
    198,
    288,
    352,
    120,
    216,
    320,
    384,
    132,
    240,
    360,
    432,
    144,
    280,
    408,
    480,
    168,
    308,
    448,
    532,
    180,
    338,
    504,
    588,
    196,
    364,
    546,
    650,
    224,
    416,
    600,
    700,
    224,
    442,
    644,
    750,
    252,
    476,
    690,
    816,
    270,
    504,
    750,
    900,
    300,
    560,
    810,
    960,
    312,
    588,
    870,
    1050,
    336,
    644,
    952,
    1110,
    360,
    700,
    1020,
    1200,
    390,
    728,
    1050,
    1260,
    420,
    784,
    1140,
    1350,
    450,
    812,
    1200,
    1440,
    480,
    868,
    1290,
    1530,
    510,
    924,
    1350,
    1620,
    540,
    980,
    1440,
    1710,
    570,
    1036,
    1530,
    1800,
    570,
    1064,
    1590,
    1890,
    600,
    1120,
    1680,
    1980,
    630,
    1204,
    1770,
    2100,
    660,
    1260,
    1860,
    2220,
    720,
    1316,
    1950,
    2310,
    750,
    1372,
    2040,
    2430
  ];
  errorCorrectionCode.getBlocksCount = function getBlocksCount(version2, errorCorrectionLevel2) {
    switch (errorCorrectionLevel2) {
      case ECLevel$1.L:
        return EC_BLOCKS_TABLE[(version2 - 1) * 4 + 0];
      case ECLevel$1.M:
        return EC_BLOCKS_TABLE[(version2 - 1) * 4 + 1];
      case ECLevel$1.Q:
        return EC_BLOCKS_TABLE[(version2 - 1) * 4 + 2];
      case ECLevel$1.H:
        return EC_BLOCKS_TABLE[(version2 - 1) * 4 + 3];
      default:
        return void 0;
    }
  };
  errorCorrectionCode.getTotalCodewordsCount = function getTotalCodewordsCount(version2, errorCorrectionLevel2) {
    switch (errorCorrectionLevel2) {
      case ECLevel$1.L:
        return EC_CODEWORDS_TABLE[(version2 - 1) * 4 + 0];
      case ECLevel$1.M:
        return EC_CODEWORDS_TABLE[(version2 - 1) * 4 + 1];
      case ECLevel$1.Q:
        return EC_CODEWORDS_TABLE[(version2 - 1) * 4 + 2];
      case ECLevel$1.H:
        return EC_CODEWORDS_TABLE[(version2 - 1) * 4 + 3];
      default:
        return void 0;
    }
  };
  var polynomial = {};
  var galoisField = {};
  const EXP_TABLE = new Uint8Array(512);
  const LOG_TABLE = new Uint8Array(256);
  (function initTables() {
    let x = 1;
    for (let i = 0; i < 255; i++) {
      EXP_TABLE[i] = x;
      LOG_TABLE[x] = i;
      x <<= 1;
      if (x & 256) {
        x ^= 285;
      }
    }
    for (let i = 255; i < 512; i++) {
      EXP_TABLE[i] = EXP_TABLE[i - 255];
    }
  })();
  galoisField.log = function log(n) {
    if (n < 1) throw new Error("log(" + n + ")");
    return LOG_TABLE[n];
  };
  galoisField.exp = function exp(n) {
    return EXP_TABLE[n];
  };
  galoisField.mul = function mul(x, y) {
    if (x === 0 || y === 0) return 0;
    return EXP_TABLE[LOG_TABLE[x] + LOG_TABLE[y]];
  };
  (function(exports) {
    const GF = galoisField;
    exports.mul = function mul(p1, p2) {
      const coeff = new Uint8Array(p1.length + p2.length - 1);
      for (let i = 0; i < p1.length; i++) {
        for (let j = 0; j < p2.length; j++) {
          coeff[i + j] ^= GF.mul(p1[i], p2[j]);
        }
      }
      return coeff;
    };
    exports.mod = function mod(divident, divisor) {
      let result = new Uint8Array(divident);
      while (result.length - divisor.length >= 0) {
        const coeff = result[0];
        for (let i = 0; i < divisor.length; i++) {
          result[i] ^= GF.mul(divisor[i], coeff);
        }
        let offset = 0;
        while (offset < result.length && result[offset] === 0) offset++;
        result = result.slice(offset);
      }
      return result;
    };
    exports.generateECPolynomial = function generateECPolynomial(degree) {
      let poly = new Uint8Array([1]);
      for (let i = 0; i < degree; i++) {
        poly = exports.mul(poly, new Uint8Array([1, GF.exp(i)]));
      }
      return poly;
    };
  })(polynomial);
  const Polynomial = polynomial;
  function ReedSolomonEncoder$1(degree) {
    this.genPoly = void 0;
    this.degree = degree;
    if (this.degree) this.initialize(this.degree);
  }
  ReedSolomonEncoder$1.prototype.initialize = function initialize(degree) {
    this.degree = degree;
    this.genPoly = Polynomial.generateECPolynomial(this.degree);
  };
  ReedSolomonEncoder$1.prototype.encode = function encode(data) {
    if (!this.genPoly) {
      throw new Error("Encoder not initialized");
    }
    const paddedData = new Uint8Array(data.length + this.degree);
    paddedData.set(data);
    const remainder = Polynomial.mod(paddedData, this.genPoly);
    const start = this.degree - remainder.length;
    if (start > 0) {
      const buff = new Uint8Array(this.degree);
      buff.set(remainder, start);
      return buff;
    }
    return remainder;
  };
  var reedSolomonEncoder = ReedSolomonEncoder$1;
  var version = {};
  var mode = {};
  var versionCheck = {};
  versionCheck.isValid = function isValid(version2) {
    return !isNaN(version2) && version2 >= 1 && version2 <= 40;
  };
  var regex = {};
  const numeric = "[0-9]+";
  const alphanumeric = "[A-Z $%*+\\-./:]+";
  let kanji = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
  kanji = kanji.replace(/u/g, "\\u");
  const byte = "(?:(?![A-Z0-9 $%*+\\-./:]|" + kanji + ")(?:.|[\r\n]))+";
  regex.KANJI = new RegExp(kanji, "g");
  regex.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g");
  regex.BYTE = new RegExp(byte, "g");
  regex.NUMERIC = new RegExp(numeric, "g");
  regex.ALPHANUMERIC = new RegExp(alphanumeric, "g");
  const TEST_KANJI = new RegExp("^" + kanji + "$");
  const TEST_NUMERIC = new RegExp("^" + numeric + "$");
  const TEST_ALPHANUMERIC = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
  regex.testKanji = function testKanji(str) {
    return TEST_KANJI.test(str);
  };
  regex.testNumeric = function testNumeric(str) {
    return TEST_NUMERIC.test(str);
  };
  regex.testAlphanumeric = function testAlphanumeric(str) {
    return TEST_ALPHANUMERIC.test(str);
  };
  (function(exports) {
    const VersionCheck = versionCheck;
    const Regex = regex;
    exports.NUMERIC = {
      id: "Numeric",
      bit: 1 << 0,
      ccBits: [10, 12, 14]
    };
    exports.ALPHANUMERIC = {
      id: "Alphanumeric",
      bit: 1 << 1,
      ccBits: [9, 11, 13]
    };
    exports.BYTE = {
      id: "Byte",
      bit: 1 << 2,
      ccBits: [8, 16, 16]
    };
    exports.KANJI = {
      id: "Kanji",
      bit: 1 << 3,
      ccBits: [8, 10, 12]
    };
    exports.MIXED = {
      bit: -1
    };
    exports.getCharCountIndicator = function getCharCountIndicator(mode2, version2) {
      if (!mode2.ccBits) throw new Error("Invalid mode: " + mode2);
      if (!VersionCheck.isValid(version2)) {
        throw new Error("Invalid version: " + version2);
      }
      if (version2 >= 1 && version2 < 10) return mode2.ccBits[0];
      else if (version2 < 27) return mode2.ccBits[1];
      return mode2.ccBits[2];
    };
    exports.getBestModeForData = function getBestModeForData(dataStr) {
      if (Regex.testNumeric(dataStr)) return exports.NUMERIC;
      else if (Regex.testAlphanumeric(dataStr)) return exports.ALPHANUMERIC;
      else if (Regex.testKanji(dataStr)) return exports.KANJI;
      else return exports.BYTE;
    };
    exports.toString = function toString(mode2) {
      if (mode2 && mode2.id) return mode2.id;
      throw new Error("Invalid mode");
    };
    exports.isValid = function isValid(mode2) {
      return mode2 && mode2.bit && mode2.ccBits;
    };
    function fromString(string) {
      if (typeof string !== "string") {
        throw new Error("Param is not a string");
      }
      const lcStr = string.toLowerCase();
      switch (lcStr) {
        case "numeric":
          return exports.NUMERIC;
        case "alphanumeric":
          return exports.ALPHANUMERIC;
        case "kanji":
          return exports.KANJI;
        case "byte":
          return exports.BYTE;
        default:
          throw new Error("Unknown mode: " + string);
      }
    }
    exports.from = function from(value, defaultValue) {
      if (exports.isValid(value)) {
        return value;
      }
      try {
        return fromString(value);
      } catch (e) {
        return defaultValue;
      }
    };
  })(mode);
  (function(exports) {
    const Utils2 = utils$1;
    const ECCode2 = errorCorrectionCode;
    const ECLevel2 = errorCorrectionLevel;
    const Mode2 = mode;
    const VersionCheck = versionCheck;
    const G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
    const G18_BCH = Utils2.getBCHDigit(G18);
    function getBestVersionForDataLength(mode2, length, errorCorrectionLevel2) {
      for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
        if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel2, mode2)) {
          return currentVersion;
        }
      }
      return void 0;
    }
    function getReservedBitsCount(mode2, version2) {
      return Mode2.getCharCountIndicator(mode2, version2) + 4;
    }
    function getTotalBitsFromDataArray(segments2, version2) {
      let totalBits = 0;
      segments2.forEach(function(data) {
        const reservedBits = getReservedBitsCount(data.mode, version2);
        totalBits += reservedBits + data.getBitsLength();
      });
      return totalBits;
    }
    function getBestVersionForMixedData(segments2, errorCorrectionLevel2) {
      for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
        const length = getTotalBitsFromDataArray(segments2, currentVersion);
        if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel2, Mode2.MIXED)) {
          return currentVersion;
        }
      }
      return void 0;
    }
    exports.from = function from(value, defaultValue) {
      if (VersionCheck.isValid(value)) {
        return parseInt(value, 10);
      }
      return defaultValue;
    };
    exports.getCapacity = function getCapacity(version2, errorCorrectionLevel2, mode2) {
      if (!VersionCheck.isValid(version2)) {
        throw new Error("Invalid QR Code version");
      }
      if (typeof mode2 === "undefined") mode2 = Mode2.BYTE;
      const totalCodewords = Utils2.getSymbolTotalCodewords(version2);
      const ecTotalCodewords = ECCode2.getTotalCodewordsCount(version2, errorCorrectionLevel2);
      const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
      if (mode2 === Mode2.MIXED) return dataTotalCodewordsBits;
      const usableBits = dataTotalCodewordsBits - getReservedBitsCount(mode2, version2);
      switch (mode2) {
        case Mode2.NUMERIC:
          return Math.floor(usableBits / 10 * 3);
        case Mode2.ALPHANUMERIC:
          return Math.floor(usableBits / 11 * 2);
        case Mode2.KANJI:
          return Math.floor(usableBits / 13);
        case Mode2.BYTE:
        default:
          return Math.floor(usableBits / 8);
      }
    };
    exports.getBestVersionForData = function getBestVersionForData(data, errorCorrectionLevel2) {
      let seg;
      const ecl = ECLevel2.from(errorCorrectionLevel2, ECLevel2.M);
      if (Array.isArray(data)) {
        if (data.length > 1) {
          return getBestVersionForMixedData(data, ecl);
        }
        if (data.length === 0) {
          return 1;
        }
        seg = data[0];
      } else {
        seg = data;
      }
      return getBestVersionForDataLength(seg.mode, seg.getLength(), ecl);
    };
    exports.getEncodedBits = function getEncodedBits(version2) {
      if (!VersionCheck.isValid(version2) || version2 < 7) {
        throw new Error("Invalid QR Code version");
      }
      let d = version2 << 12;
      while (Utils2.getBCHDigit(d) - G18_BCH >= 0) {
        d ^= G18 << Utils2.getBCHDigit(d) - G18_BCH;
      }
      return version2 << 12 | d;
    };
  })(version);
  var formatInfo = {};
  const Utils$3 = utils$1;
  const G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
  const G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
  const G15_BCH = Utils$3.getBCHDigit(G15);
  formatInfo.getEncodedBits = function getEncodedBits(errorCorrectionLevel2, mask) {
    const data = errorCorrectionLevel2.bit << 3 | mask;
    let d = data << 10;
    while (Utils$3.getBCHDigit(d) - G15_BCH >= 0) {
      d ^= G15 << Utils$3.getBCHDigit(d) - G15_BCH;
    }
    return (data << 10 | d) ^ G15_MASK;
  };
  var segments = {};
  const Mode$4 = mode;
  function NumericData(data) {
    this.mode = Mode$4.NUMERIC;
    this.data = data.toString();
  }
  NumericData.getBitsLength = function getBitsLength(length) {
    return 10 * Math.floor(length / 3) + (length % 3 ? length % 3 * 3 + 1 : 0);
  };
  NumericData.prototype.getLength = function getLength() {
    return this.data.length;
  };
  NumericData.prototype.getBitsLength = function getBitsLength() {
    return NumericData.getBitsLength(this.data.length);
  };
  NumericData.prototype.write = function write(bitBuffer2) {
    let i, group, value;
    for (i = 0; i + 3 <= this.data.length; i += 3) {
      group = this.data.substr(i, 3);
      value = parseInt(group, 10);
      bitBuffer2.put(value, 10);
    }
    const remainingNum = this.data.length - i;
    if (remainingNum > 0) {
      group = this.data.substr(i);
      value = parseInt(group, 10);
      bitBuffer2.put(value, remainingNum * 3 + 1);
    }
  };
  var numericData = NumericData;
  const Mode$3 = mode;
  const ALPHA_NUM_CHARS = [
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    " ",
    "$",
    "%",
    "*",
    "+",
    "-",
    ".",
    "/",
    ":"
  ];
  function AlphanumericData(data) {
    this.mode = Mode$3.ALPHANUMERIC;
    this.data = data;
  }
  AlphanumericData.getBitsLength = function getBitsLength(length) {
    return 11 * Math.floor(length / 2) + 6 * (length % 2);
  };
  AlphanumericData.prototype.getLength = function getLength() {
    return this.data.length;
  };
  AlphanumericData.prototype.getBitsLength = function getBitsLength() {
    return AlphanumericData.getBitsLength(this.data.length);
  };
  AlphanumericData.prototype.write = function write(bitBuffer2) {
    let i;
    for (i = 0; i + 2 <= this.data.length; i += 2) {
      let value = ALPHA_NUM_CHARS.indexOf(this.data[i]) * 45;
      value += ALPHA_NUM_CHARS.indexOf(this.data[i + 1]);
      bitBuffer2.put(value, 11);
    }
    if (this.data.length % 2) {
      bitBuffer2.put(ALPHA_NUM_CHARS.indexOf(this.data[i]), 6);
    }
  };
  var alphanumericData = AlphanumericData;
  const Mode$2 = mode;
  function ByteData(data) {
    this.mode = Mode$2.BYTE;
    if (typeof data === "string") {
      this.data = new TextEncoder().encode(data);
    } else {
      this.data = new Uint8Array(data);
    }
  }
  ByteData.getBitsLength = function getBitsLength(length) {
    return length * 8;
  };
  ByteData.prototype.getLength = function getLength() {
    return this.data.length;
  };
  ByteData.prototype.getBitsLength = function getBitsLength() {
    return ByteData.getBitsLength(this.data.length);
  };
  ByteData.prototype.write = function(bitBuffer2) {
    for (let i = 0, l = this.data.length; i < l; i++) {
      bitBuffer2.put(this.data[i], 8);
    }
  };
  var byteData = ByteData;
  const Mode$1 = mode;
  const Utils$2 = utils$1;
  function KanjiData(data) {
    this.mode = Mode$1.KANJI;
    this.data = data;
  }
  KanjiData.getBitsLength = function getBitsLength(length) {
    return length * 13;
  };
  KanjiData.prototype.getLength = function getLength() {
    return this.data.length;
  };
  KanjiData.prototype.getBitsLength = function getBitsLength() {
    return KanjiData.getBitsLength(this.data.length);
  };
  KanjiData.prototype.write = function(bitBuffer2) {
    let i;
    for (i = 0; i < this.data.length; i++) {
      let value = Utils$2.toSJIS(this.data[i]);
      if (value >= 33088 && value <= 40956) {
        value -= 33088;
      } else if (value >= 57408 && value <= 60351) {
        value -= 49472;
      } else {
        throw new Error(
          "Invalid SJIS character: " + this.data[i] + "\nMake sure your charset is UTF-8"
        );
      }
      value = (value >>> 8 & 255) * 192 + (value & 255);
      bitBuffer2.put(value, 13);
    }
  };
  var kanjiData = KanjiData;
  var dijkstra = { exports: {} };
  (function(module) {
    var dijkstra2 = {
      single_source_shortest_paths: function(graph, s, d) {
        var predecessors = {};
        var costs = {};
        costs[s] = 0;
        var open = dijkstra2.PriorityQueue.make();
        open.push(s, 0);
        var closest, u, v, cost_of_s_to_u, adjacent_nodes, cost_of_e, cost_of_s_to_u_plus_cost_of_e, cost_of_s_to_v, first_visit;
        while (!open.empty()) {
          closest = open.pop();
          u = closest.value;
          cost_of_s_to_u = closest.cost;
          adjacent_nodes = graph[u] || {};
          for (v in adjacent_nodes) {
            if (adjacent_nodes.hasOwnProperty(v)) {
              cost_of_e = adjacent_nodes[v];
              cost_of_s_to_u_plus_cost_of_e = cost_of_s_to_u + cost_of_e;
              cost_of_s_to_v = costs[v];
              first_visit = typeof costs[v] === "undefined";
              if (first_visit || cost_of_s_to_v > cost_of_s_to_u_plus_cost_of_e) {
                costs[v] = cost_of_s_to_u_plus_cost_of_e;
                open.push(v, cost_of_s_to_u_plus_cost_of_e);
                predecessors[v] = u;
              }
            }
          }
        }
        if (typeof d !== "undefined" && typeof costs[d] === "undefined") {
          var msg = ["Could not find a path from ", s, " to ", d, "."].join("");
          throw new Error(msg);
        }
        return predecessors;
      },
      extract_shortest_path_from_predecessor_list: function(predecessors, d) {
        var nodes = [];
        var u = d;
        while (u) {
          nodes.push(u);
          predecessors[u];
          u = predecessors[u];
        }
        nodes.reverse();
        return nodes;
      },
      find_path: function(graph, s, d) {
        var predecessors = dijkstra2.single_source_shortest_paths(graph, s, d);
        return dijkstra2.extract_shortest_path_from_predecessor_list(
          predecessors,
          d
        );
      },
      /**
       * A very naive priority queue implementation.
       */
      PriorityQueue: {
        make: function(opts) {
          var T = dijkstra2.PriorityQueue, t = {}, key;
          opts = opts || {};
          for (key in T) {
            if (T.hasOwnProperty(key)) {
              t[key] = T[key];
            }
          }
          t.queue = [];
          t.sorter = opts.sorter || T.default_sorter;
          return t;
        },
        default_sorter: function(a, b) {
          return a.cost - b.cost;
        },
        /**
         * Add a new item to the queue and ensure the highest priority element
         * is at the front of the queue.
         */
        push: function(value, cost) {
          var item = { value, cost };
          this.queue.push(item);
          this.queue.sort(this.sorter);
        },
        /**
         * Return the highest priority element in the queue.
         */
        pop: function() {
          return this.queue.shift();
        },
        empty: function() {
          return this.queue.length === 0;
        }
      }
    };
    {
      module.exports = dijkstra2;
    }
  })(dijkstra);
  var dijkstraExports = dijkstra.exports;
  (function(exports) {
    const Mode2 = mode;
    const NumericData2 = numericData;
    const AlphanumericData2 = alphanumericData;
    const ByteData2 = byteData;
    const KanjiData2 = kanjiData;
    const Regex = regex;
    const Utils2 = utils$1;
    const dijkstra2 = dijkstraExports;
    function getStringByteLength(str) {
      return unescape(encodeURIComponent(str)).length;
    }
    function getSegments(regex2, mode2, str) {
      const segments2 = [];
      let result;
      while ((result = regex2.exec(str)) !== null) {
        segments2.push({
          data: result[0],
          index: result.index,
          mode: mode2,
          length: result[0].length
        });
      }
      return segments2;
    }
    function getSegmentsFromString(dataStr) {
      const numSegs = getSegments(Regex.NUMERIC, Mode2.NUMERIC, dataStr);
      const alphaNumSegs = getSegments(Regex.ALPHANUMERIC, Mode2.ALPHANUMERIC, dataStr);
      let byteSegs;
      let kanjiSegs;
      if (Utils2.isKanjiModeEnabled()) {
        byteSegs = getSegments(Regex.BYTE, Mode2.BYTE, dataStr);
        kanjiSegs = getSegments(Regex.KANJI, Mode2.KANJI, dataStr);
      } else {
        byteSegs = getSegments(Regex.BYTE_KANJI, Mode2.BYTE, dataStr);
        kanjiSegs = [];
      }
      const segs = numSegs.concat(alphaNumSegs, byteSegs, kanjiSegs);
      return segs.sort(function(s1, s2) {
        return s1.index - s2.index;
      }).map(function(obj) {
        return {
          data: obj.data,
          mode: obj.mode,
          length: obj.length
        };
      });
    }
    function getSegmentBitsLength(length, mode2) {
      switch (mode2) {
        case Mode2.NUMERIC:
          return NumericData2.getBitsLength(length);
        case Mode2.ALPHANUMERIC:
          return AlphanumericData2.getBitsLength(length);
        case Mode2.KANJI:
          return KanjiData2.getBitsLength(length);
        case Mode2.BYTE:
          return ByteData2.getBitsLength(length);
      }
    }
    function mergeSegments(segs) {
      return segs.reduce(function(acc, curr) {
        const prevSeg = acc.length - 1 >= 0 ? acc[acc.length - 1] : null;
        if (prevSeg && prevSeg.mode === curr.mode) {
          acc[acc.length - 1].data += curr.data;
          return acc;
        }
        acc.push(curr);
        return acc;
      }, []);
    }
    function buildNodes(segs) {
      const nodes = [];
      for (let i = 0; i < segs.length; i++) {
        const seg = segs[i];
        switch (seg.mode) {
          case Mode2.NUMERIC:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode2.ALPHANUMERIC, length: seg.length },
              { data: seg.data, mode: Mode2.BYTE, length: seg.length }
            ]);
            break;
          case Mode2.ALPHANUMERIC:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode2.BYTE, length: seg.length }
            ]);
            break;
          case Mode2.KANJI:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode2.BYTE, length: getStringByteLength(seg.data) }
            ]);
            break;
          case Mode2.BYTE:
            nodes.push([
              { data: seg.data, mode: Mode2.BYTE, length: getStringByteLength(seg.data) }
            ]);
        }
      }
      return nodes;
    }
    function buildGraph(nodes, version2) {
      const table = {};
      const graph = { start: {} };
      let prevNodeIds = ["start"];
      for (let i = 0; i < nodes.length; i++) {
        const nodeGroup = nodes[i];
        const currentNodeIds = [];
        for (let j = 0; j < nodeGroup.length; j++) {
          const node = nodeGroup[j];
          const key = "" + i + j;
          currentNodeIds.push(key);
          table[key] = { node, lastCount: 0 };
          graph[key] = {};
          for (let n = 0; n < prevNodeIds.length; n++) {
            const prevNodeId = prevNodeIds[n];
            if (table[prevNodeId] && table[prevNodeId].node.mode === node.mode) {
              graph[prevNodeId][key] = getSegmentBitsLength(table[prevNodeId].lastCount + node.length, node.mode) - getSegmentBitsLength(table[prevNodeId].lastCount, node.mode);
              table[prevNodeId].lastCount += node.length;
            } else {
              if (table[prevNodeId]) table[prevNodeId].lastCount = node.length;
              graph[prevNodeId][key] = getSegmentBitsLength(node.length, node.mode) + 4 + Mode2.getCharCountIndicator(node.mode, version2);
            }
          }
        }
        prevNodeIds = currentNodeIds;
      }
      for (let n = 0; n < prevNodeIds.length; n++) {
        graph[prevNodeIds[n]].end = 0;
      }
      return { map: graph, table };
    }
    function buildSingleSegment(data, modesHint) {
      let mode2;
      const bestMode = Mode2.getBestModeForData(data);
      mode2 = Mode2.from(modesHint, bestMode);
      if (mode2 !== Mode2.BYTE && mode2.bit < bestMode.bit) {
        throw new Error('"' + data + '" cannot be encoded with mode ' + Mode2.toString(mode2) + ".\n Suggested mode is: " + Mode2.toString(bestMode));
      }
      if (mode2 === Mode2.KANJI && !Utils2.isKanjiModeEnabled()) {
        mode2 = Mode2.BYTE;
      }
      switch (mode2) {
        case Mode2.NUMERIC:
          return new NumericData2(data);
        case Mode2.ALPHANUMERIC:
          return new AlphanumericData2(data);
        case Mode2.KANJI:
          return new KanjiData2(data);
        case Mode2.BYTE:
          return new ByteData2(data);
      }
    }
    exports.fromArray = function fromArray(array) {
      return array.reduce(function(acc, seg) {
        if (typeof seg === "string") {
          acc.push(buildSingleSegment(seg, null));
        } else if (seg.data) {
          acc.push(buildSingleSegment(seg.data, seg.mode));
        }
        return acc;
      }, []);
    };
    exports.fromString = function fromString(data, version2) {
      const segs = getSegmentsFromString(data, Utils2.isKanjiModeEnabled());
      const nodes = buildNodes(segs);
      const graph = buildGraph(nodes, version2);
      const path = dijkstra2.find_path(graph.map, "start", "end");
      const optimizedSegs = [];
      for (let i = 1; i < path.length - 1; i++) {
        optimizedSegs.push(graph.table[path[i]].node);
      }
      return exports.fromArray(mergeSegments(optimizedSegs));
    };
    exports.rawSplit = function rawSplit(data) {
      return exports.fromArray(
        getSegmentsFromString(data, Utils2.isKanjiModeEnabled())
      );
    };
  })(segments);
  const Utils$1 = utils$1;
  const ECLevel = errorCorrectionLevel;
  const BitBuffer = bitBuffer;
  const BitMatrix = bitMatrix;
  const AlignmentPattern = alignmentPattern;
  const FinderPattern = finderPattern;
  const MaskPattern = maskPattern;
  const ECCode = errorCorrectionCode;
  const ReedSolomonEncoder = reedSolomonEncoder;
  const Version = version;
  const FormatInfo = formatInfo;
  const Mode = mode;
  const Segments = segments;
  function setupFinderPattern(matrix, version2) {
    const size = matrix.size;
    const pos = FinderPattern.getPositions(version2);
    for (let i = 0; i < pos.length; i++) {
      const row = pos[i][0];
      const col = pos[i][1];
      for (let r = -1; r <= 7; r++) {
        if (row + r <= -1 || size <= row + r) continue;
        for (let c = -1; c <= 7; c++) {
          if (col + c <= -1 || size <= col + c) continue;
          if (r >= 0 && r <= 6 && (c === 0 || c === 6) || c >= 0 && c <= 6 && (r === 0 || r === 6) || r >= 2 && r <= 4 && c >= 2 && c <= 4) {
            matrix.set(row + r, col + c, true, true);
          } else {
            matrix.set(row + r, col + c, false, true);
          }
        }
      }
    }
  }
  function setupTimingPattern(matrix) {
    const size = matrix.size;
    for (let r = 8; r < size - 8; r++) {
      const value = r % 2 === 0;
      matrix.set(r, 6, value, true);
      matrix.set(6, r, value, true);
    }
  }
  function setupAlignmentPattern(matrix, version2) {
    const pos = AlignmentPattern.getPositions(version2);
    for (let i = 0; i < pos.length; i++) {
      const row = pos[i][0];
      const col = pos[i][1];
      for (let r = -2; r <= 2; r++) {
        for (let c = -2; c <= 2; c++) {
          if (r === -2 || r === 2 || c === -2 || c === 2 || r === 0 && c === 0) {
            matrix.set(row + r, col + c, true, true);
          } else {
            matrix.set(row + r, col + c, false, true);
          }
        }
      }
    }
  }
  function setupVersionInfo(matrix, version2) {
    const size = matrix.size;
    const bits = Version.getEncodedBits(version2);
    let row, col, mod;
    for (let i = 0; i < 18; i++) {
      row = Math.floor(i / 3);
      col = i % 3 + size - 8 - 3;
      mod = (bits >> i & 1) === 1;
      matrix.set(row, col, mod, true);
      matrix.set(col, row, mod, true);
    }
  }
  function setupFormatInfo(matrix, errorCorrectionLevel2, maskPattern2) {
    const size = matrix.size;
    const bits = FormatInfo.getEncodedBits(errorCorrectionLevel2, maskPattern2);
    let i, mod;
    for (i = 0; i < 15; i++) {
      mod = (bits >> i & 1) === 1;
      if (i < 6) {
        matrix.set(i, 8, mod, true);
      } else if (i < 8) {
        matrix.set(i + 1, 8, mod, true);
      } else {
        matrix.set(size - 15 + i, 8, mod, true);
      }
      if (i < 8) {
        matrix.set(8, size - i - 1, mod, true);
      } else if (i < 9) {
        matrix.set(8, 15 - i - 1 + 1, mod, true);
      } else {
        matrix.set(8, 15 - i - 1, mod, true);
      }
    }
    matrix.set(size - 8, 8, 1, true);
  }
  function setupData(matrix, data) {
    const size = matrix.size;
    let inc = -1;
    let row = size - 1;
    let bitIndex = 7;
    let byteIndex = 0;
    for (let col = size - 1; col > 0; col -= 2) {
      if (col === 6) col--;
      while (true) {
        for (let c = 0; c < 2; c++) {
          if (!matrix.isReserved(row, col - c)) {
            let dark = false;
            if (byteIndex < data.length) {
              dark = (data[byteIndex] >>> bitIndex & 1) === 1;
            }
            matrix.set(row, col - c, dark);
            bitIndex--;
            if (bitIndex === -1) {
              byteIndex++;
              bitIndex = 7;
            }
          }
        }
        row += inc;
        if (row < 0 || size <= row) {
          row -= inc;
          inc = -inc;
          break;
        }
      }
    }
  }
  function createData(version2, errorCorrectionLevel2, segments2) {
    const buffer = new BitBuffer();
    segments2.forEach(function(data) {
      buffer.put(data.mode.bit, 4);
      buffer.put(data.getLength(), Mode.getCharCountIndicator(data.mode, version2));
      data.write(buffer);
    });
    const totalCodewords = Utils$1.getSymbolTotalCodewords(version2);
    const ecTotalCodewords = ECCode.getTotalCodewordsCount(version2, errorCorrectionLevel2);
    const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
    if (buffer.getLengthInBits() + 4 <= dataTotalCodewordsBits) {
      buffer.put(0, 4);
    }
    while (buffer.getLengthInBits() % 8 !== 0) {
      buffer.putBit(0);
    }
    const remainingByte = (dataTotalCodewordsBits - buffer.getLengthInBits()) / 8;
    for (let i = 0; i < remainingByte; i++) {
      buffer.put(i % 2 ? 17 : 236, 8);
    }
    return createCodewords(buffer, version2, errorCorrectionLevel2);
  }
  function createCodewords(bitBuffer2, version2, errorCorrectionLevel2) {
    const totalCodewords = Utils$1.getSymbolTotalCodewords(version2);
    const ecTotalCodewords = ECCode.getTotalCodewordsCount(version2, errorCorrectionLevel2);
    const dataTotalCodewords = totalCodewords - ecTotalCodewords;
    const ecTotalBlocks = ECCode.getBlocksCount(version2, errorCorrectionLevel2);
    const blocksInGroup2 = totalCodewords % ecTotalBlocks;
    const blocksInGroup1 = ecTotalBlocks - blocksInGroup2;
    const totalCodewordsInGroup1 = Math.floor(totalCodewords / ecTotalBlocks);
    const dataCodewordsInGroup1 = Math.floor(dataTotalCodewords / ecTotalBlocks);
    const dataCodewordsInGroup2 = dataCodewordsInGroup1 + 1;
    const ecCount = totalCodewordsInGroup1 - dataCodewordsInGroup1;
    const rs = new ReedSolomonEncoder(ecCount);
    let offset = 0;
    const dcData = new Array(ecTotalBlocks);
    const ecData = new Array(ecTotalBlocks);
    let maxDataSize = 0;
    const buffer = new Uint8Array(bitBuffer2.buffer);
    for (let b = 0; b < ecTotalBlocks; b++) {
      const dataSize = b < blocksInGroup1 ? dataCodewordsInGroup1 : dataCodewordsInGroup2;
      dcData[b] = buffer.slice(offset, offset + dataSize);
      ecData[b] = rs.encode(dcData[b]);
      offset += dataSize;
      maxDataSize = Math.max(maxDataSize, dataSize);
    }
    const data = new Uint8Array(totalCodewords);
    let index = 0;
    let i, r;
    for (i = 0; i < maxDataSize; i++) {
      for (r = 0; r < ecTotalBlocks; r++) {
        if (i < dcData[r].length) {
          data[index++] = dcData[r][i];
        }
      }
    }
    for (i = 0; i < ecCount; i++) {
      for (r = 0; r < ecTotalBlocks; r++) {
        data[index++] = ecData[r][i];
      }
    }
    return data;
  }
  function createSymbol(data, version2, errorCorrectionLevel2, maskPattern2) {
    let segments2;
    if (Array.isArray(data)) {
      segments2 = Segments.fromArray(data);
    } else if (typeof data === "string") {
      let estimatedVersion = version2;
      if (!estimatedVersion) {
        const rawSegments = Segments.rawSplit(data);
        estimatedVersion = Version.getBestVersionForData(rawSegments, errorCorrectionLevel2);
      }
      segments2 = Segments.fromString(data, estimatedVersion || 40);
    } else {
      throw new Error("Invalid data");
    }
    const bestVersion = Version.getBestVersionForData(segments2, errorCorrectionLevel2);
    if (!bestVersion) {
      throw new Error("The amount of data is too big to be stored in a QR Code");
    }
    if (!version2) {
      version2 = bestVersion;
    } else if (version2 < bestVersion) {
      throw new Error(
        "\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + bestVersion + ".\n"
      );
    }
    const dataBits = createData(version2, errorCorrectionLevel2, segments2);
    const moduleCount = Utils$1.getSymbolSize(version2);
    const modules = new BitMatrix(moduleCount);
    setupFinderPattern(modules, version2);
    setupTimingPattern(modules);
    setupAlignmentPattern(modules, version2);
    setupFormatInfo(modules, errorCorrectionLevel2, 0);
    if (version2 >= 7) {
      setupVersionInfo(modules, version2);
    }
    setupData(modules, dataBits);
    if (isNaN(maskPattern2)) {
      maskPattern2 = MaskPattern.getBestMask(
        modules,
        setupFormatInfo.bind(null, modules, errorCorrectionLevel2)
      );
    }
    MaskPattern.applyMask(maskPattern2, modules);
    setupFormatInfo(modules, errorCorrectionLevel2, maskPattern2);
    return {
      modules,
      version: version2,
      errorCorrectionLevel: errorCorrectionLevel2,
      maskPattern: maskPattern2,
      segments: segments2
    };
  }
  qrcode.create = function create(data, options) {
    if (typeof data === "undefined" || data === "") {
      throw new Error("No input text");
    }
    let errorCorrectionLevel2 = ECLevel.M;
    let version2;
    let mask;
    if (typeof options !== "undefined") {
      errorCorrectionLevel2 = ECLevel.from(options.errorCorrectionLevel, ECLevel.M);
      version2 = Version.from(options.version);
      mask = MaskPattern.from(options.maskPattern);
      if (options.toSJISFunc) {
        Utils$1.setToSJISFunction(options.toSJISFunc);
      }
    }
    return createSymbol(data, version2, errorCorrectionLevel2, mask);
  };
  var canvas = {};
  var utils = {};
  (function(exports) {
    function hex2rgba(hex) {
      if (typeof hex === "number") {
        hex = hex.toString();
      }
      if (typeof hex !== "string") {
        throw new Error("Color should be defined as hex string");
      }
      let hexCode = hex.slice().replace("#", "").split("");
      if (hexCode.length < 3 || hexCode.length === 5 || hexCode.length > 8) {
        throw new Error("Invalid hex color: " + hex);
      }
      if (hexCode.length === 3 || hexCode.length === 4) {
        hexCode = Array.prototype.concat.apply([], hexCode.map(function(c) {
          return [c, c];
        }));
      }
      if (hexCode.length === 6) hexCode.push("F", "F");
      const hexValue = parseInt(hexCode.join(""), 16);
      return {
        r: hexValue >> 24 & 255,
        g: hexValue >> 16 & 255,
        b: hexValue >> 8 & 255,
        a: hexValue & 255,
        hex: "#" + hexCode.slice(0, 6).join("")
      };
    }
    exports.getOptions = function getOptions(options) {
      if (!options) options = {};
      if (!options.color) options.color = {};
      const margin = typeof options.margin === "undefined" || options.margin === null || options.margin < 0 ? 4 : options.margin;
      const width = options.width && options.width >= 21 ? options.width : void 0;
      const scale = options.scale || 4;
      return {
        width,
        scale: width ? 4 : scale,
        margin,
        color: {
          dark: hex2rgba(options.color.dark || "#000000ff"),
          light: hex2rgba(options.color.light || "#ffffffff")
        },
        type: options.type,
        rendererOpts: options.rendererOpts || {}
      };
    };
    exports.getScale = function getScale(qrSize, opts) {
      return opts.width && opts.width >= qrSize + opts.margin * 2 ? opts.width / (qrSize + opts.margin * 2) : opts.scale;
    };
    exports.getImageWidth = function getImageWidth(qrSize, opts) {
      const scale = exports.getScale(qrSize, opts);
      return Math.floor((qrSize + opts.margin * 2) * scale);
    };
    exports.qrToImageData = function qrToImageData(imgData, qr, opts) {
      const size = qr.modules.size;
      const data = qr.modules.data;
      const scale = exports.getScale(size, opts);
      const symbolSize = Math.floor((size + opts.margin * 2) * scale);
      const scaledMargin = opts.margin * scale;
      const palette = [opts.color.light, opts.color.dark];
      for (let i = 0; i < symbolSize; i++) {
        for (let j = 0; j < symbolSize; j++) {
          let posDst = (i * symbolSize + j) * 4;
          let pxColor = opts.color.light;
          if (i >= scaledMargin && j >= scaledMargin && i < symbolSize - scaledMargin && j < symbolSize - scaledMargin) {
            const iSrc = Math.floor((i - scaledMargin) / scale);
            const jSrc = Math.floor((j - scaledMargin) / scale);
            pxColor = palette[data[iSrc * size + jSrc] ? 1 : 0];
          }
          imgData[posDst++] = pxColor.r;
          imgData[posDst++] = pxColor.g;
          imgData[posDst++] = pxColor.b;
          imgData[posDst] = pxColor.a;
        }
      }
    };
  })(utils);
  (function(exports) {
    const Utils2 = utils;
    function clearCanvas(ctx, canvas2, size) {
      ctx.clearRect(0, 0, canvas2.width, canvas2.height);
      if (!canvas2.style) canvas2.style = {};
      canvas2.height = size;
      canvas2.width = size;
      canvas2.style.height = size + "px";
      canvas2.style.width = size + "px";
    }
    function getCanvasElement() {
      try {
        return document.createElement("canvas");
      } catch (e) {
        throw new Error("You need to specify a canvas element");
      }
    }
    exports.render = function render(qrData, canvas2, options) {
      let opts = options;
      let canvasEl = canvas2;
      if (typeof opts === "undefined" && (!canvas2 || !canvas2.getContext)) {
        opts = canvas2;
        canvas2 = void 0;
      }
      if (!canvas2) {
        canvasEl = getCanvasElement();
      }
      opts = Utils2.getOptions(opts);
      const size = Utils2.getImageWidth(qrData.modules.size, opts);
      const ctx = canvasEl.getContext("2d");
      const image = ctx.createImageData(size, size);
      Utils2.qrToImageData(image.data, qrData, opts);
      clearCanvas(ctx, canvasEl, size);
      ctx.putImageData(image, 0, 0);
      return canvasEl;
    };
    exports.renderToDataURL = function renderToDataURL(qrData, canvas2, options) {
      let opts = options;
      if (typeof opts === "undefined" && (!canvas2 || !canvas2.getContext)) {
        opts = canvas2;
        canvas2 = void 0;
      }
      if (!opts) opts = {};
      const canvasEl = exports.render(qrData, canvas2, opts);
      const type = opts.type || "image/png";
      const rendererOpts = opts.rendererOpts || {};
      return canvasEl.toDataURL(type, rendererOpts.quality);
    };
  })(canvas);
  var svgTag = {};
  const Utils = utils;
  function getColorAttrib(color, attrib) {
    const alpha = color.a / 255;
    const str = attrib + '="' + color.hex + '"';
    return alpha < 1 ? str + " " + attrib + '-opacity="' + alpha.toFixed(2).slice(1) + '"' : str;
  }
  function svgCmd(cmd, x, y) {
    let str = cmd + x;
    if (typeof y !== "undefined") str += " " + y;
    return str;
  }
  function qrToPath(data, size, margin) {
    let path = "";
    let moveBy = 0;
    let newRow = false;
    let lineLength = 0;
    for (let i = 0; i < data.length; i++) {
      const col = Math.floor(i % size);
      const row = Math.floor(i / size);
      if (!col && !newRow) newRow = true;
      if (data[i]) {
        lineLength++;
        if (!(i > 0 && col > 0 && data[i - 1])) {
          path += newRow ? svgCmd("M", col + margin, 0.5 + row + margin) : svgCmd("m", moveBy, 0);
          moveBy = 0;
          newRow = false;
        }
        if (!(col + 1 < size && data[i + 1])) {
          path += svgCmd("h", lineLength);
          lineLength = 0;
        }
      } else {
        moveBy++;
      }
    }
    return path;
  }
  svgTag.render = function render(qrData, options, cb) {
    const opts = Utils.getOptions(options);
    const size = qrData.modules.size;
    const data = qrData.modules.data;
    const qrcodesize = size + opts.margin * 2;
    const bg = !opts.color.light.a ? "" : "<path " + getColorAttrib(opts.color.light, "fill") + ' d="M0 0h' + qrcodesize + "v" + qrcodesize + 'H0z"/>';
    const path = "<path " + getColorAttrib(opts.color.dark, "stroke") + ' d="' + qrToPath(data, size, opts.margin) + '"/>';
    const viewBox = 'viewBox="0 0 ' + qrcodesize + " " + qrcodesize + '"';
    const width = !opts.width ? "" : 'width="' + opts.width + '" height="' + opts.width + '" ';
    const svgTag2 = '<svg xmlns="http://www.w3.org/2000/svg" ' + width + viewBox + ' shape-rendering="crispEdges">' + bg + path + "</svg>\n";
    if (typeof cb === "function") {
      cb(null, svgTag2);
    }
    return svgTag2;
  };
  const canPromise = canPromise$1;
  const QRCode = qrcode;
  const CanvasRenderer = canvas;
  const SvgRenderer = svgTag;
  function renderCanvas(renderFunc, canvas2, text, opts, cb) {
    const args = [].slice.call(arguments, 1);
    const argsNum = args.length;
    const isLastArgCb = typeof args[argsNum - 1] === "function";
    if (!isLastArgCb && !canPromise()) {
      throw new Error("Callback required as last argument");
    }
    if (isLastArgCb) {
      if (argsNum < 2) {
        throw new Error("Too few arguments provided");
      }
      if (argsNum === 2) {
        cb = text;
        text = canvas2;
        canvas2 = opts = void 0;
      } else if (argsNum === 3) {
        if (canvas2.getContext && typeof cb === "undefined") {
          cb = opts;
          opts = void 0;
        } else {
          cb = opts;
          opts = text;
          text = canvas2;
          canvas2 = void 0;
        }
      }
    } else {
      if (argsNum < 1) {
        throw new Error("Too few arguments provided");
      }
      if (argsNum === 1) {
        text = canvas2;
        canvas2 = opts = void 0;
      } else if (argsNum === 2 && !canvas2.getContext) {
        opts = text;
        text = canvas2;
        canvas2 = void 0;
      }
      return new Promise(function(resolve, reject) {
        try {
          const data = QRCode.create(text, opts);
          resolve(renderFunc(data, canvas2, opts));
        } catch (e) {
          reject(e);
        }
      });
    }
    try {
      const data = QRCode.create(text, opts);
      cb(null, renderFunc(data, canvas2, opts));
    } catch (e) {
      cb(e);
    }
  }
  browser.create = QRCode.create;
  browser.toCanvas = renderCanvas.bind(null, CanvasRenderer.render);
  browser.toDataURL = renderCanvas.bind(null, CanvasRenderer.renderToDataURL);
  browser.toString = renderCanvas.bind(null, function(data, _, opts) {
    return SvgRenderer.render(data, opts);
  });
  var md5$1 = { exports: {} };
  var crypt = { exports: {} };
  (function() {
    var base64map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", crypt$1 = {
      // Bit-wise rotation left
      rotl: function(n, b) {
        return n << b | n >>> 32 - b;
      },
      // Bit-wise rotation right
      rotr: function(n, b) {
        return n << 32 - b | n >>> b;
      },
      // Swap big-endian to little-endian and vice versa
      endian: function(n) {
        if (n.constructor == Number) {
          return crypt$1.rotl(n, 8) & 16711935 | crypt$1.rotl(n, 24) & 4278255360;
        }
        for (var i = 0; i < n.length; i++)
          n[i] = crypt$1.endian(n[i]);
        return n;
      },
      // Generate an array of any length of random bytes
      randomBytes: function(n) {
        for (var bytes = []; n > 0; n--)
          bytes.push(Math.floor(Math.random() * 256));
        return bytes;
      },
      // Convert a byte array to big-endian 32-bit words
      bytesToWords: function(bytes) {
        for (var words = [], i = 0, b = 0; i < bytes.length; i++, b += 8)
          words[b >>> 5] |= bytes[i] << 24 - b % 32;
        return words;
      },
      // Convert big-endian 32-bit words to a byte array
      wordsToBytes: function(words) {
        for (var bytes = [], b = 0; b < words.length * 32; b += 8)
          bytes.push(words[b >>> 5] >>> 24 - b % 32 & 255);
        return bytes;
      },
      // Convert a byte array to a hex string
      bytesToHex: function(bytes) {
        for (var hex = [], i = 0; i < bytes.length; i++) {
          hex.push((bytes[i] >>> 4).toString(16));
          hex.push((bytes[i] & 15).toString(16));
        }
        return hex.join("");
      },
      // Convert a hex string to a byte array
      hexToBytes: function(hex) {
        for (var bytes = [], c = 0; c < hex.length; c += 2)
          bytes.push(parseInt(hex.substr(c, 2), 16));
        return bytes;
      },
      // Convert a byte array to a base-64 string
      bytesToBase64: function(bytes) {
        for (var base64 = [], i = 0; i < bytes.length; i += 3) {
          var triplet = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
          for (var j = 0; j < 4; j++)
            if (i * 8 + j * 6 <= bytes.length * 8)
              base64.push(base64map.charAt(triplet >>> 6 * (3 - j) & 63));
            else
              base64.push("=");
        }
        return base64.join("");
      },
      // Convert a base-64 string to a byte array
      base64ToBytes: function(base64) {
        base64 = base64.replace(/[^A-Z0-9+\/]/ig, "");
        for (var bytes = [], i = 0, imod4 = 0; i < base64.length; imod4 = ++i % 4) {
          if (imod4 == 0) continue;
          bytes.push((base64map.indexOf(base64.charAt(i - 1)) & Math.pow(2, -2 * imod4 + 8) - 1) << imod4 * 2 | base64map.indexOf(base64.charAt(i)) >>> 6 - imod4 * 2);
        }
        return bytes;
      }
    };
    crypt.exports = crypt$1;
  })();
  var cryptExports = crypt.exports;
  var charenc = {
    // UTF-8 encoding
    utf8: {
      // Convert a string to a byte array
      stringToBytes: function(str) {
        return charenc.bin.stringToBytes(unescape(encodeURIComponent(str)));
      },
      // Convert a byte array to a string
      bytesToString: function(bytes) {
        return decodeURIComponent(escape(charenc.bin.bytesToString(bytes)));
      }
    },
    // Binary encoding
    bin: {
      // Convert a string to a byte array
      stringToBytes: function(str) {
        for (var bytes = [], i = 0; i < str.length; i++)
          bytes.push(str.charCodeAt(i) & 255);
        return bytes;
      },
      // Convert a byte array to a string
      bytesToString: function(bytes) {
        for (var str = [], i = 0; i < bytes.length; i++)
          str.push(String.fromCharCode(bytes[i]));
        return str.join("");
      }
    }
  };
  var charenc_1 = charenc;
  /*!
   * Determine if an object is a Buffer
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   */
  var isBuffer_1 = function(obj) {
    return obj != null && (isBuffer(obj) || isSlowBuffer(obj) || !!obj._isBuffer);
  };
  function isBuffer(obj) {
    return !!obj.constructor && typeof obj.constructor.isBuffer === "function" && obj.constructor.isBuffer(obj);
  }
  function isSlowBuffer(obj) {
    return typeof obj.readFloatLE === "function" && typeof obj.slice === "function" && isBuffer(obj.slice(0, 0));
  }
  (function() {
    var crypt2 = cryptExports, utf8 = charenc_1.utf8, isBuffer2 = isBuffer_1, bin = charenc_1.bin, md52 = function(message, options) {
      if (message.constructor == String)
        if (options && options.encoding === "binary")
          message = bin.stringToBytes(message);
        else
          message = utf8.stringToBytes(message);
      else if (isBuffer2(message))
        message = Array.prototype.slice.call(message, 0);
      else if (!Array.isArray(message) && message.constructor !== Uint8Array)
        message = message.toString();
      var m = crypt2.bytesToWords(message), l = message.length * 8, a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
      for (var i = 0; i < m.length; i++) {
        m[i] = (m[i] << 8 | m[i] >>> 24) & 16711935 | (m[i] << 24 | m[i] >>> 8) & 4278255360;
      }
      m[l >>> 5] |= 128 << l % 32;
      m[(l + 64 >>> 9 << 4) + 14] = l;
      var FF = md52._ff, GG = md52._gg, HH = md52._hh, II = md52._ii;
      for (var i = 0; i < m.length; i += 16) {
        var aa = a, bb = b, cc = c, dd = d;
        a = FF(a, b, c, d, m[i + 0], 7, -680876936);
        d = FF(d, a, b, c, m[i + 1], 12, -389564586);
        c = FF(c, d, a, b, m[i + 2], 17, 606105819);
        b = FF(b, c, d, a, m[i + 3], 22, -1044525330);
        a = FF(a, b, c, d, m[i + 4], 7, -176418897);
        d = FF(d, a, b, c, m[i + 5], 12, 1200080426);
        c = FF(c, d, a, b, m[i + 6], 17, -1473231341);
        b = FF(b, c, d, a, m[i + 7], 22, -45705983);
        a = FF(a, b, c, d, m[i + 8], 7, 1770035416);
        d = FF(d, a, b, c, m[i + 9], 12, -1958414417);
        c = FF(c, d, a, b, m[i + 10], 17, -42063);
        b = FF(b, c, d, a, m[i + 11], 22, -1990404162);
        a = FF(a, b, c, d, m[i + 12], 7, 1804603682);
        d = FF(d, a, b, c, m[i + 13], 12, -40341101);
        c = FF(c, d, a, b, m[i + 14], 17, -1502002290);
        b = FF(b, c, d, a, m[i + 15], 22, 1236535329);
        a = GG(a, b, c, d, m[i + 1], 5, -165796510);
        d = GG(d, a, b, c, m[i + 6], 9, -1069501632);
        c = GG(c, d, a, b, m[i + 11], 14, 643717713);
        b = GG(b, c, d, a, m[i + 0], 20, -373897302);
        a = GG(a, b, c, d, m[i + 5], 5, -701558691);
        d = GG(d, a, b, c, m[i + 10], 9, 38016083);
        c = GG(c, d, a, b, m[i + 15], 14, -660478335);
        b = GG(b, c, d, a, m[i + 4], 20, -405537848);
        a = GG(a, b, c, d, m[i + 9], 5, 568446438);
        d = GG(d, a, b, c, m[i + 14], 9, -1019803690);
        c = GG(c, d, a, b, m[i + 3], 14, -187363961);
        b = GG(b, c, d, a, m[i + 8], 20, 1163531501);
        a = GG(a, b, c, d, m[i + 13], 5, -1444681467);
        d = GG(d, a, b, c, m[i + 2], 9, -51403784);
        c = GG(c, d, a, b, m[i + 7], 14, 1735328473);
        b = GG(b, c, d, a, m[i + 12], 20, -1926607734);
        a = HH(a, b, c, d, m[i + 5], 4, -378558);
        d = HH(d, a, b, c, m[i + 8], 11, -2022574463);
        c = HH(c, d, a, b, m[i + 11], 16, 1839030562);
        b = HH(b, c, d, a, m[i + 14], 23, -35309556);
        a = HH(a, b, c, d, m[i + 1], 4, -1530992060);
        d = HH(d, a, b, c, m[i + 4], 11, 1272893353);
        c = HH(c, d, a, b, m[i + 7], 16, -155497632);
        b = HH(b, c, d, a, m[i + 10], 23, -1094730640);
        a = HH(a, b, c, d, m[i + 13], 4, 681279174);
        d = HH(d, a, b, c, m[i + 0], 11, -358537222);
        c = HH(c, d, a, b, m[i + 3], 16, -722521979);
        b = HH(b, c, d, a, m[i + 6], 23, 76029189);
        a = HH(a, b, c, d, m[i + 9], 4, -640364487);
        d = HH(d, a, b, c, m[i + 12], 11, -421815835);
        c = HH(c, d, a, b, m[i + 15], 16, 530742520);
        b = HH(b, c, d, a, m[i + 2], 23, -995338651);
        a = II(a, b, c, d, m[i + 0], 6, -198630844);
        d = II(d, a, b, c, m[i + 7], 10, 1126891415);
        c = II(c, d, a, b, m[i + 14], 15, -1416354905);
        b = II(b, c, d, a, m[i + 5], 21, -57434055);
        a = II(a, b, c, d, m[i + 12], 6, 1700485571);
        d = II(d, a, b, c, m[i + 3], 10, -1894986606);
        c = II(c, d, a, b, m[i + 10], 15, -1051523);
        b = II(b, c, d, a, m[i + 1], 21, -2054922799);
        a = II(a, b, c, d, m[i + 8], 6, 1873313359);
        d = II(d, a, b, c, m[i + 15], 10, -30611744);
        c = II(c, d, a, b, m[i + 6], 15, -1560198380);
        b = II(b, c, d, a, m[i + 13], 21, 1309151649);
        a = II(a, b, c, d, m[i + 4], 6, -145523070);
        d = II(d, a, b, c, m[i + 11], 10, -1120210379);
        c = II(c, d, a, b, m[i + 2], 15, 718787259);
        b = II(b, c, d, a, m[i + 9], 21, -343485551);
        a = a + aa >>> 0;
        b = b + bb >>> 0;
        c = c + cc >>> 0;
        d = d + dd >>> 0;
      }
      return crypt2.endian([a, b, c, d]);
    };
    md52._ff = function(a, b, c, d, x, s, t) {
      var n = a + (b & c | ~b & d) + (x >>> 0) + t;
      return (n << s | n >>> 32 - s) + b;
    };
    md52._gg = function(a, b, c, d, x, s, t) {
      var n = a + (b & d | c & ~d) + (x >>> 0) + t;
      return (n << s | n >>> 32 - s) + b;
    };
    md52._hh = function(a, b, c, d, x, s, t) {
      var n = a + (b ^ c ^ d) + (x >>> 0) + t;
      return (n << s | n >>> 32 - s) + b;
    };
    md52._ii = function(a, b, c, d, x, s, t) {
      var n = a + (c ^ (b | ~d)) + (x >>> 0) + t;
      return (n << s | n >>> 32 - s) + b;
    };
    md52._blocksize = 16;
    md52._digestsize = 16;
    md5$1.exports = function(message, options) {
      if (message === void 0 || message === null)
        throw new Error("Illegal argument " + message);
      var digestbytes = crypt2.wordsToBytes(md52(message, options));
      return options && options.asBytes ? digestbytes : options && options.asString ? bin.bytesToString(digestbytes) : crypt2.bytesToHex(digestbytes);
    };
  })();
  var md5Exports = md5$1.exports;
  const md5 = /* @__PURE__ */ getDefaultExportFromCjs(md5Exports);
  const MIXIN_KEY_ENC_TAB = [
    46,
    47,
    18,
    2,
    53,
    8,
    23,
    32,
    15,
    50,
    10,
    31,
    58,
    3,
    45,
    35,
    27,
    43,
    5,
    49,
    33,
    9,
    42,
    19,
    29,
    28,
    14,
    39,
    12,
    38,
    41,
    13,
    37,
    48,
    7,
    16,
    24,
    55,
    40,
    61,
    26,
    17,
    0,
    1,
    60,
    51,
    30,
    4,
    22,
    25,
    54,
    21,
    56,
    59,
    6,
    63,
    57,
    62,
    11,
    36,
    20,
    34,
    44,
    52
  ];
  let wbiKeys = null;
  const filterWbiValue = (value) => String(value).replace(/[!'()*]/g, "");
  const genMixinKey = (raw) => {
    let result = "";
    for (const i of MIXIN_KEY_ENC_TAB) {
      if (i < raw.length) result += raw[i];
    }
    return result.slice(0, 32);
  };
  const signWbi = (params, keys) => {
    const wts = Math.floor(now$2() / 1e3).toString();
    const withWts = { ...params, wts };
    const mixinKey = genMixinKey(`${keys.imgKey}${keys.subKey}`);
    const query = Object.entries(withWts).sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(filterWbiValue(value))}`).join("&");
    return { ...params, wts, w_rid: md5(query + mixinKey) };
  };
  const forward = async (client, url, { method, headers, body }) => {
    var _a, _b;
    const response = await client.fetch("/api/network/forwardProxy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url,
        method,
        headers: Object.entries(headers || {}).map(([key, value]) => ({ [key]: value })),
        payloadEncoding: "text",
        ...body ? { payload: body, contentType: headers["Content-Type"] || headers["content-type"] || "application/json" } : {}
      })
    });
    const result = JSON.parse(await response.text());
    if ((result == null ? void 0 : result.code) !== 0) throw new Error((result == null ? void 0 : result.msg) || "forward request failed");
    if (((_a = result.data) == null ? void 0 : _a.status) >= 400) throw new Error(`HTTP ${result.data.status}`);
    return ((_b = result.data) == null ? void 0 : _b.body) || "";
  };
  const fetchText = async (client, url, { cookie = "", headers = {}, method = "GET", body } = {}) => {
    const request = {
      method,
      headers: buildHeaders(cookie, headers),
      body
    };
    if (/^https?:\/\//i.test(url)) return forward(client, url, request);
    const response = await client.fetch(url, request);
    if ((response == null ? void 0 : response.status) && response.status >= 400) throw new Error(`HTTP ${response.status}`);
    return await response.text();
  };
  const fetchJson = async (client, url, options) => JSON.parse(await fetchText(client, url, options));
  const postFormJson = (client, url, data, { cookie = "", headers = {} } = {}) => fetchJson(client, url, {
    cookie,
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", ...headers },
    body: formBody(data)
  });
  const ensureWbiKeys = async (client, cookie) => {
    var _a, _b, _c;
    const nowSec = Math.floor(now$2() / 1e3);
    if (wbiKeys && nowSec - wbiKeys.fetchedAtEpochSec < 12 * 60 * 60) return wbiKeys;
    const json = await fetchJson(client, API.nav, { cookie });
    const wbi = ((_a = json == null ? void 0 : json.data) == null ? void 0 : _a.wbi_img) || {};
    wbiKeys = {
      imgKey: ((_b = String(wbi.img_url || "").split("/").pop()) == null ? void 0 : _b.split(".")[0]) || "",
      subKey: ((_c = String(wbi.sub_url || "").split("/").pop()) == null ? void 0 : _c.split(".")[0]) || "",
      fetchedAtEpochSec: nowSec
    };
    if (!wbiKeys.imgKey || !wbiKeys.subKey) throw new Error("Bilibili WBI key unavailable");
    return wbiKeys;
  };
  const signedWbiUrl = async (client, url, params, cookie) => withQuery(url, signWbi(params, await ensureWbiKeys(client, cookie)));
  const checkConnection$1 = async (client, payload) => {
    var _a;
    const cookie = ensureCookie(payload);
    const json = await fetchJson(client, API.nav, { cookie });
    if ((json == null ? void 0 : json.code) === -101 || (json == null ? void 0 : json.code) === -111 || ((_a = json.data) == null ? void 0 : _a.isLogin) === false) throw new Error("登录已过期");
    checkApiResponse(json, "获取用户信息失败");
    const d = json.data || {}, vip = d.vip || {}, level = d.level_info || {};
    const profile = {
      uid: d.mid,
      uname: d.uname,
      face: d.face || "",
      vipStatus: vip.status || 0,
      vipType: vip.type || 0,
      vipStatusText: vip.status === 1 ? vip.type === 2 ? "年度大会员" : "月度大会员" : "普通用户",
      level: level.current_level || 0,
      coins: typeof d.money === "number" ? d.money : typeof d.coins === "number" ? d.coins : 0,
      experience: level.current_exp || 0
    };
    return { connected: true, message: "连接成功", profile };
  };
  const createAccount = (userInfo, cookie) => ({
    id: `bilibili_${userInfo.uid || userInfo.mid}`,
    type: "bilibili",
    name: userInfo.uname,
    cookie,
    uid: String(userInfo.uid || userInfo.mid || ""),
    uname: userInfo.uname,
    face: userInfo.face,
    vipStatus: userInfo.vipStatus,
    vip_type: userInfo.vipType,
    level_info: { current_level: userInfo.level, current_exp: userInfo.experience },
    money: userInfo.coins,
    active: true
  });
  const extractQrCookie = (pollData) => {
    var _a, _b;
    const data = (pollData == null ? void 0 : pollData.data) || {};
    if ((_b = (_a = data.cookie_info) == null ? void 0 : _a.cookies) == null ? void 0 : _b.length) {
      return data.cookie_info.cookies.filter((item) => item.name && item.value).map((item) => `${item.name}=${encodeURIComponent(item.value)}`).join("; ");
    }
    const url = data.url || "";
    const params = new URL(url || "https://www.bilibili.com").searchParams;
    return ["SESSDATA", "bili_jct", "DedeUserID", "DedeUserID__ckMd5", "Expires"].filter((key) => params.get(key)).map((key) => `${key}=${encodeURIComponent(params.get(key))}`).join("; ");
  };
  const qrLogin = async (client) => {
    var _a, _b, _c;
    const json = await fetchJson(client, API.qrLogin, {});
    checkApiResponse(json, "生成二维码失败");
    const url = ((_a = json.data) == null ? void 0 : _a.url) || "";
    const key = ((_b = json.data) == null ? void 0 : _b.qrcode_key) || ((_c = json.data) == null ? void 0 : _c.auth_code) || "";
    if (!url || !key) throw new Error("二维码数据不完整");
    return {
      data: await browser.toDataURL(url, { width: 200, margin: 1, errorCorrectionLevel: "M" }),
      key,
      message: "请使用哔哩哔哩 App 扫码并确认登录"
    };
  };
  const qrPoll = async (client, payload) => {
    var _a;
    const key = String((payload == null ? void 0 : payload.key) || "");
    if (!key) throw new Error("missing qr key");
    const json = await fetchJson(client, withQuery(API.qrPoll, { qrcode_key: key }), {});
    const code = Number(((_a = json.data) == null ? void 0 : _a.code) ?? json.code);
    const messages = {
      86101: "等待扫码...",
      86090: "已扫码，请在手机端确认",
      86038: "二维码已失效，请刷新"
    };
    if (code !== 0) return { done: false, code, message: messages[code] || json.message || `状态：${code}` };
    const cookie = extractQrCookie(json);
    if (!cookie) throw new Error("未返回 Cookie");
    const profile = (await checkConnection$1(client, { cookie })).profile;
    return { done: true, code: 0, message: "登录成功", account: createAccount(profile, cookie) };
  };
  const driverState = /* @__PURE__ */ new Map();
  const stateKey = (cookie = "") => md5(String(cookie || "").slice(0, 4096));
  const getState = (cookie = "") => {
    const key = stateKey(cookie);
    if (!driverState.has(key)) driverState.set(key, { historyCursor: null, dynamicOffset: null, pgcState: {} });
    return driverState.get(key);
  };
  const proxyAssetUrl = (url = "") => {
    const value = String(url || "");
    if (!value) return "";
    return value.startsWith("//") ? `https:${value}` : value;
  };
  const createFolder = (id, name, size = 0, thumbnail = "") => ({
    id,
    name,
    title: name,
    path: `/${id}`.replace(/\/+/g, "/"),
    isDir: true,
    is_dir: true,
    type: "folder",
    source: "bilibili",
    sourcePath: `/${id}`.replace(/\/+/g, "/"),
    url: "#",
    size,
    created: now$2(),
    modified: now$2(),
    thumbnail: proxyAssetUrl(thumbnail)
  });
  const toMediaItem$1 = (file = {}, type = "video") => {
    const isDir = !!file.isDir || !!file.is_dir;
    const bvid = file.bvid || file.id || "";
    const sid = file.seasonId || file.season_id || file.id || "";
    const path = file.path || `/${type}/${type === "video" ? bvid : sid}`;
    const title = file.name || file.title || "";
    const base = {
      id: isDir ? `bilibili-folder-${file.id || path}` : `bilibili-${type === "video" ? bvid : sid}`,
      name: title,
      title,
      type: isDir ? "folder" : "video",
      source: "bilibili",
      sourcePath: path,
      path,
      url: isDir ? "#" : `bilibili://${path}`,
      originalUrl: isDir ? "#" : `bilibili://${path}`,
      thumbnail: proxyAssetUrl(file.thumbnail || file.coverUrl || file.pic || file.cover || ""),
      added: file.created || file.pubDate || file.pubdate || now$2(),
      duration: file.duration || file.durationSec || 0,
      size: file.size || 0,
      is_dir: isDir,
      isDir
    };
    if (isDir) return base;
    return {
      ...base,
      bvid: file.bvid,
      aid: file.aid,
      cid: file.cid,
      page: file.page,
      ownerName: file.ownerName,
      ownerMid: file.ownerMid,
      ownerFace: file.ownerFace,
      seasonTypeName: file.seasonTypeName || file.seasonType,
      seasonStyles: file.seasonStyles || file.styles,
      badge: file.badge,
      viewCount: file.view ?? file.viewCount,
      danmakuCount: file.danmaku ?? file.danmakuCount,
      likeCount: file.likeCount,
      coinCount: file.coinCount,
      favoriteCount: file.favoriteCount,
      shareCount: file.shareCount,
      replyCount: file.replyCount,
      pubDate: file.pubDate || file.pubdate,
      ctime: file.ctime,
      desc: file.desc,
      tname: file.tname,
      copyright: file.copyright,
      danmakuCid: file.danmakuCid || file.cid
    };
  };
  const toLiveItem = (room = {}) => ({
    id: `bilibili-live-${room.roomId || room.roomid}`,
    name: room.title || "",
    title: room.title || "",
    path: `live/${room.roomId || room.roomid}`,
    sourcePath: `live/${room.roomId || room.roomid}`,
    isDir: false,
    is_dir: false,
    size: 0,
    created: now$2(),
    modified: now$2(),
    source: "bilibili",
    thumbnail: proxyAssetUrl(room.cover || room.coverUrl || room.user_cover || ""),
    ownerName: room.uname || "",
    ownerMid: room.uid || room.mid,
    viewCount: room.online || 0,
    type: "video",
    url: `bilibili://live/${room.roomId || room.roomid}`,
    originalUrl: `bilibili://live/${room.roomId || room.roomid}`,
    _isLive: true,
    _liveRoomId: room.roomId || room.roomid,
    _liveTitle: room.title || "",
    _liveUname: room.uname || "",
    _liveOnline: room.online || 0,
    _liveArea: room.areaName || room.cate_name || "",
    _liveParentArea: room.parentAreaName || ""
  });
  const withPage = (items, hasMore, ps = 20) => Object.assign((items || []).slice(0, ps), { hasMore: !!hasMore });
  const parseVideoCard = (item = {}) => {
    var _a, _b, _c, _d, _e;
    return (item == null ? void 0 : item.bvid) ? {
      bvid: item.bvid,
      aid: item.aid,
      cid: item.cid,
      title: stripHtmlTags(item.title || ""),
      coverUrl: item.pic || item.cover || "",
      durationSec: item.duration || 0,
      ownerName: ((_a = item.owner) == null ? void 0 : _a.name) || item.author || "",
      ownerFace: (_b = item.owner) == null ? void 0 : _b.face,
      ownerMid: ((_c = item.owner) == null ? void 0 : _c.mid) || item.mid,
      view: ((_d = item.stat) == null ? void 0 : _d.view) ?? item.play,
      danmaku: ((_e = item.stat) == null ? void 0 : _e.danmaku) ?? item.video_review,
      pubDate: item.pubdate || item.ctime,
      pubDateText: item.pub_location
    } : null;
  };
  const parseVideoCards = (items = []) => items.map(parseVideoCard).filter(Boolean);
  const parseVideoInfo = (d = {}) => ({
    bvid: d.bvid,
    aid: d.aid,
    title: d.title || "",
    pic: d.pic || "",
    desc: d.desc || "",
    tname: d.tname || "",
    copyright: d.copyright || 0,
    pubdate: d.pubdate || 0,
    ctime: d.ctime || 0,
    owner: d.owner || {},
    stat: d.stat || {},
    duration: d.duration || 0,
    pages: d.pages || [],
    ugc_season: d.ugc_season
  });
  const fetchView = async (client, cookie, bvid = "", aid = 0) => {
    const json = await fetchJson(client, withQuery(API.view, bvid ? { bvid } : { aid }), { cookie });
    checkApiResponse(json, "get video info failed");
    return parseVideoInfo(json.data || {});
  };
  const rootMenu = () => [
    ["popular", "热门视频"],
    ["recommend", "推荐视频"],
    ["zone", "分区视频"],
    ["bangumi", "番剧"],
    ["cinema", "影视"],
    ["dynamic", "动态"],
    ["live", "直播"],
    ["my", "我的"]
  ].map(([id, name]) => createFolder(id, name));
  const myMenu = () => [
    ["my/favorite", "收藏夹"],
    ["my/history", "历史记录"],
    ["my/bangumi", "追番"],
    ["my/drama", "追剧"],
    ["my/watchlater", "稍后再看"],
    ["my/like", "点赞"]
  ].map(([id, name]) => createFolder(id, name));
  const parsePath = (path = "") => {
    const pageMatch = String(path).match(/[?&]page=(\d+)/);
    return {
      page: pageMatch ? parseInt(pageMatch[1], 10) || 1 : 1,
      cleanPath: (pageMatch ? String(path).replace(/\?.*$/, "") : String(path)).replace(/^\/|\/$/g, "") || "root"
    };
  };
  const listHistory = async (client, cookie, page, ps) => {
    var _a, _b;
    const state = getState(cookie);
    if (page === 1) state.historyCursor = null;
    const cursor = state.historyCursor || {};
    const json = await fetchJson(client, withQuery(API.historyCursor, {
      max: cursor.max || 0,
      view_at: cursor.viewAt || cursor.view_at || 0,
      ps,
      type: "archive"
    }), { cookie });
    checkApiResponse(json, "get history failed");
    state.historyCursor = ((_a = json.data) == null ? void 0 : _a.cursor) || null;
    return withPage(parseVideoCards(((_b = json.data) == null ? void 0 : _b.list) || []).map((v) => toMediaItem$1(v)), !!state.historyCursor, ps);
  };
  const listDynamic = async (client, cookie, page, ps) => {
    var _a, _b;
    const state = getState(cookie);
    if (page === 1) state.dynamicOffset = null;
    const json = await fetchJson(client, withQuery(API.dynamicAllVideo, {
      type: "video",
      offset: state.dynamicOffset || "",
      timezone_offset: "-480"
    }), { cookie });
    checkApiResponse(json, "get dynamic failed");
    state.dynamicOffset = ((_a = json.data) == null ? void 0 : _a.offset) || "";
    const items = (((_b = json.data) == null ? void 0 : _b.items) || []).map((item) => {
      var _a2, _b2, _c;
      return (_c = (_b2 = (_a2 = item == null ? void 0 : item.modules) == null ? void 0 : _a2.module_dynamic) == null ? void 0 : _b2.major) == null ? void 0 : _c.archive;
    }).filter(Boolean).map((archive) => toMediaItem$1(parseVideoCard({
      bvid: archive.bvid,
      aid: archive.aid,
      title: archive.title,
      pic: archive.cover,
      duration: archive.duration,
      owner: archive.author,
      stat: archive.stat,
      pubdate: archive.pub_ts
    })));
    return withPage(items, !!state.dynamicOffset, ps);
  };
  const listPopular = async (client, cookie, page, ps) => {
    var _a, _b;
    const json = await fetchJson(client, withQuery(API.popular, { pn: page, ps }), { cookie });
    checkApiResponse(json, "get popular failed");
    return withPage(parseVideoCards(((_a = json.data) == null ? void 0 : _a.list) || []).map((v) => toMediaItem$1(v)), !((_b = json.data) == null ? void 0 : _b.no_more), ps);
  };
  const listRecommend = async (client, cookie, page, ps) => {
    var _a;
    const url = await signedWbiUrl(client, API.recommend, { ps, fresh_idx: page, fresh_idx_1h: page, fetch_row: "1", feed_version: "V8" }, cookie);
    const json = await fetchJson(client, url, { cookie });
    return withPage(parseVideoCards(((_a = json.data) == null ? void 0 : _a.item) || []).map((v) => toMediaItem$1(v)), true, ps);
  };
  const listZone = async (client, cookie, id, page, ps) => {
    var _a, _b;
    if (!id) return [
      [1, "动画"],
      [3, "音乐"],
      [129, "舞蹈"],
      [4, "游戏"],
      [36, "知识"],
      [188, "科技"],
      [160, "生活"],
      [211, "美食"],
      [217, "动物圈"],
      [119, "鬼畜"],
      [155, "时尚"],
      [5, "娱乐"],
      [181, "影视"]
    ].map(([zid, name]) => createFolder(`zone/${zid}`, name));
    const json = await fetchJson(client, withQuery(API.regionLatest, { rid: id, pn: page, ps }), { cookie });
    checkApiResponse(json, "get region failed");
    const pageInfo = ((_a = json.data) == null ? void 0 : _a.page) || {};
    const total = pageInfo.count || 0;
    return withPage(parseVideoCards(((_b = json.data) == null ? void 0 : _b.archives) || []).map((v) => toMediaItem$1(v)), total ? (pageInfo.num || page) * (pageInfo.size || ps) < total : true, ps);
  };
  const listPgc = async (client, cookie, type, page, ps) => {
    var _a, _b, _c, _d;
    const json = await fetchJson(client, withQuery(type === "bangumi" ? API.pgcBangumiPage : API.pgcCinemaPage, {
      season_type: type === "bangumi" ? 1 : 2,
      type: 1,
      sort: 0,
      page,
      pagesize: ps
    }), { cookie });
    const items = (((_a = json.data) == null ? void 0 : _a.list) || ((_b = json.result) == null ? void 0 : _b.list) || []).map((item) => toMediaItem$1({
      seasonId: item.season_id || item.seasonId,
      title: item.title,
      coverUrl: item.cover,
      badge: item.badge,
      seasonType: item.season_type_name,
      path: `/bangumi/${item.season_id || item.seasonId}`
    }, "bangumi")).filter((item) => item.sourcePath !== "/bangumi/undefined");
    const total = ((_c = json.data) == null ? void 0 : _c.total) || ((_d = json.result) == null ? void 0 : _d.total) || 0;
    return withPage(items, total ? page * ps < total : items.length >= ps, ps);
  };
  const listMy = async (client, cookie, id, page, ps, account = {}) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    const uid = currentUid(cookie, account.uid);
    if (!id) return myMenu();
    if (id === "history") return listHistory(client, cookie, page, ps);
    if (id === "watchlater") {
      const json = await fetchJson(client, API.toView, { cookie });
      checkApiResponse(json, "get watch later failed");
      return (((_a = json.data) == null ? void 0 : _a.list) || []).map((v) => toMediaItem$1(parseVideoCard(v))).filter(Boolean);
    }
    if (id === "like") {
      const json = await fetchJson(client, withQuery(API.likeVideo, { vmid: uid, pn: page, ps }), { cookie });
      checkApiResponse(json, "get liked videos failed");
      return withPage(parseVideoCards(((_b = json.data) == null ? void 0 : _b.list) || []).map((v) => toMediaItem$1(v)), (((_d = (_c = json.data) == null ? void 0 : _c.page) == null ? void 0 : _d.count) || 0) > page * ps, ps);
    }
    if (id === "bangumi" || id === "drama") {
      const json = await fetchJson(client, withQuery(API.pgcFollowList, { vmid: uid, type: id === "bangumi" ? 1 : 2, pn: page, ps, follow_status: 0 }), { cookie });
      checkApiResponse(json, "get pgc follow failed");
      return withPage((((_e = json.data) == null ? void 0 : _e.list) || []).map((b) => toMediaItem$1({
        seasonId: b.season_id,
        title: b.title,
        coverUrl: b.cover,
        path: `/bangumi/${b.season_id}`
      }, "bangumi")), (((_f = json.data) == null ? void 0 : _f.total) || 0) > page * ps, ps);
    }
    if (id === "favorite") {
      const json = await fetchJson(client, withQuery(API.favFolders, { up_mid: uid, type: 2, web_location: "333.1387" }), { cookie });
      checkApiResponse(json, "get favorite folders failed");
      return (((_g = json.data) == null ? void 0 : _g.list) || []).map((f) => createFolder(`my/favorite/${f.id}`, f.title, f.media_count, f.cover));
    }
    if (id.startsWith("favorite/")) {
      const mediaId = id.replace("favorite/", "");
      const json = await fetchJson(client, withQuery(API.favResources, { media_id: mediaId, pn: page, ps, keyword: "", order: "mtime", type: 0, tid: 0, platform: "web" }), { cookie });
      checkApiResponse(json, "get favorite resources failed");
      return withPage(parseVideoCards(((_h = json.data) == null ? void 0 : _h.medias) || []).map((v) => toMediaItem$1(v)), !!((_i = json.data) == null ? void 0 : _i.has_more), ps);
    }
    return [];
  };
  const listUser = async (client, cookie, id, page, ps) => {
    var _a, _b, _c;
    const mid = parseInt(id, 10);
    if (!mid) return [];
    const url = await signedWbiUrl(client, API.spaceArcSearch, { mid, pn: page, ps, index: 1, order: "pubdate" }, cookie);
    const json = await fetchJson(client, url, { cookie });
    checkApiResponse(json, "get user videos failed");
    const pageInfo = ((_a = json.data) == null ? void 0 : _a.page) || {};
    return withPage(parseVideoCards(((_c = (_b = json.data) == null ? void 0 : _b.list) == null ? void 0 : _c.vlist) || []).map((v) => toMediaItem$1(v)), (pageInfo.count || 0) > page * ps, ps);
  };
  const listLive = async (client, cookie, id, page, ps) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    if (!id) return [
      ["live/following", "关注主播"],
      ["live/recommend", "推荐直播"],
      ["live/area", "直播分区"]
    ].map(([key, name]) => createFolder(key, name));
    if (id === "following") {
      const json = await fetchJson(client, withQuery(API.liveFollowing, { page, page_size: ps }), { cookie, headers: { Referer: "https://live.bilibili.com/" } });
      checkApiResponse(json, "get live following failed");
      const list = ((_a = json.data) == null ? void 0 : _a.list) || ((_b = json.data) == null ? void 0 : _b.rooms) || [];
      return withPage(list.map((room) => toLiveItem({
        roomId: room.roomid || room.room_id,
        uid: room.uid,
        title: room.title,
        uname: room.uname,
        cover: room.face || room.cover_from_user || room.keyframe,
        online: room.online,
        areaName: room.area_name
      })), !!((_c = json.data) == null ? void 0 : _c.has_more), ps);
    }
    if (id === "recommend") {
      const json = await fetchJson(client, withQuery(page <= 1 ? API.liveRecommendIndex : API.liveRecommendMore, { platform: "web", page }), { cookie, headers: { Referer: "https://live.bilibili.com/" } });
      const rooms = (((_d = json.data) == null ? void 0 : _d.recommend_room_list) || ((_e = json.data) == null ? void 0 : _e.list) || ((_f = json.data) == null ? void 0 : _f.card_list) || []).flatMap((item) => (item == null ? void 0 : item.list) || (item == null ? void 0 : item.rooms) || item || []);
      return withPage(rooms.map((room) => toLiveItem({
        roomId: room.roomid || room.room_id,
        uid: room.uid,
        title: room.title,
        uname: room.uname,
        cover: room.cover || room.keyframe,
        online: room.online,
        areaName: room.area_name
      })), rooms.length > 0 && page < 8, ps);
    }
    if (id === "area") {
      const json = await fetchJson(client, API.liveAreaList, { cookie, headers: { Referer: "https://live.bilibili.com/" } });
      checkApiResponse(json, "get live areas failed");
      return (((_g = json.data) == null ? void 0 : _g.data) || json.data || []).map((p) => createFolder(`live/area/${p.id}`, p.name));
    }
    if (id.startsWith("area/")) {
      const [, parentId, childId] = id.split("/");
      const areas = await fetchJson(client, API.liveAreaList, { cookie, headers: { Referer: "https://live.bilibili.com/" } }).catch(() => ({}));
      if (!childId) {
        const parent = (((_h = areas.data) == null ? void 0 : _h.data) || areas.data || []).find((area) => String(area.id) === String(parentId));
        return ((parent == null ? void 0 : parent.list) || (parent == null ? void 0 : parent.children) || []).map((c) => createFolder(`live/area/${parentId}/${c.id}`, c.name));
      }
      const json = await fetchJson(client, withQuery(API.liveAreaRooms, { platform: "web", parent_area_id: parentId, area_id: childId, page, sort_type: "" }), { cookie, headers: { Referer: "https://live.bilibili.com/" } });
      const rooms = ((_i = json.data) == null ? void 0 : _i.list) || [];
      return withPage(rooms.map((room) => toLiveItem({
        roomId: room.roomid || room.room_id,
        uid: room.uid,
        title: room.title,
        uname: room.uname,
        cover: room.cover || room.keyframe,
        online: room.online,
        areaName: room.area_name
      })), rooms.length >= ps, ps);
    }
    return [];
  };
  const listDirectory$1 = async (client, payload) => {
    const cookie = ensureCookie(payload);
    const account = (payload == null ? void 0 : payload.account) || {};
    const { page, cleanPath } = parsePath((payload == null ? void 0 : payload.path) || "root");
    const [type, ...rest] = cleanPath.split("/");
    const id = rest.join("/");
    const ps = Math.max(1, Math.min(50, Number((payload == null ? void 0 : payload.pageSize) || 20)));
    if (type === "root") return rootMenu();
    if (type === "history") return listHistory(client, cookie, page, ps);
    if (type === "popular") return listPopular(client, cookie, page, ps);
    if (type === "recommend") return listRecommend(client, cookie, page, ps);
    if (type === "zone") return listZone(client, cookie, id, page, ps);
    if (type === "bangumi" || type === "cinema") return listPgc(client, cookie, type, page, ps);
    if (type === "dynamic") return listDynamic(client, cookie, page, ps);
    if (type === "my") return listMy(client, cookie, id, page, ps, account);
    if (type === "user") return listUser(client, cookie, id, page, ps);
    if (type === "live") return listLive(client, cookie, id, page, ps);
    return [];
  };
  const mpdCache = /* @__PURE__ */ new Map();
  const parseStream = (item) => {
    var _a, _b, _c, _d;
    return {
      id: item.id,
      baseUrl: item.baseUrl || item.base_url,
      codecs: item.codecs || "",
      bandwidth: item.bandwidth || 0,
      width: item.width || 0,
      height: item.height || 0,
      mimeType: item.mimeType || item.mime_type || "",
      segmentBase: {
        initialization: ((_a = item.segment_base) == null ? void 0 : _a.initialization) || ((_b = item.segmentBase) == null ? void 0 : _b.initialization) || "",
        indexRange: ((_c = item.segment_base) == null ? void 0 : _c.index_range) || ((_d = item.segmentBase) == null ? void 0 : _d.indexRange) || ""
      }
    };
  };
  const parsePlayUrl = (data) => {
    var _a, _b;
    const supportFormats = data.support_formats || [];
    return {
      quality: data.quality,
      acceptQuality: data.accept_quality || supportFormats.map((item) => item.quality).filter(Boolean),
      acceptDescription: data.accept_description || supportFormats.map((item) => item.new_description || item.display_desc || `${item.quality}P`),
      dash: data.dash ? {
        duration: data.dash.duration || 3600,
        video: (data.dash.video || []).map(parseStream),
        audio: [
          ...data.dash.audio || [],
          ...((_a = data.dash.dolby) == null ? void 0 : _a.audio) || [],
          ...((_b = data.dash.flac) == null ? void 0 : _b.audio) ? [data.dash.flac.audio] : []
        ].map(parseStream)
      } : null,
      durl: (data.durl || []).map((item) => ({ url: item.url, size: item.size, length: item.length }))
    };
  };
  const parseSubtitles = (data) => {
    var _a;
    return (((_a = data == null ? void 0 : data.subtitle) == null ? void 0 : _a.subtitles) || []).map((item) => {
      var _a2;
      return {
        lan: item.lan || "",
        lanDoc: item.lan_doc || item.lan || "",
        url: ((_a2 = item.subtitle_url) == null ? void 0 : _a2.startsWith("//")) ? `https:${item.subtitle_url}` : item.subtitle_url || ""
      };
    }).filter((item) => item.url);
  };
  const proxiedUrl = (url = "") => `${PRIVATE_BASE}/api/bilibili/proxy?url=${encodeURIComponent(url)}`;
  const resolvePlayParams = async (client, path, cookie) => {
    var _a, _b, _c;
    const cleanPath = String(path || "").replace(/^bilibili:\/\//, "");
    const page = parseInt(((_a = cleanPath.match(/[?&]p=(\d+)/)) == null ? void 0 : _a[1]) || "1", 10) || 1;
    const plainPath = cleanPath.replace(/[?&]p=\d+/, "").replace(/[?&]$/, "");
    if (plainPath.startsWith("live/")) return { isLive: true, roomId: parseInt(plainPath.replace("live/", ""), 10) };
    if (plainPath.includes("|")) {
      const parts = Object.fromEntries(plainPath.split("|").map((part) => part.split(":")));
      return {
        bvid: parts.bvid || "",
        cid: parseInt(parts.cid, 10) || 0,
        page: parseInt(parts.page, 10) || 1,
        epid: parts.epid ? parseInt(parts.epid, 10) : void 0
      };
    }
    const videoMatch = plainPath.match(/^\/?video\/(.+)/);
    if (videoMatch) {
      const json = await fetchJson(client, withQuery(API.view, { bvid: videoMatch[1] }), { cookie });
      checkApiResponse(json, "get video info failed");
      const pages = ((_b = json.data) == null ? void 0 : _b.pages) || [];
      const current = pages.find((item) => item.page === page) || pages[page - 1] || pages[0];
      if (!current) throw new Error("video page not found");
      return { bvid: videoMatch[1], cid: current.cid, page: current.page || page };
    }
    const bangumiMatch = plainPath.match(/^\/?bangumi\/(\d+)/);
    if (bangumiMatch) {
      const json = await fetchJson(client, withQuery(API.pgcSeason, { season_id: bangumiMatch[1] }), { cookie });
      checkApiResponse(json, "get bangumi detail failed");
      const episodes = ((_c = json.result) == null ? void 0 : _c.episodes) || [];
      const current = episodes[page - 1] || episodes[0];
      if (!current) throw new Error("episode not found");
      return { bvid: current.bvid || "", cid: current.cid, page, epid: current.id, seasonId: Number(bangumiMatch[1]) };
    }
    throw new Error(`invalid bilibili path: ${path}`);
  };
  const fetchPlayerInfo = async (client, params, cookie) => {
    if (!params.bvid || !params.cid) return {};
    try {
      const url = await signedWbiUrl(client, API.playerInfo, { bvid: params.bvid, cid: String(params.cid) }, cookie);
      const json = await fetchJson(client, url, { cookie, headers: { Referer: "https://www.bilibili.com", "X-Blbl-Skip-Origin": "1" } });
      checkApiResponse(json, "get player info failed");
      return { subtitles: parseSubtitles(json.data || {}) };
    } catch {
      return {};
    }
  };
  const fetchPlayUrl = async (client, params, cookie) => {
    if (params.epid) {
      const json2 = await fetchJson(client, withQuery(API.pgcPlayUrl, {
        ep_id: params.epid,
        cid: params.cid,
        qn: 127,
        fnval: 4048,
        fnver: 0,
        fourk: 1
      }), { cookie });
      checkApiResponse(json2, "get pgc play url failed");
      return parsePlayUrl(json2.result || json2.data || {});
    }
    const url = await signedWbiUrl(client, API.playUrl, {
      bvid: params.bvid,
      cid: String(params.cid),
      qn: "127",
      fnval: "4048",
      fnver: "0",
      fourk: "1"
    }, cookie);
    const json = await fetchJson(client, url, { cookie });
    checkApiResponse(json, "get play url failed");
    return parsePlayUrl(json.data || {});
  };
  const fetchLive = async (client, roomId, cookie) => {
    var _a, _b;
    const json = await fetchJson(client, withQuery(API.livePlayInfo, {
      room_id: roomId,
      protocol: "0,1",
      format: "0,1,2",
      codec: "0,1",
      qn: "10000",
      platform: "web",
      ptype: "8"
    }), { cookie, headers: { Referer: `https://live.bilibili.com/${roomId}` } });
    checkApiResponse(json, "get live play url failed");
    const playurl = ((_b = (_a = json.data) == null ? void 0 : _a.playurl_info) == null ? void 0 : _b.playurl) || {};
    const lines = [];
    for (const stream of playurl.stream || []) {
      for (const format of stream.format || []) {
        for (const codec of format.codec || []) {
          for (const info of codec.url_info || []) {
            if (codec.base_url && info.host) lines.push(info.host + codec.base_url + (info.extra || ""));
          }
        }
      }
    }
    return lines[0] || "";
  };
  const resolvePlayback$1 = async (client, payload) => {
    var _a, _b, _c;
    const cookie = String((payload == null ? void 0 : payload.cookie) || "");
    const path = String((payload == null ? void 0 : payload.path) || "");
    if (!cookie) throw new Error("missing bilibili cookie");
    const params = await resolvePlayParams(client, path, cookie);
    if (params.isLive) {
      const url = proxiedUrl(await fetchLive(client, params.roomId, cookie));
      return {
        url,
        qualities: [{ default: true, html: "直播", url, extra: { isLive: true, roomId: params.roomId } }],
        runtime: {}
      };
    }
    const [playUrl, playerInfo] = await Promise.all([
      fetchPlayUrl(client, params, cookie),
      fetchPlayerInfo(client, params, cookie)
    ]);
    return {
      url: ((_a = qualities[0]) == null ? void 0 : _a.url) || proxiedUrl(((_c = (_b = playUrl.durl) == null ? void 0 : _b[0]) == null ? void 0 : _c.url) || ""),
      qualities,
      runtime: {
        danmakuCid: params.cid ? String(params.cid) : "",
        danmakuBvid: params.cid ? params.bvid : "",
        subtitleBvid: params.cid ? params.bvid : "",
        subtitleCid: params.cid ? String(params.cid) : ""
      }
    };
  };
  const getCachedMpd = (key) => {
    const cached = mpdCache.get(key);
    if (!cached || cached.expiresAt < now$2()) {
      mpdCache.delete(key);
      return null;
    }
    return cached.mpd;
  };
  const createMediaItemFromPath$1 = async (client, payload) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
    const cookie = ensureCookie(payload);
    const path = String((payload == null ? void 0 : payload.path) || "");
    const params = await resolvePlayParams(client, path, cookie);
    if (params.isLive) {
      const roomJson = await fetchJson(client, withQuery(API.liveRoomInfo, { room_id: params.roomId }), { cookie, headers: { Referer: `https://live.bilibili.com/${params.roomId}` } }).catch(() => ({}));
      const room = roomJson.data || {};
      return toLiveItem({
        roomId: params.roomId,
        uid: room.uid,
        title: room.title || `直播 ${params.roomId}`,
        uname: room.uname || ((_b = (_a = room.anchor_info) == null ? void 0 : _a.base_info) == null ? void 0 : _b.uname),
        cover: room.user_cover || room.keyframe,
        online: room.online,
        areaName: room.area_name
      });
    }
    const info = await fetchView(client, cookie, params.bvid);
    const page = info.pages.find((item) => item.page === params.page || item.cid === params.cid) || info.pages[0] || {};
    return toMediaItem$1({
      ...info,
      bvid: params.bvid,
      cid: page.cid || params.cid,
      page: page.page || params.page,
      duration: page.duration || info.duration,
      path,
      title: info.pages.length > 1 ? `${info.title} - ${page.part || `P${params.page}`}` : info.title,
      ownerName: (_c = info.owner) == null ? void 0 : _c.name,
      ownerMid: (_d = info.owner) == null ? void 0 : _d.mid,
      ownerFace: (_e = info.owner) == null ? void 0 : _e.face,
      viewCount: (_f = info.stat) == null ? void 0 : _f.view,
      danmakuCount: (_g = info.stat) == null ? void 0 : _g.danmaku,
      likeCount: (_h = info.stat) == null ? void 0 : _h.like,
      coinCount: (_i = info.stat) == null ? void 0 : _i.coin,
      favoriteCount: (_j = info.stat) == null ? void 0 : _j.favorite,
      shareCount: (_k = info.stat) == null ? void 0 : _k.share,
      replyCount: (_l = info.stat) == null ? void 0 : _l.reply,
      danmakuCid: page.cid || params.cid,
      ...(payload == null ? void 0 : payload.timeParams) || {},
      isLoop: ((_m = payload == null ? void 0 : payload.timeParams) == null ? void 0 : _m.endTime) !== void 0
    });
  };
  const loadEpisodes = async (client, payload) => {
    var _a, _b, _c;
    const cookie = ensureCookie(payload);
    const path = String((payload == null ? void 0 : payload.path) || "");
    if (path.startsWith("/bangumi/")) {
      const seasonId = parseInt(path.replace("/bangumi/", ""), 10);
      const json = await fetchJson(client, withQuery(API.pgcSeason, { season_id: seasonId }), { cookie });
      checkApiResponse(json, "get bangumi detail failed");
      const episodes = ((_a = json.result) == null ? void 0 : _a.episodes) || [];
      return {
        pages: episodes.map((ep) => ({
          title: `${ep.title || ""}${ep.long_title ? ` - ${ep.long_title}` : ""}`.trim(),
          path: `bvid:${ep.bvid || ""}|cid:${ep.cid}|page:1|epid:${ep.id}`,
          bvid: ep.bvid || "",
          cid: ep.cid,
          page: 1,
          duration: ep.duration || 0,
          thumbnail: proxyAssetUrl(ep.cover),
          epid: ep.id,
          selected: false
        }))
      };
    }
    const params = await resolvePlayParams(client, path, cookie);
    const info = await fetchView(client, cookie, params.bvid);
    const seasonItems = (((_b = info.ugc_season) == null ? void 0 : _b.sections) || []).flatMap((section) => (section.episodes || []).map((ep) => {
      var _a2;
      const arc = ep.arc || {};
      const bvid = (ep.bvid || arc.bvid || "").trim();
      const cid = ep.cid || arc.cid || 0;
      const page = arc.page || 1;
      return bvid ? {
        title: (ep.title || arc.title || "").trim() || "未命名",
        path: `bvid:${bvid}|cid:${cid}|page:${page}`,
        bvid,
        cid,
        page,
        duration: arc.duration || 0,
        thumbnail: proxyAssetUrl(arc.pic || ""),
        viewCount: ((_a2 = arc.stat) == null ? void 0 : _a2.view) || 0,
        selected: bvid === params.bvid && cid === params.cid && page === params.page
      } : null;
    }).filter(Boolean));
    return {
      pages: info.pages.length > 1 ? info.pages.map((p) => {
        var _a2;
        return {
          title: ((_a2 = p.part) == null ? void 0 : _a2.trim()) ? `P${p.page} ${p.part}` : `P${p.page}`,
          path: `bvid:${params.bvid}|cid:${p.cid}|page:${p.page}`,
          bvid: params.bvid,
          cid: p.cid,
          page: p.page,
          duration: p.duration,
          thumbnail: proxyAssetUrl(p.first_frame || ""),
          selected: p.page === params.page
        };
      }) : void 0,
      season: seasonItems.length ? { title: ((_c = info.ugc_season) == null ? void 0 : _c.title) || "合集", items: seasonItems } : void 0
    };
  };
  const mapSearchVideo = (item) => ({
    ...toMediaItem$1({
      bvid: item.bvid || "",
      aid: item.aid,
      title: stripHtmlTags(item.title || ""),
      coverUrl: item.pic ? String(item.pic).startsWith("//") ? `https:${item.pic}` : item.pic : "",
      durationSec: parseDuration(item.duration),
      ownerName: item.author || "",
      ownerMid: item.mid,
      view: item.play,
      danmaku: item.video_review,
      pubDate: item.pubdate,
      path: `/video/${item.bvid}`
    }),
    artist: item.author || "",
    album: "BBLL"
  });
  const mapSearchBangumi = (item, album = "番剧") => {
    var _a, _b;
    return {
      ...toMediaItem$1({
        seasonId: item.season_id || item.pgc_season_id,
        title: stripHtmlTags(item.title || ""),
        coverUrl: item.cover,
        badge: item.angle_title || ((_b = (_a = item.display_info) == null ? void 0 : _a[0]) == null ? void 0 : _b.text),
        seasonType: item.season_type_name,
        path: `/bangumi/${item.season_id || item.pgc_season_id}`
      }, "bangumi"),
      album: item.season_type_name || album
    };
  };
  const mapSearchLive = (item) => ({
    ...toLiveItem({
      roomId: item.roomid,
      uid: item.uid || item.mid,
      title: stripHtmlTags(item.title || ""),
      uname: stripHtmlTags(item.uname || ""),
      cover: item.user_cover || item.cover,
      online: item.online || 0,
      areaName: item.cate_name
    }),
    artist: stripHtmlTags(item.uname || ""),
    album: item.cate_name || "直播"
  });
  const mapSearchUser = (item) => ({
    id: `bilibili-user-${item.mid}`,
    name: item.uname || "",
    title: item.uname || "",
    type: "folder",
    source: "bilibili",
    sourcePath: `/user/${item.mid}`,
    localPath: `/user/${item.mid}/`,
    path: `/user/${item.mid}`,
    url: "#",
    thumbnail: item.upic ? String(item.upic).startsWith("//") ? `https:${item.upic}` : item.upic : "",
    artist: item.usign || "",
    album: "用户",
    added: now$2(),
    size: 0,
    isDir: true,
    is_dir: true
  });
  const searchOne = async (client, cookie, keyword, page, type) => {
    var _a, _b, _c, _d;
    if (!keyword.trim() && type !== "hints") return { items: [], page, hasMore: false };
    if (type === "user") {
      const json2 = await fetchJson(client, withQuery(API.searchType, { search_type: "bili_user", keyword, page }), { cookie });
      checkApiResponse(json2, "user search failed");
      return { items: (((_a = json2.data) == null ? void 0 : _a.result) || []).map(mapSearchUser), page, hasMore: (((_b = json2.data) == null ? void 0 : _b.numPages) || 0) > page };
    }
    const searchType = type === "bangumi" ? "media_bangumi" : type === "media" ? "media_ft" : type === "live" ? "live_room" : "video";
    const url = await signedWbiUrl(client, API.searchTypeWbi, { search_type: searchType, keyword, page, order: type === "live" ? "online" : "totalrank" }, cookie);
    const json = await fetchJson(client, url, { cookie });
    checkApiResponse(json, `${type} search failed`);
    const result = ((_c = json.data) == null ? void 0 : _c.result) || [];
    const mapper = type === "bangumi" ? (item) => mapSearchBangumi(item, "番剧") : type === "media" ? (item) => mapSearchBangumi(item, "影视") : type === "live" ? mapSearchLive : mapSearchVideo;
    return { items: result.map(mapper).filter((item) => (item == null ? void 0 : item.id) && (item == null ? void 0 : item.title)), page, hasMore: (((_d = json.data) == null ? void 0 : _d.numPages) || 0) > page };
  };
  const searchAll$1 = async (client, payload) => {
    const cookie = String((payload == null ? void 0 : payload.cookie) || "");
    const keyword = String((payload == null ? void 0 : payload.keyword) || "");
    const page = Math.max(1, Number((payload == null ? void 0 : payload.page) || 1));
    const type = String((payload == null ? void 0 : payload.type) || "all");
    if (type !== "all") return searchOne(client, cookie, keyword, page, type);
    const empty = { items: [], page, hasMore: false };
    const [video, bangumi, media, live] = await Promise.all([
      searchOne(client, cookie, keyword, page, "video").catch(() => empty),
      searchOne(client, cookie, keyword, page, "bangumi").catch(() => empty),
      searchOne(client, cookie, keyword, page, "media").catch(() => empty),
      searchOne(client, cookie, keyword, page, "live").catch(() => empty)
    ]);
    return { items: [...video.items, ...bangumi.items, ...media.items, ...live.items], page, hasMore: video.hasMore || bangumi.hasMore || media.hasMore || live.hasMore };
  };
  const searchHints = async (client, payload) => {
    var _a;
    const cookie = String((payload == null ? void 0 : payload.cookie) || "");
    const keyword = String((payload == null ? void 0 : payload.keyword) || "");
    if (keyword.trim()) {
      const json2 = await fetchJson(client, withQuery(API.searchSuggest, { term: keyword, main_ver: "v1", func: "suggest", suggest_type: "accurate", sub_type: "tag" }), { cookie });
      return (((_a = json2.result) == null ? void 0 : _a.tag) || []).map((item) => item.value || item.term || "").filter(Boolean);
    }
    const json = await fetchJson(client, API.searchHotword, { cookie });
    return (json.list || []).slice(0, 8).map((item) => item.keyword || "").filter(Boolean);
  };
  const resolveSocialVideo = async (client, cookie, item = {}) => {
    const bvid = String((item == null ? void 0 : item.bvid) || "").trim();
    const aid = Number((item == null ? void 0 : item.aid) || (bvid ? (await fetchView(client, cookie, bvid)).aid : 0));
    if (!bvid && !aid) throw new Error("缺少视频标识");
    return { bvid, aid };
  };
  const payloadId = (bvid, aid) => bvid ? { bvid } : { aid };
  const socialAction = async (client, payload) => {
    var _a, _b;
    const cookie = ensureCookie(payload);
    const action = String((payload == null ? void 0 : payload.action) || "");
    const { bvid, aid } = await resolveSocialVideo(client, cookie, (payload == null ? void 0 : payload.item) || {});
    const csrf = csrfOf(cookie);
    if (!csrf) throw new Error("缺少 bili_jct");
    if (action === "like") {
      const json = await postFormJson(client, API.socialLike, { ...payloadId(bvid, aid), like: 1, csrf }, { cookie, headers: { Referer: "https://www.bilibili.com" } });
      checkApiResponse(json, "点赞操作失败");
      return true;
    }
    if (action === "coin") {
      const state = await fetchJson(client, withQuery(API.socialCoinState, payloadId(bvid, aid)), { cookie });
      checkApiResponse(state, "获取投币状态失败");
      if (Math.max(0, ((_a = state.data) == null ? void 0 : _a.multiply) || 0) >= 2) throw new Error("最多只能投 2 个币");
      const json = await postFormJson(client, API.socialCoin, { ...payloadId(bvid, aid), multiply: Math.min(2, Math.max(1, Number((payload == null ? void 0 : payload.multiply) || 1))), select_like: 0, csrf }, { cookie });
      checkApiResponse(json, "投币失败");
      return true;
    }
    if (action === "favorite") {
      currentUid(cookie, (_b = payload == null ? void 0 : payload.account) == null ? void 0 : _b.uid);
      const mediaId = Number((payload == null ? void 0 : payload.mediaId) || 0);
      if (mediaId) {
        const json2 = await postFormJson(client, API.favResourceDeal, { rid: aid, type: 2, add_media_ids: mediaId, del_media_ids: "", csrf }, { cookie });
        checkApiResponse(json2, "收藏失败");
        return true;
      }
      const folders = await favoriteFolders(client, { cookie, item: payload == null ? void 0 : payload.item, account: payload == null ? void 0 : payload.account });
      const folder = folders.find((item) => item.title === "默认收藏夹") || folders[0];
      if (!(folder == null ? void 0 : folder.mediaId)) throw new Error("未找到可用收藏夹");
      const json = await postFormJson(client, API.favResourceDeal, { rid: aid, type: 2, add_media_ids: folder.mediaId, del_media_ids: "", csrf }, { cookie });
      checkApiResponse(json, "收藏失败");
      return true;
    }
    throw new Error(`unknown bilibili action: ${action}`);
  };
  const favoriteFolders = async (client, payload) => {
    var _a, _b;
    const cookie = ensureCookie(payload);
    const uid = currentUid(cookie, (_a = payload == null ? void 0 : payload.account) == null ? void 0 : _a.uid);
    const { aid } = await resolveSocialVideo(client, cookie, (payload == null ? void 0 : payload.item) || {});
    const json = await fetchJson(client, withQuery(API.favFolders, { up_mid: uid, type: 2, rid: aid, web_location: "333.1387" }), { cookie });
    checkApiResponse(json, "获取收藏夹失败");
    return (((_b = json.data) == null ? void 0 : _b.list) || []).map((item) => ({
      mediaId: item.id,
      title: item.title,
      mediaCount: item.media_count,
      coverUrl: item.cover,
      favState: !!item.fav_state
    }));
  };
  const comments = async (client, payload, replies = false) => {
    var _a;
    const cookie = ensureCookie(payload);
    const { aid } = await resolveSocialVideo(client, cookie, (payload == null ? void 0 : payload.item) || {});
    const params = replies ? { type: 1, oid: aid, root: payload == null ? void 0 : payload.rootRpid, pn: Math.max(1, Number((payload == null ? void 0 : payload.page) || 1)), ps: 20 } : { type: 1, oid: aid, sort: (payload == null ? void 0 : payload.sort) || 1, pn: Math.max(1, Number((payload == null ? void 0 : payload.page) || 1)), ps: 20, nohot: 1 };
    const json = await fetchJson(client, withQuery(replies ? API.replyReplies : API.reply, params), { cookie, headers: { Referer: "https://www.bilibili.com" } });
    checkApiResponse(json, replies ? "获取回复失败" : "获取评论失败");
    return ((_a = json.data) == null ? void 0 : _a.replies) || [];
  };
  const parseJsonBody$1 = async (request) => {
    var _a, _b;
    const body = ((_a = request == null ? void 0 : request.request) == null ? void 0 : _a.body) || ((_b = request == null ? void 0 : request.Request) == null ? void 0 : _b.Body) || {};
    const data = body.data ?? body.Data;
    if (!data) return {};
    if (typeof data.json === "function") return await data.json();
    if (typeof data.text === "function") {
      const text = await data.text();
      return text ? JSON.parse(text) : {};
    }
    if (typeof data === "string") return data ? JSON.parse(data) : {};
    return data;
  };
  const queryValue = (request, key) => {
    const url = (request == null ? void 0 : request.url) || (request == null ? void 0 : request.URL) || {};
    const query = url.query || url.Query || {};
    const value = query[key];
    return Array.isArray(value) ? String(value[0] || "") : String(value || "");
  };
  const headerValue = (headers = {}, name) => {
    const found = Object.entries(headers || {}).find(([key]) => key.toLowerCase() === name.toLowerCase());
    const value = found == null ? void 0 : found[1];
    return Array.isArray(value) ? String(value[0] || "") : value === void 0 ? "" : String(value);
  };
  const jsonRoute$1 = (handler, errorStatus = 500) => async (request) => {
    try {
      return jsonResponse(success(await handler(await parseJsonBody$1(request), request)));
    } catch (error) {
      return jsonResponse(failure((error == null ? void 0 : error.message) || String(error), errorStatus), errorStatus);
    }
  };
  const proxyRoute = (request) => {
    var _a, _b;
    const url = queryValue(request, "url");
    if (!/^https?:\/\//i.test(url)) return textResponse("invalid proxy url", 400);
    const requestHeaders = ((_a = request == null ? void 0 : request.request) == null ? void 0 : _a.headers) || ((_b = request == null ? void 0 : request.Request) == null ? void 0 : _b.Headers) || {};
    const range = headerValue(requestHeaders, "range");
    return proxyResponse(url, {
      ...BILI_CDN_HEADERS,
      ...range ? { Range: range } : {}
    });
  };
  const createBilibiliHandlers = ({ client }) => ({
    "POST /api/bilibili/check": async (request) => {
      try {
        return jsonResponse(success(await checkConnection$1(client, await parseJsonBody$1(request))));
      } catch (error) {
        return jsonResponse(success({ connected: false, message: `连接失败: ${(error == null ? void 0 : error.message) || String(error)}` }));
      }
    },
    "POST /api/bilibili/login/qrcode": jsonRoute$1(() => qrLogin(client)),
    "POST /api/bilibili/login/poll": jsonRoute$1((payload) => qrPoll(client, payload)),
    "POST /api/bilibili/directory": jsonRoute$1((payload) => listDirectory$1(client, payload)),
    "POST /api/bilibili/media": jsonRoute$1((payload) => createMediaItemFromPath$1(client, payload)),
    "POST /api/bilibili/episodes": jsonRoute$1((payload) => loadEpisodes(client, payload)),
    "POST /api/bilibili/search": jsonRoute$1((payload) => searchAll$1(client, payload)),
    "POST /api/bilibili/search/hints": jsonRoute$1((payload) => searchHints(client, payload)),
    "POST /api/bilibili/resolve": jsonRoute$1((payload) => resolvePlayback$1(client, payload)),
    "POST /api/bilibili/favorite-folders": jsonRoute$1((payload) => favoriteFolders(client, payload)),
    "POST /api/bilibili/social": jsonRoute$1((payload) => socialAction(client, payload)),
    "POST /api/bilibili/comments": jsonRoute$1((payload) => comments(client, payload, false)),
    "POST /api/bilibili/comment-replies": jsonRoute$1((payload) => comments(client, payload, true)),
    "GET /api/bilibili/mpd/:key": async (request) => {
      var _a, _b;
      const path = ((_a = request == null ? void 0 : request.context) == null ? void 0 : _a.path) || ((_b = request == null ? void 0 : request.Context) == null ? void 0 : _b.Path) || "";
      const key = path.split("/").pop() || "";
      const mpd = getCachedMpd(key);
      if (!mpd) return textResponse("mpd not found", 404);
      return textResponse(mpd, 200, "application/dash+xml; charset=utf-8");
    },
    "ANY /api/bilibili/proxy": proxyRoute
  });
  const FETCH_TIMEOUT = 12e3;
  const SITE_CACHE_TTL = 6e4;
  const DETAIL_CACHE_TTL$1 = 6e4;
  const NAME_SPLIT_RE = /[,，、\s]+/;
  let sitesCache = null;
  const detailCache$1 = /* @__PURE__ */ new Map();
  const now$1 = () => Date.now();
  const safeJsonParse = (text = "") => {
    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  };
  const decodeSafe$1 = (value = "") => {
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  };
  const decodeBase64 = (text = "") => {
    try {
      if (typeof atob === "function") return atob(text);
      if (typeof Buffer !== "undefined") return Buffer.from(text, "base64").toString("utf-8");
    } catch {
    }
    return "";
  };
  const getCached = (cached) => cached && cached.expiresAt > now$1() ? cached.value : null;
  const looksLikeJson = (contentType = "", text = "") => {
    const clean = String(text || "").trim();
    return /json/i.test(contentType || "") || clean.startsWith("{") || clean.startsWith("[");
  };
  const stripCdata = (value = "") => String(value || "").replace(/^<!\[CDATA\[/, "").replace(/\]\]>$/, "").trim();
  const xmlDecode = (value = "") => stripCdata(value).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
  const xmlBlocks = (xml = "", tag = "") => [...String(xml || "").matchAll(new RegExp(`<${tag}\\b[^>]*>[\\s\\S]*?<\\/${tag}>`, "gi"))].map((match) => match[0]);
  const xmlAttr = (xml = "", name = "") => {
    var _a;
    return xmlDecode(((_a = String(xml || "").match(new RegExp(`\\b${name}=["']([^"']*)["']`, "i"))) == null ? void 0 : _a[1]) || "");
  };
  const xmlText = (xml = "", tag = "") => {
    var _a;
    return xmlDecode(((_a = String(xml || "").match(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"))) == null ? void 0 : _a[1]) || "");
  };
  const timeoutFetch = async (client, url, timeout = FETCH_TIMEOUT) => {
    const response = await Promise.race([
      client.fetch(url, { method: "GET" }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("Request timeout")), timeout))
    ]);
    if ((response == null ? void 0 : response.status) && response.status >= 400) throw new Error(`HTTP ${response.status}`);
    const headers = (response == null ? void 0 : response.headers) || {};
    return {
      contentType: typeof headers.get === "function" ? headers.get("content-type") || "" : "",
      text: await response.text()
    };
  };
  const buildUrlCandidates = (rawUrl = "") => {
    const out = /* @__PURE__ */ new Set();
    if (rawUrl) out.add(rawUrl);
    try {
      const url = new URL(rawUrl);
      if (url.protocol === "http:") {
        url.protocol = "https:";
        out.add(url.toString());
      }
    } catch {
    }
    return [...out];
  };
  const normalizeSite = (raw = {}, sourceFrom = "", i = 0) => ({
    key: String((raw == null ? void 0 : raw.key) || (raw == null ? void 0 : raw.id) || (raw == null ? void 0 : raw.name) || i),
    name: String((raw == null ? void 0 : raw.name) || (raw == null ? void 0 : raw.title) || (raw == null ? void 0 : raw.key) || (raw == null ? void 0 : raw.id) || `Source ${i + 1}`),
    api: (raw == null ? void 0 : raw.api) || (raw == null ? void 0 : raw.base) || (raw == null ? void 0 : raw.endpoint) || void 0,
    type: typeof (raw == null ? void 0 : raw.type) === "number" ? raw.type : typeof (raw == null ? void 0 : raw.type) === "string" ? parseInt(raw.type, 10) : void 0,
    searchable: (raw == null ? void 0 : raw.searchable) ?? (raw == null ? void 0 : raw.search) ?? 1,
    ext: raw == null ? void 0 : raw.ext,
    sourceFrom
  });
  const dedupeSites = (sites = []) => {
    const map = /* @__PURE__ */ new Map();
    for (const site of sites) {
      if (!(site == null ? void 0 : site.name) && !(site == null ? void 0 : site.key)) continue;
      const key = String(site.api || site.key || site.name || "").trim();
      if (!key || map.has(key)) continue;
      map.set(key, site);
    }
    return [...map.values()];
  };
  const parseSiteArrayFromJson = (obj, sourceFrom = "") => {
    var _a;
    const arr = (obj == null ? void 0 : obj.sites) || (obj == null ? void 0 : obj.list) || (obj == null ? void 0 : obj.rules) || ((_a = obj == null ? void 0 : obj.data) == null ? void 0 : _a.sites) || [];
    if (!Array.isArray(arr)) return [];
    return dedupeSites(arr.map((it, i) => normalizeSite(it, sourceFrom, i)));
  };
  const extractSitesFromText = (text = "", sourceFrom = "") => {
    const found = [];
    const addSites = (obj) => found.push(...parseSiteArrayFromJson(obj, sourceFrom));
    const parsed = safeJsonParse(text);
    if (parsed) addSites(parsed);
    const stripped = text.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ");
    for (const line of stripped.split(/\r?\n/)) {
      const clean = line.trim();
      if (!clean.includes("$")) continue;
      const [name, api] = clean.split("$");
      if (name && api && /^https?:\/\//i.test(api.trim())) found.push({ key: name.trim(), name: name.trim(), api: api.trim(), sourceFrom });
    }
    for (const match of text.matchAll(/atob\(["']([A-Za-z0-9+/=]+)["']\)/g)) {
      const decoded = decodeBase64(match[1] || "");
      const obj = safeJsonParse(decoded) || safeJsonParse(decodeSafe$1(decoded));
      if (obj) addSites(obj);
    }
    for (const block of (text.match(/[A-Za-z0-9+/=]{200,}/g) || []).slice(0, 10)) {
      let decoded = decodeBase64(block);
      if (!decoded) continue;
      for (let i = 0; i < 2; i++) {
        const compact = decoded.replace(/\s+/g, "");
        if (!compact || !/^[A-Za-z0-9+/=]+$/.test(compact)) break;
        decoded = decodeBase64(compact);
        if (!decoded) break;
      }
      const obj = safeJsonParse(decoded);
      if (obj) addSites(obj);
    }
    return dedupeSites(found);
  };
  async function requestFirstMatch(client, urls, parse, timeout = FETCH_TIMEOUT) {
    for (const url of urls) {
      try {
        const { text, contentType } = await timeoutFetch(client, url, timeout);
        const value = parse(text, contentType);
        if (Array.isArray(value) ? value.length : value) return value;
      } catch {
      }
    }
    return null;
  }
  const loadAllSites = async (client, config = {}) => {
    const key = JSON.stringify((config == null ? void 0 : config.sources) || []);
    const cached = getCached(sitesCache);
    if (cached && sitesCache.key === key) return cached;
    const rules = (Array.isArray(config == null ? void 0 : config.sources) ? config.sources : []).filter((rule) => rule.enabled !== false);
    const results = await Promise.allSettled(rules.map((source) => fetchSitesFromSource(client, source)));
    const all = [];
    for (const result of results) {
      if (result.status !== "fulfilled") continue;
      const picked = result.value.filter((site) => /^https?:\/\//i.test(site.api || ""));
      all.push(...picked.length ? picked : result.value);
    }
    const value = dedupeSites(all);
    sitesCache = { key, value, expiresAt: now$1() + SITE_CACHE_TTL };
    return value;
  };
  const getHomeSiteKey = (config = {}) => typeof (config == null ? void 0 : config.homeSiteKey) === "string" ? config.homeSiteKey : "";
  async function fetchSitesFromSource(client, source = {}) {
    if (source.kind === "inline" || String(source.url || "").startsWith("inline://")) {
      return dedupeSites((Array.isArray(source.sites) ? source.sites : []).map((it, i) => normalizeSite(it, "inline", i)));
    }
    for (const url of buildUrlCandidates(source.url || "")) {
      try {
        const { text, contentType } = await timeoutFetch(client, url);
        if (looksLikeJson(contentType, text)) {
          const fromJson = parseSiteArrayFromJson(safeJsonParse(text), source.kind || "site");
          if (fromJson.length) return dedupeSites(fromJson.filter((site) => !!site.api));
        }
        const fromText = extractSitesFromText(text, source.kind || "site");
        if (fromText.length) return dedupeSites(fromText.filter((site) => !!site.api));
      } catch {
      }
    }
    return [];
  }
  const parseJsonList = (obj) => {
    var _a;
    const arr = (obj == null ? void 0 : obj.list) || ((_a = obj == null ? void 0 : obj.data) == null ? void 0 : _a.list) || (obj == null ? void 0 : obj.data) || [];
    if (!Array.isArray(arr)) return [];
    return arr.map((v) => ({
      id: String((v == null ? void 0 : v.vod_id) ?? (v == null ? void 0 : v.id) ?? (v == null ? void 0 : v.vid) ?? (v == null ? void 0 : v.ids) ?? ""),
      title: String((v == null ? void 0 : v.vod_name) ?? (v == null ? void 0 : v.name) ?? (v == null ? void 0 : v.title) ?? ""),
      pic: String((v == null ? void 0 : v.vod_pic) ?? (v == null ? void 0 : v.pic) ?? (v == null ? void 0 : v.cover) ?? ""),
      vod_id: v == null ? void 0 : v.vod_id,
      vod_name: v == null ? void 0 : v.vod_name,
      vod_pic: v == null ? void 0 : v.vod_pic,
      remarks: (v == null ? void 0 : v.vod_remarks) || (v == null ? void 0 : v.remarks) || (v == null ? void 0 : v.note) || (v == null ? void 0 : v.vod_state) || "",
      year: (v == null ? void 0 : v.vod_year) || (v == null ? void 0 : v.year) || "",
      area: (v == null ? void 0 : v.vod_area) || (v == null ? void 0 : v.area) || "",
      type_name: (v == null ? void 0 : v.type_name) || (v == null ? void 0 : v.vod_tag) || ""
    })).filter((item) => item.id && item.title);
  };
  const parseXmlList = (xml = "") => {
    const blocks = [...xmlBlocks(xml, "video"), ...xmlBlocks(xml, "item")];
    return blocks.map((block) => ({
      id: xmlText(block, "id") || xmlAttr(block, "id"),
      title: xmlText(block, "name") || xmlText(block, "title"),
      pic: xmlText(block, "pic") || xmlAttr(block, "pic")
    })).filter((item) => item.id && item.title);
  };
  const parseJsonCategories = (obj) => {
    var _a;
    const classes = (obj == null ? void 0 : obj.class) || (obj == null ? void 0 : obj.types) || ((_a = obj == null ? void 0 : obj.data) == null ? void 0 : _a.class) || [];
    if (!Array.isArray(classes)) return [];
    return classes.map((c, i) => ({
      id: String((c == null ? void 0 : c.type_id) ?? (c == null ? void 0 : c.tid) ?? (c == null ? void 0 : c.id) ?? i + 1),
      name: String((c == null ? void 0 : c.type_name) ?? (c == null ? void 0 : c.name) ?? `Category ${i + 1}`)
    })).filter((c) => c.id && c.name);
  };
  const parseXmlCategories = (xml = "") => {
    const tys = xmlBlocks(xml, "ty").map((block) => ({ id: xmlAttr(block, "id"), name: xmlDecode(block.replace(/^<ty\b[^>]*>|<\/ty>$/gi, "")) }));
    const types = xmlBlocks(xml, "type").map((block) => ({ id: xmlAttr(block, "id"), name: xmlAttr(block, "name") || xmlDecode(block.replace(/^<type\b[^>]*>|<\/type>$/gi, "")) }));
    return [...tys, ...types].filter((c) => c.id && c.name);
  };
  const parseListAuto = (text, contentType) => looksLikeJson(contentType, text) ? parseJsonList(safeJsonParse(text)) : parseXmlList(text);
  const parseCategoriesAuto = (text, contentType) => looksLikeJson(contentType, text) ? parseJsonCategories(safeJsonParse(text)) : parseXmlCategories(text);
  const parseEpisodeUrls = (value = "") => String(value || "").split("#").map((line) => {
    const [name, url] = line.split("$");
    const finalUrl = (url || name || "").trim();
    return { name: name || "Play", url: finalUrl };
  }).filter((ep) => /^https?:\/\//i.test(ep.url));
  const parsePlayFromJson = (obj) => {
    var _a, _b;
    const item = ((_a = obj == null ? void 0 : obj.list) == null ? void 0 : _a[0]) || ((_b = obj == null ? void 0 : obj.data) == null ? void 0 : _b[0]) || (obj == null ? void 0 : obj.data) || (obj == null ? void 0 : obj.list);
    if (!item) return "";
    const urls = (item == null ? void 0 : item.vod_play_url) || (item == null ? void 0 : item.play_url) || "";
    if (typeof urls === "string" && urls) {
      const list = parseEpisodeUrls(urls).map((it) => it.url);
      return list.find((url) => /\.m3u8(\?|$)/i.test(url)) || list[0] || "";
    }
    if (Array.isArray(urls)) {
      const list = urls.filter((url) => typeof url === "string" && /^https?:\/\//i.test(url));
      return list.find((url) => /\.m3u8(\?|$)/i.test(url)) || list[0] || "";
    }
    const match = JSON.stringify(item).match(/https?:\/\/[^\s"'\\]+/g);
    if (!(match == null ? void 0 : match.length)) return "";
    return (match.find((url) => /\.m3u8(\?|$)/i.test(url)) || match[0] || "").replace(/\\\\/g, "\\");
  };
  const parsePlayFromXml = (xml = "") => {
    const urls = xmlBlocks(xml, "dd").flatMap((block) => parseEpisodeUrls(xmlDecode(block.replace(/^<dd\b[^>]*>|<\/dd>$/gi, ""))).map((it) => it.url));
    return urls.find((url) => /\.m3u8(\?|$)/i.test(url)) || urls[0] || "";
  };
  const fetchListPreferCovers = async (client, site, candidates) => {
    let fallback = null;
    for (const url of candidates) {
      try {
        const { text, contentType } = await timeoutFetch(client, url);
        const list = parseListAuto(text, contentType).map((item) => ({ ...item, site }));
        if (!list.length) continue;
        if (list.some((item) => !!item.pic)) return list;
        if (!fallback) fallback = list;
      } catch {
      }
    }
    return fallback || [];
  };
  const cmsHome = async (client, site) => {
    if (!(site == null ? void 0 : site.api)) return [];
    return await requestFirstMatch(client, [`${site.api}?ac=list`, `${site.api}?ac=class`, `${site.api}`], (text, contentType) => {
      const list = parseCategoriesAuto(text, contentType);
      return list.length ? list : null;
    }) || [];
  };
  const cmsListByType = (client, site, typeId, page = 1) => {
    if (!(site == null ? void 0 : site.api)) return [];
    const tid = encodeURIComponent(typeId);
    return fetchListPreferCovers(client, site, [
      `${site.api}?ac=list&t=${tid}&pg=${page}`,
      `${site.api}?ac=detail&t=${tid}&pg=${page}`,
      `${site.api}?ac=videolist&t=${tid}&pg=${page}`,
      `${site.api}?t=${tid}&pg=${page}`
    ]);
  };
  const cmsSearch = (client, site, keyword) => {
    if (!(site == null ? void 0 : site.api)) return [];
    const wd = encodeURIComponent(keyword);
    return fetchListPreferCovers(client, site, [`${site.api}?wd=${wd}`, `${site.api}?ac=detail&wd=${wd}`, `${site.api}?ac=list&wd=${wd}`]);
  };
  const splitNames = (text = "") => String(text || "").split(NAME_SPLIT_RE).map((value) => value.trim()).filter(Boolean).map((name) => ({ name }));
  const parseDetailFromJson = (obj) => {
    var _a, _b;
    const item = ((_a = obj == null ? void 0 : obj.list) == null ? void 0 : _a[0]) || ((_b = obj == null ? void 0 : obj.data) == null ? void 0 : _b[0]) || (obj == null ? void 0 : obj.data) || (obj == null ? void 0 : obj.list);
    if (!item) return {};
    const froms = String((item == null ? void 0 : item.vod_play_from) || (item == null ? void 0 : item.play_from) || "").split("$$$").filter(Boolean);
    const segs = String((item == null ? void 0 : item.vod_play_url) || (item == null ? void 0 : item.play_url) || "").split("$$$").filter(Boolean);
    const sources = froms.map((from, i) => ({ from, episodes: parseEpisodeUrls(segs[i] || "") })).filter((source) => source.episodes.length);
    if (!sources.length) {
      const single = parsePlayFromJson({ list: [item] });
      if (single) sources.push({ from: "default", episodes: [{ name: "Play", url: single }] });
    }
    return {
      title: (item == null ? void 0 : item.vod_name) || (item == null ? void 0 : item.title) || "",
      pic: (item == null ? void 0 : item.vod_pic) || (item == null ? void 0 : item.pic) || "",
      remarks: (item == null ? void 0 : item.vod_remarks) || (item == null ? void 0 : item.remarks) || "",
      url: parsePlayFromJson({ list: [item] }),
      sources,
      year: item == null ? void 0 : item.vod_year,
      area: item == null ? void 0 : item.vod_area,
      directors: splitNames(item == null ? void 0 : item.vod_director),
      casts: splitNames(item == null ? void 0 : item.vod_actor),
      content: item == null ? void 0 : item.vod_content,
      genres: String((item == null ? void 0 : item.vod_class) || (item == null ? void 0 : item.type_name) || "").split(NAME_SPLIT_RE).filter(Boolean),
      score: (item == null ? void 0 : item.vod_score) || (item == null ? void 0 : item.vod_douban_score) || (item == null ? void 0 : item.score),
      pubdate: (item == null ? void 0 : item.vod_pubdate) || (item == null ? void 0 : item.vod_release_date) || (item == null ? void 0 : item.pubdate),
      duration: (item == null ? void 0 : item.vod_duration) || (item == null ? void 0 : item.duration) || (item == null ? void 0 : item.vod_length) || (item == null ? void 0 : item.vod_len),
      lang: (item == null ? void 0 : item.vod_lang) || (item == null ? void 0 : item.lang)
    };
  };
  const parseDetailFromXml = (xml = "") => {
    const vod = xmlBlocks(xml, "video")[0] || xmlBlocks(xml, "vod")[0] || "";
    if (!vod) return {};
    const sources = xmlBlocks(vod || xml, "dd").map((block) => ({
      from: xmlAttr(block, "flag") || "default",
      episodes: parseEpisodeUrls(xmlDecode(block.replace(/^<dd\b[^>]*>|<\/dd>$/gi, "")))
    })).filter((source) => source.episodes.length);
    if (!sources.length) {
      const single = parsePlayFromXml(xml);
      if (single) sources.push({ from: "default", episodes: [{ name: "Play", url: single }] });
    }
    return {
      title: xmlText(vod, "name"),
      pic: xmlText(vod, "pic"),
      remarks: xmlText(vod, "note"),
      url: parsePlayFromXml(xml),
      sources,
      year: xmlText(vod, "year"),
      area: xmlText(vod, "area"),
      directors: splitNames(xmlText(vod, "director")),
      casts: splitNames(xmlText(vod, "actor")),
      content: xmlText(vod, "des"),
      genres: xmlText(vod, "class").split(NAME_SPLIT_RE).filter(Boolean),
      score: xmlText(vod, "score") || xmlText(vod, "douban_score"),
      pubdate: xmlText(vod, "pubdate") || xmlText(vod, "last"),
      duration: xmlText(vod, "duration") || xmlText(vod, "len") || xmlText(vod, "length"),
      lang: xmlText(vod, "lang")
    };
  };
  const cmsDetailInfo = async (client, site, id) => {
    if (!(site == null ? void 0 : site.api) || !id) return {};
    const cacheKey = `${site.api}|${id}`;
    const cached = getCached(detailCache$1.get(cacheKey));
    if (cached) return { ...cached, site };
    const itemId = encodeURIComponent(id);
    const detail = await requestFirstMatch(client, [
      `${site.api}?ac=detail&ids=${itemId}`,
      `${site.api}?ac=videolist&ids=${itemId}`,
      `${site.api}?ids=${itemId}`
    ], (text, contentType) => {
      var _a;
      const info = looksLikeJson(contentType, text) ? parseDetailFromJson(safeJsonParse(text)) : parseDetailFromXml(text);
      return info && (((_a = info.sources) == null ? void 0 : _a.length) || info.url) ? info : null;
    });
    const value = detail || {};
    detailCache$1.set(cacheKey, { value, expiresAt: now$1() + DETAIL_CACHE_TTL$1 });
    return { ...value, site };
  };
  const DOUBAN_BASE = "https://m.douban.com/rexxar/api/v2";
  const sanitizeTvTitle = (title = "") => String(title || "").replace(/[（(]\s*第?\s*\d+\s*[集话季部篇期]\s*[）)]/g, "").replace(/第\s*\d+\s*[集话季部篇期]/g, "").replace(/\s*[-_]\s*第?\s*\d+\s*[集话季部篇期].*$/g, "").replace(/\s+/g, " ").trim();
  const doubanFetch = async (client, path, params = {}) => {
    const url = new URL(`${DOUBAN_BASE}${path}`);
    Object.entries(params).forEach(([key, value]) => url.searchParams.append(key, String(value)));
    try {
      const response = await client.fetch(url.toString(), {
        method: "GET",
        headers: { Referer: "https://m.douban.com/" }
      });
      if ((response == null ? void 0 : response.status) && response.status >= 400) throw new Error(`HTTP ${response.status}`);
      return JSON.parse(await response.text());
    } catch {
      return null;
    }
  };
  const searchMovie = async (client, query) => {
    var _a, _b;
    const key = String(query || "").trim();
    if (!key) return null;
    const data = await doubanFetch(client, "/search/subjects", { q: key, type: "movie", count: 1 });
    const item = (_b = (_a = data == null ? void 0 : data.subjects) == null ? void 0 : _a.items) == null ? void 0 : _b[0];
    return item ? { id: item.target_id, ...item.target } : null;
  };
  const getMovieDetail = (client, id) => id ? doubanFetch(client, `/movie/${id}`) : null;
  const enrichTvboxDetailWithDouban = async (client, title, detail = {}) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
    const query = sanitizeTvTitle(title || (detail == null ? void 0 : detail.title) || (detail == null ? void 0 : detail.vod_name) || "");
    if (!query) return detail || {};
    const match = await searchMovie(client, query);
    if (!(match == null ? void 0 : match.id)) return detail || {};
    const douban = await getMovieDetail(client, match.id);
    if (!douban) return detail || {};
    return {
      ...detail,
      title: douban.title || (detail == null ? void 0 : detail.title),
      original_title: douban.original_title || (detail == null ? void 0 : detail.original_title) || "",
      pic: ((_a = douban.pic) == null ? void 0 : _a.large) || ((_b = douban.pic) == null ? void 0 : _b.normal) || (detail == null ? void 0 : detail.pic) || "",
      genres: ((_c = douban.genres) == null ? void 0 : _c.length) ? douban.genres : detail == null ? void 0 : detail.genres,
      rating: douban.rating || (detail == null ? void 0 : detail.rating),
      score: ((_d = douban.rating) == null ? void 0 : _d.value) || (detail == null ? void 0 : detail.score) || "",
      directors: ((_e = douban.directors) == null ? void 0 : _e.length) ? douban.directors : detail == null ? void 0 : detail.directors,
      casts: ((_f = douban.actors) == null ? void 0 : _f.length) ? douban.actors : detail == null ? void 0 : detail.casts,
      year: douban.year || (detail == null ? void 0 : detail.year) || "",
      countries: ((_g = douban.countries) == null ? void 0 : _g.length) ? douban.countries : detail == null ? void 0 : detail.countries,
      summary: douban.intro || (detail == null ? void 0 : detail.summary) || (detail == null ? void 0 : detail.content) || "",
      aka: ((_h = douban.aka) == null ? void 0 : _h.length) ? douban.aka : detail == null ? void 0 : detail.aka,
      durations: ((_i = douban.durations) == null ? void 0 : _i.length) ? douban.durations : detail == null ? void 0 : detail.durations,
      trailers: ((_j = douban.trailers) == null ? void 0 : _j.length) ? douban.trailers : detail == null ? void 0 : detail.trailers,
      pubdate: douban.pubdate || (detail == null ? void 0 : detail.pubdate) || "",
      languages: ((_k = douban.languages) == null ? void 0 : _k.length) ? douban.languages : detail == null ? void 0 : detail.languages,
      episodes_count: douban.episodes_count || (detail == null ? void 0 : detail.episodes_count) || 0
    };
  };
  const DETAIL_CACHE_TTL = 6e4;
  const PLAYABLE_CACHE_TTL = 3e4;
  const SOURCE_ID = "tvbox";
  const PROTOCOL = "tvbox://";
  const itemCache = /* @__PURE__ */ new Map();
  const detailCache = /* @__PURE__ */ new Map();
  const playableCache = /* @__PURE__ */ new Map();
  const now = () => Date.now();
  const pickFirst = (item, ...keys) => keys.map((key) => item == null ? void 0 : item[key]).find(Boolean) || "";
  const joinText = (list = []) => list.filter(Boolean).map((item) => `${item}`).join(" / ");
  const hasM3u8Episode = (source) => ((source == null ? void 0 : source.episodes) || []).some((ep) => /\.m3u8(\?|$)/i.test((ep == null ? void 0 : ep.url) || ""));
  const sortTvboxSources = (sources = []) => [...sources].sort((a, b) => Number(hasM3u8Episode(b)) - Number(hasM3u8Episode(a)));
  const decodeSafe = (value = "") => {
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  };
  const parseJsonBody = async (request) => {
    var _a, _b;
    const body = ((_a = request == null ? void 0 : request.request) == null ? void 0 : _a.body) || ((_b = request == null ? void 0 : request.Request) == null ? void 0 : _b.Body) || {};
    const data = body.data ?? body.Data;
    if (!data) return {};
    if (typeof data.json === "function") return await data.json();
    if (typeof data.text === "function") {
      const text = await data.text();
      return text ? JSON.parse(text) : {};
    }
    if (typeof data === "string") return data ? JSON.parse(data) : {};
    return data;
  };
  const jsonRoute = (handler) => async (request) => {
    try {
      return jsonResponse(success(await handler(await parseJsonBody(request), request)));
    } catch (error) {
      return jsonResponse(failure((error == null ? void 0 : error.message) || String(error), 500), 500);
    }
  };
  const normalizePath = (path = "") => {
    const raw = String(path || "").split("?")[0];
    const clean = decodeSafe(raw).replace(/\\/g, "/");
    if (!clean) return "/";
    return clean.startsWith("/") ? clean : `/${clean}`;
  };
  const getPage = (path = "") => {
    var _a;
    return Math.max(1, parseInt(((_a = String(path || "").match(/[?&]page=(\d+)/)) == null ? void 0 : _a[1]) || "1", 10) || 1);
  };
  const parseNavPath = (path = "") => {
    const clean = normalizePath(path).replace(/^\/|\/$/g, "");
    if (!clean || clean === "root") return { type: "root" };
    const parts = clean.split("/");
    if (parts[0] === "sites") {
      if (parts[1] && parts[2] === "cat" && parts[3]) return { type: "category", siteKey: parts[1], categoryId: parts[3] };
      if (parts[1]) return { type: "site", siteKey: parts[1] };
      return { type: "sites" };
    }
    if (parts[0] === "search" && parts[1]) return { type: "search", keyword: decodeSafe(parts[1]) };
    return { type: "root" };
  };
  const parsePlayPath = (fileId = "") => {
    const rawPath = normalizePath(fileId);
    const parts = rawPath.replace(/^\/|\/$/g, "").split("/").filter(Boolean);
    if (!parts.length) return { rawPath, itemId: "" };
    if (parts[0] === "sites" && parts[1] && parts[2] === "cat" && parts[3] && parts[4]) {
      return { rawPath, siteKey: parts[1], categoryId: parts[3], itemId: parts[4] };
    }
    if (parts[0] === "search" && parts.length >= 4) return { rawPath, siteKey: parts[parts.length - 2], itemId: parts[parts.length - 1] };
    if (parts[0] === "search" && parts.length >= 3) return { rawPath, itemId: parts[parts.length - 1] };
    return { rawPath, itemId: parts[parts.length - 1] || "" };
  };
  const getSites = (client, payload = {}) => loadAllSites(client, (payload == null ? void 0 : payload.config) || {});
  const findSite = async (client, payload, siteKey = "") => {
    const sites = await getSites(client, payload);
    return sites.find((site) => site.key === siteKey || site.name === siteKey) || null;
  };
  const ensureSite = async (client, payload) => {
    const sites = await getSites(client, payload);
    const homeKey = getHomeSiteKey((payload == null ? void 0 : payload.config) || {});
    const site = homeKey ? sites.find((item) => {
      var _a;
      return item.key === homeKey || ((_a = item.name) == null ? void 0 : _a.includes(homeKey));
    }) || sites[0] : sites[0];
    if (!site) throw new Error("No TVBox site available");
    return site;
  };
  const buildDirEntry = (id, name, path) => {
    const ts = now();
    return { id, name, path, size: 0, isDir: true, is_dir: true, modified: ts, created: ts };
  };
  const cacheItem = (item, fullPath) => {
    var _a;
    itemCache.set(fullPath, item);
    if (!itemCache.has(item.id)) itemCache.set(item.id, item);
    if ((_a = item.site) == null ? void 0 : _a.key) itemCache.set(`${item.site.key}|${item.id}`, item);
  };
  const convertItemsToFiles = (items = [], basePath = "") => {
    const ts = now();
    return items.map((item) => {
      const fullPath = `${basePath}/${item.id}`;
      cacheItem(item, fullPath);
      return {
        id: fullPath,
        name: item.title,
        path: fullPath,
        size: 0,
        isDir: false,
        is_dir: false,
        modified: ts,
        created: ts,
        thumbnail: item.pic,
        _tvboxItem: item
      };
    });
  };
  const listDirectory = async (client, payload) => {
    const nav = parseNavPath((payload == null ? void 0 : payload.path) || "root");
    const page = getPage((payload == null ? void 0 : payload.path) || "");
    const sites = await getSites(client, payload);
    if (nav.type === "root") return [
      buildDirEntry("sites", `影视站点 (${sites.length})`, "/sites"),
      buildDirEntry("search", "搜索影视", "/search")
    ];
    if (nav.type === "sites") return sites.map((site) => {
      const siteKey = site.key || site.name;
      return buildDirEntry(`site-${siteKey}`, site.name || site.key, `/sites/${siteKey}`);
    });
    if (nav.type === "site") {
      const site = await findSite(client, payload, nav.siteKey);
      return site ? (await cmsHome(client, site)).map((cat) => buildDirEntry(`cat-${cat.id}`, cat.name, `/sites/${nav.siteKey}/cat/${cat.id}`)) : [];
    }
    if (nav.type === "category") {
      const site = await findSite(client, payload, nav.siteKey);
      return site ? convertItemsToFiles(await cmsListByType(client, site, nav.categoryId, page), `/sites/${nav.siteKey}/cat/${nav.categoryId}`) : [];
    }
    if (nav.type === "search") {
      const site = await ensureSite(client, payload);
      return convertItemsToFiles(await cmsSearch(client, site, nav.keyword), `/search/${encodeURIComponent(nav.keyword)}`);
    }
    return [];
  };
  const findCachedItem = (rawPath, itemId, siteKey) => itemCache.get(rawPath) || (siteKey ? itemCache.get(`${siteKey}|${itemId}`) : null) || itemCache.get(itemId) || null;
  const getDetail = async (client, site, itemId) => {
    const key = `${site.api || ""}|${itemId}`;
    const cached = detailCache.get(key);
    if (cached && cached.expiresAt > now()) return cached.value;
    const raw = await cmsDetailInfo(client, site, itemId);
    const detail = await enrichTvboxDetailWithDouban(client, (raw == null ? void 0 : raw.title) || "", raw);
    detailCache.set(key, { value: detail, expiresAt: now() + DETAIL_CACHE_TTL });
    return detail;
  };
  const resolveItem = async (client, payload, parsed) => {
    const cached = findCachedItem(parsed.rawPath, parsed.itemId, parsed.siteKey);
    if (cached) return cached;
    if (parsed.siteKey && parsed.categoryId) {
      const site = await findSite(client, payload, parsed.siteKey);
      if (!site) return null;
      const found = (await cmsListByType(client, site, parsed.categoryId, 1)).find((item) => item.id === parsed.itemId) || null;
      if (found) {
        const withSite = { ...found, site };
        cacheItem(withSite, parsed.rawPath);
        return withSite;
      }
    }
    return null;
  };
  const resolvePlayableContext = async (client, payload, fileId) => {
    const cacheKey = `${JSON.stringify((payload == null ? void 0 : payload.config) || {})}|${fileId}`;
    const cached = playableCache.get(cacheKey);
    if (cached && cached.expiresAt > now()) return cached.value;
    const parsed = parsePlayPath(fileId);
    if (!parsed.itemId) throw new Error("Invalid TVBox item path");
    const item = await resolveItem(client, payload, parsed);
    const site = (item == null ? void 0 : item.site) || await findSite(client, payload, parsed.siteKey) || await ensureSite(client, payload);
    const value = { detail: await getDetail(client, site, (item == null ? void 0 : item.id) || parsed.itemId) };
    playableCache.set(cacheKey, { value, expiresAt: now() + PLAYABLE_CACHE_TTL });
    return value;
  };
  const pickPlayableUrl = (detail = {}) => {
    var _a;
    const sources = sortTvboxSources(detail.sources || []);
    for (const source of sources) {
      const m3u8 = (source.episodes || []).find((ep) => /\.m3u8(\?|$)/i.test((ep == null ? void 0 : ep.url) || ""));
      if (m3u8 == null ? void 0 : m3u8.url) return m3u8.url;
    }
    for (const source of sources) {
      const first = (_a = source.episodes) == null ? void 0 : _a[0];
      if (first == null ? void 0 : first.url) return first.url;
    }
    return detail.url || "";
  };
  const getMediaType = (url = "") => /\.mpd([?#]|$)/i.test(url) ? "mpd" : /\.m3u8([?#]|$)/i.test(url) ? "m3u8" : "auto";
  const toMediaItem = async (client, payload, path, item = {}, detail = {}) => {
    var _a;
    const pic = pickFirst(item, "pic") || pickFirst(detail, "pic");
    const parsed = parsePlayPath(path);
    const site = item.site || await findSite(client, payload, parsed.siteKey) || await ensureSite(client, payload);
    const sources = sortTvboxSources(detail.sources || []);
    const title = pickFirst(detail, "title") || pickFirst(item, "title") || "未命名";
    const countries = Array.isArray(detail.countries) ? detail.countries : [];
    const languages = Array.isArray(detail.languages) ? detail.languages : (detail == null ? void 0 : detail.lang) ? [detail.lang] : [];
    const durations = Array.isArray(detail.durations) ? detail.durations : (detail == null ? void 0 : detail.duration) ? [detail.duration] : [];
    const genres = Array.isArray(detail.genres) ? detail.genres : [];
    const score = pickFirst(detail, "score") || ((_a = detail == null ? void 0 : detail.rating) == null ? void 0 : _a.value) || "";
    const meta = [
      score ? `豆瓣: ${score}` : "",
      pickFirst(detail, "year") || pickFirst(item, "year"),
      joinText(countries),
      (detail == null ? void 0 : detail.episodes_count) ? `${detail.episodes_count} 集` : "",
      pickFirst(detail, "remarks") || pickFirst(item, "remarks")
    ].filter(Boolean).join(" · ");
    return {
      id: `tvbox-${path}`,
      title,
      name: title,
      url: `${PROTOCOL}file/${path}`,
      originalUrl: `${PROTOCOL}file/${path}`,
      type: "video",
      source: SOURCE_ID,
      sourcePath: path,
      thumbnail: pic,
      added: now(),
      size: 0,
      year: pickFirst(detail, "year") || pickFirst(item, "year"),
      area: pickFirst(detail, "area") || pickFirst(item, "area"),
      remarks: pickFirst(detail, "remarks") || pickFirst(item, "remarks"),
      genre: genres.length ? genres.join(" / ") : item.type_name || "",
      artist: meta,
      desc: pickFirst(detail, "summary", "content"),
      rating: detail.rating,
      score,
      countries,
      languages,
      durations,
      aka: Array.isArray(detail.aka) ? detail.aka : [],
      directors: Array.isArray(detail.directors) ? detail.directors : [],
      casts: Array.isArray(detail.casts) ? detail.casts : [],
      summary: pickFirst(detail, "summary", "content"),
      pubDate: pickFirst(detail, "pubdate"),
      episodesCount: Number(detail.episodes_count || 0),
      originalTitle: pickFirst(detail, "original_title"),
      sources,
      _episodes: { sources },
      site
    };
  };
  const createMediaItemsFromDirectory = async (client, payload) => {
    const path = (payload == null ? void 0 : payload.path) || "";
    const page = Math.max(1, Number((payload == null ? void 0 : payload.page) || 1));
    const files = await listDirectory(client, { ...payload, path: page > 1 ? `${path}${String(path).includes("?") ? "&" : "?"}page=${page}` : path });
    return Promise.all(files.map(async (file) => file.isDir ? {
      id: `tvbox-folder-${file.id}`,
      title: file.name,
      name: file.name,
      type: "folder",
      url: "#",
      originalUrl: `${PROTOCOL}${file.path}`,
      source: SOURCE_ID,
      sourcePath: file.path,
      is_dir: true,
      isDir: true,
      thumbnail: "",
      size: 0,
      added: file.created
    } : {
      ...await toMediaItem(client, payload, file.path, file._tvboxItem || { title: file.name, pic: file.thumbnail }, {}),
      id: `tvbox-${file.id}`,
      added: file.created
    }));
  };
  const createMediaItemFromPath = async (client, payload) => {
    var _a;
    const path = String((payload == null ? void 0 : payload.path) || "");
    const parsed = parsePlayPath(path);
    const item = await resolveItem(client, payload, parsed) || {
      id: parsed.itemId,
      title: parsed.itemId,
      site: await findSite(client, payload, parsed.siteKey) || await ensureSite(client, payload)
    };
    const detail = await getDetail(client, item.site, item.id || parsed.itemId);
    return { ...await toMediaItem(client, payload, path, item, detail), ...(payload == null ? void 0 : payload.timeParams) || {}, isLoop: ((_a = payload == null ? void 0 : payload.timeParams) == null ? void 0 : _a.endTime) !== void 0 };
  };
  const getQualities = async (client, payload) => {
    const { detail } = await resolvePlayableContext(client, payload, (payload == null ? void 0 : payload.path) || "");
    const sources = sortTvboxSources(detail.sources || []);
    const options = [];
    sources.forEach((source, i) => (source.episodes || []).forEach((ep, j) => {
      if (!(ep == null ? void 0 : ep.url)) return;
      options.push({
        default: i === 0 && j === 0,
        html: `${source.from || `线路${i + 1}`} - ${ep.name || `第${j + 1}集`}`,
        url: ep.url,
        extra: { type: getMediaType(ep.url), from: source.from || "" }
      });
    }));
    return options;
  };
  const resolvePlayback = async (client, payload) => {
    const { detail } = await resolvePlayableContext(client, payload, (payload == null ? void 0 : payload.path) || "");
    const url = pickPlayableUrl(detail);
    if (!url) throw new Error("Playback URL not found");
    return { url, qualities: await getQualities(client, payload), runtime: {} };
  };
  const searchAll = async (client, payload) => {
    const keyword = String((payload == null ? void 0 : payload.keyword) || "");
    const siteKey = String((payload == null ? void 0 : payload.siteKey) || "");
    const sites = await getSites(client, payload);
    if (!keyword.trim()) return [];
    const homeKey = getHomeSiteKey((payload == null ? void 0 : payload.config) || {});
    const homeSite = homeKey ? sites.find((site) => {
      var _a;
      return site.key === homeKey || ((_a = site.name) == null ? void 0 : _a.includes(homeKey));
    }) : null;
    const queue = siteKey ? sites.filter((site) => site.key === siteKey || site.name === siteKey) : (homeSite ? [homeSite, ...sites.filter((site) => site !== homeSite)] : sites).filter((site) => site.searchable !== 0).slice(0, 12);
    const groups = await Promise.all(queue.map(async (site) => {
      const items = await cmsSearch(client, site, keyword).catch(() => []);
      return items.map((item) => {
        const path = `/search/${encodeURIComponent(keyword)}/${site.key}/${item.id}`;
        const withSite = { ...item, site };
        cacheItem(withSite, path);
        return {
          id: `tvbox-search-${site.key}-${item.id}`,
          path,
          name: item.title,
          title: item.title,
          type: "video",
          url: `${PROTOCOL}file${path}`,
          originalUrl: `${PROTOCOL}file${path}`,
          source: SOURCE_ID,
          sourcePath: path,
          thumbnail: item.pic || "",
          size: 0,
          added: now(),
          playCount: 0,
          currentTime: 0,
          orderIndex: 0,
          album: site.name,
          searchSource: site.name,
          remarks: item.remarks || "",
          year: item.year || "",
          genre: item.type_name || ""
        };
      });
    }));
    return groups.flat();
  };
  const searchSites = async (client, payload) => (await getSites(client, payload)).filter((site) => site.searchable !== 0).map((site) => ({ key: site.key, name: site.name || site.key }));
  const checkConnection = async (client, payload) => {
    const sites = await getSites(client, payload);
    return { connected: true, message: `Loaded ${sites.length} site(s)`, profile: { sitesCount: sites.length } };
  };
  const createTvboxHandlers = ({ client }) => ({
    "POST /api/tvbox/check": jsonRoute((payload) => checkConnection(client, payload)),
    "POST /api/tvbox/directory": jsonRoute((payload) => listDirectory(client, payload)),
    "POST /api/tvbox/items": jsonRoute((payload) => createMediaItemsFromDirectory(client, payload)),
    "POST /api/tvbox/media": jsonRoute((payload) => createMediaItemFromPath(client, payload)),
    "POST /api/tvbox/resolve": jsonRoute((payload) => resolvePlayback(client, payload)),
    "POST /api/tvbox/qualities": jsonRoute((payload) => getQualities(client, payload)),
    "POST /api/tvbox/search": jsonRoute((payload) => searchAll(client, payload)),
    "POST /api/tvbox/search/sites": jsonRoute((payload) => searchSites(client, payload))
  });
  const pick = (value, lowerName, upperName) => {
    if (!value) return void 0;
    if (value[lowerName] !== void 0) return value[lowerName];
    if (value[upperName] !== void 0) return value[upperName];
    return void 0;
  };
  const decodePath = (path) => {
    try {
      return decodeURIComponent(path);
    } catch {
      return path;
    }
  };
  const requestPath = (request) => {
    const context = pick(request, "context", "Context");
    const url = pick(request, "url", "URL");
    const fromContext = pick(context, "path", "Path");
    const fromUrl = pick(url, "path", "Path");
    const raw = fromContext || fromUrl || "/";
    return decodePath(raw.replace(/^\/plugin\/private\/[^/]+/, "") || "/");
  };
  const requestMethod = (request) => {
    const meta = pick(request, "request", "Request");
    return String(pick(meta, "method", "Method") || "GET").toUpperCase();
  };
  const matchDynamicHandler = (handlers, method, path) => {
    for (const [route, handler] of Object.entries(handlers)) {
      const [routeMethod, routePath] = route.split(" ");
      if (routeMethod !== method && routeMethod !== "ANY") continue;
      if (!(routePath == null ? void 0 : routePath.includes(":"))) continue;
      const pattern = `^${routePath.replace(/:[^/]+/g, "[^/]+")}$`;
      if (new RegExp(pattern).test(path)) return handler;
    }
    return null;
  };
  const createRouter = ({ handlers, statusPayload, logger }) => async (request) => {
    var _a;
    const method = requestMethod(request);
    const path = requestPath(request);
    const key = `${method} ${path}`;
    const anyKey = `ANY ${path}`;
    try {
      if (path === "/" || path === "/status") return jsonResponse(success(statusPayload()));
      const handler = handlers[key] || handlers[anyKey];
      if (handler) return await handler(request);
      const dynamicHandler = matchDynamicHandler(handlers, method, path);
      if (dynamicHandler) return await dynamicHandler(request);
      return jsonResponse(failure(`route not implemented: ${key}`, 404), 404);
    } catch (error) {
      (_a = logger == null ? void 0 : logger.error) == null ? void 0 : _a.call(logger, "[siyuan-media-player]", (error == null ? void 0 : error.stack) || (error == null ? void 0 : error.message) || String(error));
      return jsonResponse(failure((error == null ? void 0 : error.message) || String(error), 500), 500);
    }
  };
  (function() {
    const handlers = {
      ...createBilibiliHandlers({ client: siyuan.client }),
      ...createTvboxHandlers({ client: siyuan.client })
    };
    const statusPayload = () => ({
      name: "siyuan-media-player",
      kernel: true,
      capabilities: ["bilibili.resolve", "bilibili.proxy", "bilibili.mpd", "tvbox.resolve"],
      routes: Object.keys(handlers).sort()
    });
    const route = createRouter({
      handlers,
      logger: siyuan.logger,
      statusPayload
    });
    siyuan.plugin.lifecycle.onload = async () => {
      await siyuan.rpc.bind("siyuan-media-player.status", async () => statusPayload(), "Return media player kernel runtime status.");
    };
    siyuan.plugin.lifecycle.onunload = async () => {
    };
    siyuan.server.private.http.handler = async (request) => {
      return route(request);
    };
  })();
})();
