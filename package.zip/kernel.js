(function() {
  "use strict";
  const success = (data) => ({
    code: 200,
    message: "success",
    data: data === void 0 ? null : data
  });
  const failure = (message, code = 500, data = null) => ({
    code,
    message: message || "error",
    data
  });
  const jsonResponse = (payload, statusCode = 200) => ({
    statusCode,
    headers: {
      "Content-Type": ["application/json; charset=utf-8"]
    },
    body: {
      data: {
        type: "JSON",
        data: payload
      }
    }
  });
  const textResponse = (text, statusCode = 200, contentType = "text/plain; charset=utf-8") => ({
    statusCode,
    headers: {
      "Content-Type": [contentType]
    },
    body: {
      string: {
        format: "%s",
        values: [String(text || "")]
      }
    }
  });
  const proxyResponse = (url, headers = {}, method = "") => {
    const normalizedHeaders = {};
    for (const [key, value] of Object.entries(headers || {})) {
      if (value === void 0 || value === null || value === "") continue;
      normalizedHeaders[key] = Array.isArray(value) ? value.map(String) : [String(value)];
    }
    const proxy = {
      url,
      headers: normalizedHeaders
    };
    if (method) proxy.method = method;
    return {
      statusCode: 200,
      headers: {},
      body: { proxy }
    };
  };
  const PRIVATE_BASE$2 = "/plugin/private/siyuan-media-player";
  const USER_AGENT$1 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
  const BILI_HEADERS = {
    "User-Agent": USER_AGENT$1,
    Referer: "https://www.bilibili.com/",
    Origin: "https://www.bilibili.com"
  };
  const BILI_CDN_HEADERS = {
    "User-Agent": USER_AGENT$1,
    Referer: "https://www.bilibili.com/",
    "Accept-Encoding": "identity"
  };
  const API = {
    www: "https://www.bilibili.com",
    nav: "https://api.bilibili.com/x/web-interface/nav",
    qrTvLogin: "https://passport.bilibili.com/x/passport-tv-login/qrcode/auth_code",
    qrTvPoll: "https://passport.bilibili.com/x/passport-tv-login/qrcode/poll",
    view: "https://api.bilibili.com/x/web-interface/view",
    playUrl: "https://api.bilibili.com/x/player/wbi/playurl",
    playerInfo: "https://api.bilibili.com/x/player/wbi/v2",
    videoShot: "https://api.bilibili.com/x/player/videoshot",
    aiSummary: "https://api.bilibili.com/x/web-interface/view/conclusion/get",
    commentXml: "https://comment.bilibili.com/{cid}.xml",
    popular: "https://api.bilibili.com/x/web-interface/popular",
    recommend: "https://api.bilibili.com/x/web-interface/wbi/index/top/feed/rcmd",
    regionLatest: "https://api.bilibili.com/x/web-interface/dynamic/region",
    related: "https://api.bilibili.com/x/web-interface/archive/related",
    pgcSeason: "https://api.bilibili.com/pgc/view/web/season",
    pgcPlayUrl: "https://api.bilibili.com/pgc/player/web/playurl",
    pgcFollowList: "https://api.bilibili.com/pgc/web/follow/list",
    pgcBangumiPage: "https://api.bilibili.com/pgc/season/index/result",
    pgcCinemaPage: "https://api.bilibili.com/pgc/season/index/result",
    dynamicAllVideo: "https://api.bilibili.com/x/polymer/web-dynamic/v1/feed/all",
    spaceArcSearch: "https://api.bilibili.com/x/space/wbi/arc/search",
    historyCursor: "https://api.bilibili.com/x/web-interface/history/cursor",
    toView: "https://api.bilibili.com/x/v2/history/toview/web",
    likeVideo: "https://api.bilibili.com/x/space/like/video",
    relationStat: "https://api.bilibili.com/x/relation/stat",
    upStat: "https://api.bilibili.com/x/space/upstat",
    favFolders: "https://api.bilibili.com/x/v3/fav/folder/created/list-all",
    favResources: "https://api.bilibili.com/x/v3/fav/resource/list",
    favResourceDeal: "https://api.bilibili.com/x/v3/fav/resource/deal",
    searchTypeWbi: "https://api.bilibili.com/x/web-interface/wbi/search/type",
    searchType: "https://api.bilibili.com/x/web-interface/search/type",
    searchSuggest: "https://s.search.bilibili.com/main/suggest",
    searchHotword: "https://s.search.bilibili.com/main/hotword",
    socialLike: "https://api.bilibili.com/x/web-interface/archive/like",
    socialCoinState: "https://api.bilibili.com/x/web-interface/archive/coins",
    socialCoin: "https://api.bilibili.com/x/web-interface/coin/add",
    reply: "https://api.bilibili.com/x/v2/reply",
    replyReplies: "https://api.bilibili.com/x/v2/reply/reply",
    liveAreaList: "https://api.live.bilibili.com/xlive/web-interface/v1/index/getWebAreaList",
    liveAreaRooms: "https://api.live.bilibili.com/xlive/web-interface/v1/second/getList",
    liveFollowing: "https://api.live.bilibili.com/xlive/web-ucenter/user/following",
    liveRecommendIndex: "https://api.live.bilibili.com/xlive/web-interface/v1/webMain/getList",
    liveRecommendMore: "https://api.live.bilibili.com/xlive/web-interface/v1/webMain/getMoreRecList",
    liveRoomInfo: "https://api.live.bilibili.com/xlive/web-room/v1/index/getInfoByRoom",
    livePlayInfo: "https://api.live.bilibili.com/xlive/web-room/v2/index/getRoomPlayInfo"
  };
  const now$2 = () => Date.now();
  const withQuery = (url, params = {}) => {
    const target = new URL(url);
    for (const [key, value] of Object.entries(params)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    return target.toString();
  };
  const buildHeaders = (cookie = "", headers = {}) => ({
    ...BILI_HEADERS,
    ...headers,
    ...cookie ? { Cookie: cookie } : {}
  });
  const stripHtmlTags = (value = "") => String(value || "").replace(/<[^>]+>/g, "").replace(/&quot;/g, '"').replace(/&amp;/g, "&").trim();
  const parseDuration = (value = "") => String(value || "").split(":").reduce((acc, part) => acc * 60 + (parseInt(part, 10) || 0), 0);
  const cookieValue = (cookie = "", name = "") => {
    var _a;
    const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return decodeURIComponent(((_a = String(cookie || "").match(new RegExp(`(?:^|;\\s*)${escaped}=([^;]*)`))) == null ? void 0 : _a[1]) || "");
  };
  const csrfOf = (cookie = "") => cookieValue(cookie, "bili_jct");
  const currentUid = (cookie = "", fallback = "") => cookieValue(cookie, "DedeUserID") || fallback || "";
  const ensureCookie = (payload) => {
    const cookie = String((payload == null ? void 0 : payload.cookie) || "").trim();
    if (!cookie) throw new Error("missing bilibili cookie");
    return cookie;
  };
  const formBody = (data = {}) => new URLSearchParams(Object.entries(data).filter(([, value]) => value !== void 0 && value !== null).map(([key, value]) => [key, String(value)])).toString();
  const checkApiResponse = (json2, message) => {
    if (!json2 || json2.code !== 0) throw new Error(`${message}: ${(json2 == null ? void 0 : json2.message) || (json2 == null ? void 0 : json2.msg) || (json2 == null ? void 0 : json2.code) || "unknown"}`);
  };
  function getDefaultExportFromCjs(x) {
    return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
  }
  var md5$1 = { exports: {} };
  var crypt = { exports: {} };
  (function() {
    var base64map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", crypt$1 = {
      // Bit-wise rotation left
      rotl: function(n, b) {
        return n << b | n >>> 32 - b;
      },
      // Bit-wise rotation right
      rotr: function(n, b) {
        return n << 32 - b | n >>> b;
      },
      // Swap big-endian to little-endian and vice versa
      endian: function(n) {
        if (n.constructor == Number) {
          return crypt$1.rotl(n, 8) & 16711935 | crypt$1.rotl(n, 24) & 4278255360;
        }
        for (var i = 0; i < n.length; i++)
          n[i] = crypt$1.endian(n[i]);
        return n;
      },
      // Generate an array of any length of random bytes
      randomBytes: function(n) {
        for (var bytes = []; n > 0; n--)
          bytes.push(Math.floor(Math.random() * 256));
        return bytes;
      },
      // Convert a byte array to big-endian 32-bit words
      bytesToWords: function(bytes) {
        for (var words = [], i = 0, b = 0; i < bytes.length; i++, b += 8)
          words[b >>> 5] |= bytes[i] << 24 - b % 32;
        return words;
      },
      // Convert big-endian 32-bit words to a byte array
      wordsToBytes: function(words) {
        for (var bytes = [], b = 0; b < words.length * 32; b += 8)
          bytes.push(words[b >>> 5] >>> 24 - b % 32 & 255);
        return bytes;
      },
      // Convert a byte array to a hex string
      bytesToHex: function(bytes) {
        for (var hex = [], i = 0; i < bytes.length; i++) {
          hex.push((bytes[i] >>> 4).toString(16));
          hex.push((bytes[i] & 15).toString(16));
        }
        return hex.join("");
      },
      // Convert a hex string to a byte array
      hexToBytes: function(hex) {
        for (var bytes = [], c = 0; c < hex.length; c += 2)
          bytes.push(parseInt(hex.substr(c, 2), 16));
        return bytes;
      },
      // Convert a byte array to a base-64 string
      bytesToBase64: function(bytes) {
        for (var base64 = [], i = 0; i < bytes.length; i += 3) {
          var triplet = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
          for (var j = 0; j < 4; j++)
            if (i * 8 + j * 6 <= bytes.length * 8)
              base64.push(base64map.charAt(triplet >>> 6 * (3 - j) & 63));
            else
              base64.push("=");
        }
        return base64.join("");
      },
      // Convert a base-64 string to a byte array
      base64ToBytes: function(base64) {
        base64 = base64.replace(/[^A-Z0-9+\/]/ig, "");
        for (var bytes = [], i = 0, imod4 = 0; i < base64.length; imod4 = ++i % 4) {
          if (imod4 == 0) continue;
          bytes.push((base64map.indexOf(base64.charAt(i - 1)) & Math.pow(2, -2 * imod4 + 8) - 1) << imod4 * 2 | base64map.indexOf(base64.charAt(i)) >>> 6 - imod4 * 2);
        }
        return bytes;
      }
    };
    crypt.exports = crypt$1;
  })();
  var cryptExports = crypt.exports;
  var charenc = {
    // UTF-8 encoding
    utf8: {
      // Convert a string to a byte array
      stringToBytes: function(str) {
        return charenc.bin.stringToBytes(unescape(encodeURIComponent(str)));
      },
      // Convert a byte array to a string
      bytesToString: function(bytes) {
        return decodeURIComponent(escape(charenc.bin.bytesToString(bytes)));
      }
    },
    // Binary encoding
    bin: {
      // Convert a string to a byte array
      stringToBytes: function(str) {
        for (var bytes = [], i = 0; i < str.length; i++)
          bytes.push(str.charCodeAt(i) & 255);
        return bytes;
      },
      // Convert a byte array to a string
      bytesToString: function(bytes) {
        for (var str = [], i = 0; i < bytes.length; i++)
          str.push(String.fromCharCode(bytes[i]));
        return str.join("");
      }
    }
  };
  var charenc_1 = charenc;
  /*!
   * Determine if an object is a Buffer
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   */
  var isBuffer_1 = function(obj) {
    return obj != null && (isBuffer(obj) || isSlowBuffer(obj) || !!obj._isBuffer);
  };
  function isBuffer(obj) {
    return !!obj.constructor && typeof obj.constructor.isBuffer === "function" && obj.constructor.isBuffer(obj);
  }
  function isSlowBuffer(obj) {
    return typeof obj.readFloatLE === "function" && typeof obj.slice === "function" && isBuffer(obj.slice(0, 0));
  }
  (function() {
    var crypt2 = cryptExports, utf8 = charenc_1.utf8, isBuffer2 = isBuffer_1, bin = charenc_1.bin, md52 = function(message, options) {
      if (message.constructor == String)
        if (options && options.encoding === "binary")
          message = bin.stringToBytes(message);
        else
          message = utf8.stringToBytes(message);
      else if (isBuffer2(message))
        message = Array.prototype.slice.call(message, 0);
      else if (!Array.isArray(message) && message.constructor !== Uint8Array)
        message = message.toString();
      var m = crypt2.bytesToWords(message), l = message.length * 8, a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
      for (var i = 0; i < m.length; i++) {
        m[i] = (m[i] << 8 | m[i] >>> 24) & 16711935 | (m[i] << 24 | m[i] >>> 8) & 4278255360;
      }
      m[l >>> 5] |= 128 << l % 32;
      m[(l + 64 >>> 9 << 4) + 14] = l;
      var FF = md52._ff, GG = md52._gg, HH = md52._hh, II = md52._ii;
      for (var i = 0; i < m.length; i += 16) {
        var aa = a, bb = b, cc = c, dd = d;
        a = FF(a, b, c, d, m[i + 0], 7, -680876936);
        d = FF(d, a, b, c, m[i + 1], 12, -389564586);
        c = FF(c, d, a, b, m[i + 2], 17, 606105819);
        b = FF(b, c, d, a, m[i + 3], 22, -1044525330);
        a = FF(a, b, c, d, m[i + 4], 7, -176418897);
        d = FF(d, a, b, c, m[i + 5], 12, 1200080426);
        c = FF(c, d, a, b, m[i + 6], 17, -1473231341);
        b = FF(b, c, d, a, m[i + 7], 22, -45705983);
        a = FF(a, b, c, d, m[i + 8], 7, 1770035416);
        d = FF(d, a, b, c, m[i + 9], 12, -1958414417);
        c = FF(c, d, a, b, m[i + 10], 17, -42063);
        b = FF(b, c, d, a, m[i + 11], 22, -1990404162);
        a = FF(a, b, c, d, m[i + 12], 7, 1804603682);
        d = FF(d, a, b, c, m[i + 13], 12, -40341101);
        c = FF(c, d, a, b, m[i + 14], 17, -1502002290);
        b = FF(b, c, d, a, m[i + 15], 22, 1236535329);
        a = GG(a, b, c, d, m[i + 1], 5, -165796510);
        d = GG(d, a, b, c, m[i + 6], 9, -1069501632);
        c = GG(c, d, a, b, m[i + 11], 14, 643717713);
        b = GG(b, c, d, a, m[i + 0], 20, -373897302);
        a = GG(a, b, c, d, m[i + 5], 5, -701558691);
        d = GG(d, a, b, c, m[i + 10], 9, 38016083);
        c = GG(c, d, a, b, m[i + 15], 14, -660478335);
        b = GG(b, c, d, a, m[i + 4], 20, -405537848);
        a = GG(a, b, c, d, m[i + 9], 5, 568446438);
        d = GG(d, a, b, c, m[i + 14], 9, -1019803690);
        c = GG(c, d, a, b, m[i + 3], 14, -187363961);
        b = GG(b, c, d, a, m[i + 8], 20, 1163531501);
        a = GG(a, b, c, d, m[i + 13], 5, -1444681467);
        d = GG(d, a, b, c, m[i + 2], 9, -51403784);
        c = GG(c, d, a, b, m[i + 7], 14, 1735328473);
        b = GG(b, c, d, a, m[i + 12], 20, -1926607734);
        a = HH(a, b, c, d, m[i + 5], 4, -378558);
        d = HH(d, a, b, c, m[i + 8], 11, -2022574463);
        c = HH(c, d, a, b, m[i + 11], 16, 1839030562);
        b = HH(b, c, d, a, m[i + 14], 23, -35309556);
        a = HH(a, b, c, d, m[i + 1], 4, -1530992060);
        d = HH(d, a, b, c, m[i + 4], 11, 1272893353);
        c = HH(c, d, a, b, m[i + 7], 16, -155497632);
        b = HH(b, c, d, a, m[i + 10], 23, -1094730640);
        a = HH(a, b, c, d, m[i + 13], 4, 681279174);
        d = HH(d, a, b, c, m[i + 0], 11, -358537222);
        c = HH(c, d, a, b, m[i + 3], 16, -722521979);
        b = HH(b, c, d, a, m[i + 6], 23, 76029189);
        a = HH(a, b, c, d, m[i + 9], 4, -640364487);
        d = HH(d, a, b, c, m[i + 12], 11, -421815835);
        c = HH(c, d, a, b, m[i + 15], 16, 530742520);
        b = HH(b, c, d, a, m[i + 2], 23, -995338651);
        a = II(a, b, c, d, m[i + 0], 6, -198630844);
        d = II(d, a, b, c, m[i + 7], 10, 1126891415);
        c = II(c, d, a, b, m[i + 14], 15, -1416354905);
        b = II(b, c, d, a, m[i + 5], 21, -57434055);
        a = II(a, b, c, d, m[i + 12], 6, 1700485571);
        d = II(d, a, b, c, m[i + 3], 10, -1894986606);
        c = II(c, d, a, b, m[i + 10], 15, -1051523);
        b = II(b, c, d, a, m[i + 1], 21, -2054922799);
        a = II(a, b, c, d, m[i + 8], 6, 1873313359);
        d = II(d, a, b, c, m[i + 15], 10, -30611744);
        c = II(c, d, a, b, m[i + 6], 15, -1560198380);
        b = II(b, c, d, a, m[i + 13], 21, 1309151649);
        a = II(a, b, c, d, m[i + 4], 6, -145523070);
        d = II(d, a, b, c, m[i + 11], 10, -1120210379);
        c = II(c, d, a, b, m[i + 2], 15, 718787259);
        b = II(b, c, d, a, m[i + 9], 21, -343485551);
        a = a + aa >>> 0;
        b = b + bb >>> 0;
        c = c + cc >>> 0;
        d = d + dd >>> 0;
      }
      return crypt2.endian([a, b, c, d]);
    };
    md52._ff = function(a, b, c, d, x, s, t) {
      var n = a + (b & c | ~b & d) + (x >>> 0) + t;
      return (n << s | n >>> 32 - s) + b;
    };
    md52._gg = function(a, b, c, d, x, s, t) {
      var n = a + (b & d | c & ~d) + (x >>> 0) + t;
      return (n << s | n >>> 32 - s) + b;
    };
    md52._hh = function(a, b, c, d, x, s, t) {
      var n = a + (b ^ c ^ d) + (x >>> 0) + t;
      return (n << s | n >>> 32 - s) + b;
    };
    md52._ii = function(a, b, c, d, x, s, t) {
      var n = a + (c ^ (b | ~d)) + (x >>> 0) + t;
      return (n << s | n >>> 32 - s) + b;
    };
    md52._blocksize = 16;
    md52._digestsize = 16;
    md5$1.exports = function(message, options) {
      if (message === void 0 || message === null)
        throw new Error("Illegal argument " + message);
      var digestbytes = crypt2.wordsToBytes(md52(message, options));
      return options && options.asBytes ? digestbytes : options && options.asString ? bin.bytesToString(digestbytes) : crypt2.bytesToHex(digestbytes);
    };
  })();
  var md5Exports = md5$1.exports;
  const md5 = /* @__PURE__ */ getDefaultExportFromCjs(md5Exports);
  const MIXIN_KEY_ENC_TAB = [
    46,
    47,
    18,
    2,
    53,
    8,
    23,
    32,
    15,
    50,
    10,
    31,
    58,
    3,
    45,
    35,
    27,
    43,
    5,
    49,
    33,
    9,
    42,
    19,
    29,
    28,
    14,
    39,
    12,
    38,
    41,
    13,
    37,
    48,
    7,
    16,
    24,
    55,
    40,
    61,
    26,
    17,
    0,
    1,
    60,
    51,
    30,
    4,
    22,
    25,
    54,
    21,
    56,
    59,
    6,
    63,
    57,
    62,
    11,
    36,
    20,
    34,
    44,
    52
  ];
  let wbiKeys = null;
  const filterWbiValue = (value) => String(value).replace(/[!'()*]/g, "");
  const genMixinKey = (raw) => {
    let result = "";
    for (const i of MIXIN_KEY_ENC_TAB) {
      if (i < raw.length) result += raw[i];
    }
    return result.slice(0, 32);
  };
  const signWbi = (params, keys) => {
    const wts = Math.floor(now$2() / 1e3).toString();
    const withWts = { ...params, wts };
    const mixinKey = genMixinKey(`${keys.imgKey}${keys.subKey}`);
    const query = Object.entries(withWts).sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(filterWbiValue(value))}`).join("&");
    return { ...params, wts, w_rid: md5(query + mixinKey) };
  };
  const forward$1 = async (client, url, { method = "GET", headers, body, responseEncoding = "text" }) => {
    var _a, _b;
    const response = await client.fetch("/api/network/forwardProxy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url,
        method,
        headers: Object.entries(headers || {}).map(([key, value]) => ({ [key]: value })),
        payloadEncoding: "text",
        ...responseEncoding !== "text" ? { responseEncoding } : {},
        ...body ? { payload: body, contentType: headers["Content-Type"] || headers["content-type"] || "application/json" } : {}
      })
    });
    const result = JSON.parse(await response.text());
    if ((result == null ? void 0 : result.code) !== 0) throw new Error((result == null ? void 0 : result.msg) || "forward request failed");
    if (((_a = result.data) == null ? void 0 : _a.status) >= 400) throw new Error(`HTTP ${result.data.status}`);
    return ((_b = result.data) == null ? void 0 : _b.body) || "";
  };
  const fetchText = async (client, url, { cookie = "", headers = {}, method = "GET", body } = {}) => {
    const request2 = {
      method,
      headers: buildHeaders(cookie, headers),
      body
    };
    if (/^https?:\/\//i.test(url)) return forward$1(client, url, request2);
    const response = await client.fetch(url, request2);
    if ((response == null ? void 0 : response.status) && response.status >= 400) throw new Error(`HTTP ${response.status}`);
    return await response.text();
  };
  const fetchJson = async (client, url, options) => JSON.parse(await fetchText(client, url, options));
  const base64Bytes = (value = "") => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean2 = String(value || "").replace(/[\r\n\s]/g, "").replace(/=+$/, "");
    const bytes = [];
    let buffer = 0;
    let bits = 0;
    for (const char of clean2) {
      const next = chars.indexOf(char);
      if (next < 0) continue;
      buffer = buffer << 6 | next;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        bytes.push(buffer >> bits & 255);
      }
    }
    return new Uint8Array(bytes);
  };
  const fetchBytes = async (client, url, options = {}) => {
    const body = await forward$1(client, url, {
      method: options.method || "GET",
      headers: buildHeaders(options.cookie || "", options.headers || {}),
      body: options.body,
      responseEncoding: "base64"
    });
    return base64Bytes(body);
  };
  const postFormJson = (client, url, data, { cookie = "", headers = {} } = {}) => fetchJson(client, url, {
    cookie,
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", ...headers },
    body: formBody(data)
  });
  const ensureWbiKeys = async (client, cookie) => {
    var _a, _b, _c;
    const nowSec = Math.floor(now$2() / 1e3);
    if (wbiKeys && nowSec - wbiKeys.fetchedAtEpochSec < 12 * 60 * 60) return wbiKeys;
    const json2 = await fetchJson(client, API.nav, { cookie });
    const wbi = ((_a = json2 == null ? void 0 : json2.data) == null ? void 0 : _a.wbi_img) || {};
    wbiKeys = {
      imgKey: ((_b = String(wbi.img_url || "").split("/").pop()) == null ? void 0 : _b.split(".")[0]) || "",
      subKey: ((_c = String(wbi.sub_url || "").split("/").pop()) == null ? void 0 : _c.split(".")[0]) || "",
      fetchedAtEpochSec: nowSec
    };
    if (!wbiKeys.imgKey || !wbiKeys.subKey) throw new Error("Bilibili WBI key unavailable");
    return wbiKeys;
  };
  const signedWbiUrl = async (client, url, params, cookie) => withQuery(url, signWbi(params, await ensureWbiKeys(client, cookie)));
  const TV_LOGIN = {
    appKey: "dfca71928277209b",
    appSec: "b5475a8825547a4fc26c7d518eaaa02e",
    localId: "0",
    platform: "android",
    mobiApp: "android_hd",
    userAgent: "Mozilla/5.0 BiliDroid/2.0.1 (bbcallen@gmail.com) os/android model/android_hd mobi_app/android_hd build/2001100 channel/master innerVer/2001100 osVer/15 network/2"
  };
  const tvHeaders = {
    Referer: "https://passport.bilibili.com/",
    Origin: "https://passport.bilibili.com",
    "User-Agent": TV_LOGIN.userAgent,
    "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
    buvid: "",
    env: "prod",
    "app-key": "android_hd",
    "x-bili-trace-id": "11111111111111111111111111111111:1111111111111111:0:0",
    "x-bili-aurora-eid": "",
    "x-bili-aurora-zone": "",
    "bili-http-engine": "cronet"
  };
  const signApp = (params = {}) => {
    const out = { ...params, appkey: TV_LOGIN.appKey, ts: Math.floor(Date.now() / 1e3) };
    const query = Object.entries(out).sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`).join("&");
    return { ...out, sign: md5(query + TV_LOGIN.appSec) };
  };
  const checkConnection$1 = async (client, payload) => {
    var _a;
    const cookie = ensureCookie(payload);
    const json2 = await fetchJson(client, API.nav, { cookie });
    if ((json2 == null ? void 0 : json2.code) === -101 || (json2 == null ? void 0 : json2.code) === -111 || ((_a = json2.data) == null ? void 0 : _a.isLogin) === false) throw new Error("登录已过期");
    checkApiResponse(json2, "获取用户信息失败");
    const d = json2.data || {}, vip = d.vip || {}, level = d.level_info || {};
    const profile = {
      uid: d.mid,
      uname: d.uname,
      face: d.face || "",
      vipStatus: vip.status || 0,
      vipType: vip.type || 0,
      vipStatusText: vip.status === 1 ? vip.type === 2 ? "年度大会员" : "月度大会员" : "普通用户",
      level: level.current_level || 0,
      coins: typeof d.money === "number" ? d.money : typeof d.coins === "number" ? d.coins : 0,
      experience: level.current_exp || 0
    };
    return { connected: true, message: "连接成功", profile };
  };
  const createAccount = (userInfo, cookie) => ({
    id: `bilibili_${userInfo.uid || userInfo.mid}`,
    type: "bilibili",
    name: userInfo.uname,
    cookie,
    uid: String(userInfo.uid || userInfo.mid || ""),
    uname: userInfo.uname,
    face: userInfo.face,
    vipStatus: userInfo.vipStatus,
    vip_type: userInfo.vipType,
    level_info: { current_level: userInfo.level, current_exp: userInfo.experience },
    money: userInfo.coins,
    active: true
  });
  const extractQrCookie = (pollData) => {
    var _a, _b;
    const data = (pollData == null ? void 0 : pollData.data) || {};
    if ((_b = (_a = data.cookie_info) == null ? void 0 : _a.cookies) == null ? void 0 : _b.length) {
      return data.cookie_info.cookies.filter((item) => item.name && item.value).map((item) => `${item.name}=${item.value}`).join("; ");
    }
    const url = data.url || "";
    const params = new URL(url || "https://www.bilibili.com").searchParams;
    return ["SESSDATA", "bili_jct", "DedeUserID", "DedeUserID__ckMd5", "Expires"].filter((key) => params.get(key)).map((key) => `${key}=${encodeURIComponent(params.get(key))}`).join("; ");
  };
  const qrLogin = async (client) => {
    var _a, _b, _c;
    const json2 = await fetchJson(client, withQuery(API.qrTvLogin, signApp({
      local_id: TV_LOGIN.localId,
      platform: TV_LOGIN.platform,
      mobi_app: TV_LOGIN.mobiApp
    })), { method: "POST", headers: tvHeaders });
    checkApiResponse(json2, "生成二维码失败");
    const url = ((_a = json2.data) == null ? void 0 : _a.url) || "";
    const key = ((_b = json2.data) == null ? void 0 : _b.qrcode_key) || ((_c = json2.data) == null ? void 0 : _c.auth_code) || "";
    if (!url || !key) throw new Error("二维码数据不完整");
    return {
      data: url,
      qrcode: url,
      key,
      message: "请使用哔哩哔哩 App 扫码并确认登录"
    };
  };
  const qrPoll = async (client, payload) => {
    var _a;
    const key = String((payload == null ? void 0 : payload.key) || "");
    if (!key) throw new Error("missing qr key");
    const json2 = await fetchJson(client, withQuery(API.qrTvPoll, signApp({ auth_code: key, local_id: TV_LOGIN.localId })), { method: "POST", headers: tvHeaders });
    const code = Number(((_a = json2.data) == null ? void 0 : _a.code) ?? json2.code);
    const messages = {
      86101: "等待扫码...",
      86090: "已扫码，请在手机端确认",
      86039: "等待扫码...",
      86038: "二维码已失效，请刷新"
    };
    if (code !== 0) return { done: false, code, message: messages[code] || json2.message || `状态：${code}` };
    const cookie = extractQrCookie(json2);
    if (!cookie) throw new Error("未返回 Cookie");
    const profile = (await checkConnection$1(client, { cookie })).profile;
    return { done: true, code: 0, message: "登录成功", account: createAccount(profile, cookie) };
  };
  const driverState = /* @__PURE__ */ new Map();
  const stateKey = (cookie = "") => md5(String(cookie || "").slice(0, 4096));
  const getState = (cookie = "") => {
    const key = stateKey(cookie);
    if (!driverState.has(key)) driverState.set(key, { historyCursor: null, dynamicOffset: null, pgcState: {} });
    return driverState.get(key);
  };
  const LEGACY_PROTOCOLS = [
    ["bdpan://path/", "baidudrive", "path"],
    ["alipan://file/", "alidrive", "file"],
    ["pan115://file/", "pan115", "file"],
    ["pan123://file/", "pan123", "file"],
    ["quarktv://file/", "quarktv", "file"],
    ["quark://file/", "quarktv", "file"],
    ["webdav://path/", "webdav", "path"],
    ["onedrive://file/", "onedrive", "file"],
    ["openlist://path/", "openlist", "path"],
    ["s3://file/", "s3", "file"],
    ["tvbox://file/", "tvbox", "file"],
    ["tvbox://video/", "tvbox", "video"]
  ];
  new Set(LEGACY_PROTOCOLS.map(([, source]) => source).filter((source) => source !== "tvbox"));
  const DOUYIN_PAGE_HOSTS = ["douyin.com", "www.douyin.com", "www-hj.douyin.com", "m.douyin.com", "iesdouyin.com", "www.iesdouyin.com", "v.douyin.com"];
  const SOCIAL_SITES = {
    douyin: { name: "抖音", mediaType: "video", cookieHosts: [], pageHosts: ["douyin.com", "iesdouyin.com"], mediaHosts: ["douyin.com", "iesdouyin.com", "snssdk.com", "amemv.com", "365yg.com", "douyinvod.com", "douyinpic.com", "douyinstatic.com", "douyincdn.com", "byteimg.com", "bytecdn.cn", "bytedance.com", "bytednsdoc.com", "bytegecko.com", "bytetos.com", "bytegoofy.com", "yhgfb-cn-static.com", "zijieapi.com", "ibytedapm.com", "bytescm.com", "byted-static.com", "huoshanstatic.com", "pstatp.com", "toutiaoimg.com"] },
    kuaishou: { name: "快手", mediaType: "video", cookieHosts: [], pageHosts: ["kuaishou.com", "gifshow.com", "chenzhongtech.com"], mediaHosts: ["kwai.net", "kwaicdn.com", "kwimgs.com", "yximgs.com", "kuaishou.com", "gifshow.com", "kuaishouzt.com", "ksapisrv.com", "ksyun.com", "kscscdn.com", "kuaishouvod.com", "kwaivod.com", "chenzhongtech.com"] },
    weibo: { name: "微博", mediaType: "video", cookieHosts: [], pageHosts: ["weibo.com", "weibo.cn", "t.cn"], mediaHosts: ["weibocdn.com", "weibocdn.net", "sinaimg.cn", "sina.com.cn", "sina.com", "weibo.com", "weibo.cn"] },
    xiaohongshu: { name: "小红书", mediaType: "video", cookieHosts: ["xiaohongshu.com"], pageHosts: ["xiaohongshu.com", "xhslink.com", "xhslink.cn"], mediaHosts: ["xhscdn.com", "xhscdn.net", "xiaohongshu.com"] },
    acfun: { name: "AcFun", mediaType: "video", cookieHosts: [], pageHosts: ["acfun.cn", "acfun.com", "aixifan.com"], mediaHosts: ["acfun.cn", "acfun.com", "aixifan.com", "acfunvideo.cn", "kwai.net", "kwaicdn.com"] },
    pixiv: { name: "Pixiv", mediaType: "image", cookieHosts: ["pixiv.net"], pageHosts: ["pixiv.net"], mediaHosts: ["pximg.net", "pixiv.net"] }
  };
  const owns$1 = (host, roots) => roots.some((root) => host === root || host.endsWith(`.${root}`));
  const LINK_IN_TEXT = /(?:^|[^\w.-])((?:https?:\/\/)?(?:(?:[a-z\d-]+\.)*)(?:douyin\.com|iesdouyin\.com|kuaishou\.com|gifshow\.com|chenzhongtech\.com|weibo\.com|weibo\.cn|t\.cn|xiaohongshu\.com|xhslink\.com|xhslink\.cn|acfun\.cn|acfun\.com|aixifan\.com|pixiv\.net)\/[^\s<>"'`]+)/i;
  const isValidPath = (source, url) => {
    const path = url.pathname;
    switch (source) {
      case "douyin":
        return url.hostname === "v.douyin.com" ? path.length > 1 : /^\/(?:video|share\/video)\/\d+(?:\/|$)/i.test(path);
      case "kuaishou":
        return url.hostname.startsWith("v.") || /\/(?:short-video|photo|fw\/photo|fw\/long-video)\//i.test(path);
      case "weibo":
        return url.hostname === "t.cn" ? path.length > 1 : /\/(?:status|detail|show|tv\/show)\//i.test(path) || /^\/\d+\/[\da-z]+\/?$/i.test(path);
      case "xiaohongshu":
        return url.hostname === "xhslink.com" || url.hostname === "xhslink.cn" || /\/(?:explore|discovery\/item)\/[\da-z]+/i.test(path);
      case "acfun":
        return /\/v\/ac\d+/i.test(path) || /\/ac\d+/i.test(path) || /^\/v\/?$/i.test(path) && /^\d+$/.test(url.searchParams.get("ac") || "");
      case "pixiv":
        return /\/artworks\/\d+/i.test(path) || /illust\.php$/i.test(path) && /^\d+$/.test(url.searchParams.get("illust_id") || "");
    }
  };
  const normalizeSocialUrl = (value = "", expectedSource) => {
    var _a;
    const input = String(value || "").trim();
    if (!input || input.length > 8192) return null;
    const candidate = (/^https?:\/\/\S+$/i.test(input) ? input : ((_a = input.match(LINK_IN_TEXT)) == null ? void 0 : _a[1]) || input).replace(/[),.;!?，。！？、；：\]】》〉]+$/u, "");
    try {
      const url = new URL(/^https?:\/\//i.test(candidate) ? candidate : `https://${candidate}`);
      const host = url.hostname.toLowerCase().replace(/\.$/, "");
      if (url.username || url.password || url.port && !["80", "443"].includes(url.port)) return null;
      const source = (expectedSource ? [expectedSource] : Object.keys(SOCIAL_SITES)).find((source2) => owns$1(host, SOCIAL_SITES[source2].pageHosts) && isValidPath(source2, url));
      if (!source) return null;
      url.protocol = "https:";
      url.port = "";
      url.hash = "";
      if (!["xiaohongshu", "kuaishou", "weibo"].includes(source)) {
        for (const key of ["a", "accountId", "cloudAccountId"]) url.searchParams.delete(key);
      }
      return { source, url: url.toString() };
    } catch {
    }
    return null;
  };
  const normalizeDouyinShareUrl = (value = "") => {
    var _a;
    return ((_a = normalizeSocialUrl(value, "douyin")) == null ? void 0 : _a.url) || "";
  };
  const formats = {
    video: ["mp4", "mkv", "avi", "mov", "wmv", "webm", "m3u8", "mpd", "m4v", "mpg", "mpeg", "3gp"],
    audio: ["mp3", "wav", "aac", "m4a", "flac", "ogg"],
    image: ["jpg", "jpeg", "png", "gif", "bmp", "webp", "svg", "ico", "heic", "heif"],
    flv: ["flv"],
    mpegts: ["ts", "m2ts"],
    torrent: ["torrent"],
    subtitle: ["srt", "ass", "ssa", "vtt", "lrc", "json"],
    danmaku: ["xml"]
  };
  new Map(Object.entries(formats).flatMap(([type, extensions]) => extensions.map((ext) => [ext, type])));
  const MEDIA_FILE_TYPES = Object.keys(formats).filter((type) => type !== "subtitle" && type !== "danmaku");
  MEDIA_FILE_TYPES.flatMap((type) => formats[type]);
  const clean = (value = "") => String(value || "").trim();
  const BV_PATTERN = "BV[0-9A-Za-z]{10}";
  const BV_REGEX = new RegExp(`^${BV_PATTERN}$`);
  const BV_EXTRACT_REGEX = new RegExp(BV_PATTERN);
  const isValidBvid = (value) => BV_REGEX.test(clean(value));
  const pickBvid = (...values) => values.map((value) => clean(value)).map((value) => {
    var _a;
    return isValidBvid(value) ? value : ((_a = value.match(BV_EXTRACT_REGEX)) == null ? void 0 : _a[0]) || "";
  }).find(Boolean) || "";
  const proxyAssetUrl = (url = "") => {
    const value = String(url || "").trim();
    if (!value) return "";
    return value.startsWith("//") ? `https:${value}` : value.replace(/^http:\/\//i, "https://");
  };
  const createFolder = (id, name, size = 0, thumbnail = "") => ({
    id,
    name,
    title: name,
    path: `/${id}`.replace(/\/+/g, "/"),
    isDir: true,
    is_dir: true,
    type: "folder",
    source: "bilibili",
    sourcePath: `/${id}`.replace(/\/+/g, "/"),
    url: "#",
    size,
    created: now$2(),
    modified: now$2(),
    thumbnail: proxyAssetUrl(thumbnail)
  });
  const toMediaItem$1 = (file = {}, type = "video") => {
    const isDir = !!file.isDir || !!file.is_dir;
    const bvid = pickBvid(file.bvid, file.id, file.path, file.url, file.arcurl);
    const sid = file.seasonId || file.season_id || file.id || "";
    const path = file.path || `/${type}/${type === "video" ? bvid : sid}`;
    const title = file.name || file.title || "";
    const base = {
      id: isDir ? `bilibili-folder-${file.id || path}` : `bilibili-${type === "video" ? bvid : sid}`,
      name: title,
      title,
      type: isDir ? "folder" : "video",
      source: "bilibili",
      sourcePath: path,
      path,
      url: isDir ? "#" : `bilibili://${path}`,
      originalUrl: isDir ? "#" : `bilibili://${path}`,
      thumbnail: proxyAssetUrl(file.thumbnail || file.coverUrl || file.pic || file.cover || ""),
      added: file.created || file.pubDate || file.pubdate || now$2(),
      duration: file.duration || file.durationSec || 0,
      size: file.size || 0,
      is_dir: isDir,
      isDir
    };
    if (isDir) return base;
    return {
      ...base,
      bvid: file.bvid,
      aid: file.aid,
      cid: file.cid,
      page: file.page,
      ownerName: file.ownerName,
      ownerMid: file.ownerMid,
      ownerFace: file.ownerFace,
      seasonTypeName: file.seasonTypeName || file.seasonType,
      seasonStyles: file.seasonStyles || file.styles,
      badge: file.badge,
      viewCount: file.view ?? file.viewCount,
      danmakuCount: file.danmaku ?? file.danmakuCount,
      likeCount: file.likeCount,
      coinCount: file.coinCount,
      favoriteCount: file.favoriteCount,
      shareCount: file.shareCount,
      replyCount: file.replyCount,
      pubDate: file.pubDate || file.pubdate,
      ctime: file.ctime,
      desc: file.desc,
      tname: file.tname,
      copyright: file.copyright
    };
  };
  const toLiveItem = (room = {}) => ({
    id: `bilibili-live-${room.roomId || room.roomid}`,
    name: room.title || "",
    title: room.title || "",
    path: `live/${room.roomId || room.roomid}`,
    sourcePath: `live/${room.roomId || room.roomid}`,
    isDir: false,
    is_dir: false,
    size: 0,
    created: now$2(),
    modified: now$2(),
    source: "bilibili",
    thumbnail: proxyAssetUrl(room.cover || room.coverUrl || room.user_cover || ""),
    ownerName: room.uname || "",
    ownerMid: room.uid || room.mid,
    viewCount: room.online || 0,
    type: "video",
    url: `bilibili://live/${room.roomId || room.roomid}`,
    originalUrl: `bilibili://live/${room.roomId || room.roomid}`,
    _isLive: true,
    _liveRoomId: room.roomId || room.roomid,
    _liveTitle: room.title || "",
    _liveUname: room.uname || "",
    _liveOnline: room.online || 0,
    _liveArea: room.areaName || room.cate_name || "",
    _liveParentArea: room.parentAreaName || ""
  });
  const withPage = (items, hasMore, ps = 20) => Object.assign((items || []).slice(0, ps), { hasMore: !!hasMore });
  const parseVideoCard = (item = {}) => {
    var _a, _b, _c, _d, _e;
    const bvid = pickBvid(item.bvid, item.arcurl, item.url, item.uri, item.share_url);
    return bvid ? {
      bvid,
      aid: item.aid,
      cid: item.cid,
      title: stripHtmlTags(item.title || ""),
      coverUrl: item.pic || item.cover || "",
      durationSec: item.duration || 0,
      ownerName: ((_a = item.owner) == null ? void 0 : _a.name) || item.author || "",
      ownerFace: (_b = item.owner) == null ? void 0 : _b.face,
      ownerMid: ((_c = item.owner) == null ? void 0 : _c.mid) || item.mid,
      view: ((_d = item.stat) == null ? void 0 : _d.view) ?? item.play,
      danmaku: ((_e = item.stat) == null ? void 0 : _e.danmaku) ?? item.video_review,
      pubDate: item.pubdate || item.ctime,
      pubDateText: item.pub_location
    } : null;
  };
  const parseVideoCards = (items = []) => items.map(parseVideoCard).filter(Boolean);
  const parseVideoInfo = (d = {}) => ({
    bvid: d.bvid,
    aid: d.aid,
    title: d.title || "",
    pic: d.pic || "",
    desc: d.desc || "",
    tname: d.tname || "",
    copyright: d.copyright || 0,
    pubdate: d.pubdate || 0,
    ctime: d.ctime || 0,
    owner: d.owner || {},
    stat: d.stat || {},
    duration: d.duration || 0,
    pages: d.pages || [],
    ugc_season: d.ugc_season
  });
  const fetchView = async (client, cookie, bvid = "", aid = 0) => {
    const json2 = await fetchJson(client, withQuery(API.view, bvid ? { bvid } : { aid }), { cookie });
    checkApiResponse(json2, "get video info failed");
    return parseVideoInfo(json2.data || {});
  };
  const rootMenu = () => [
    ["popular", "热门视频"],
    ["recommend", "推荐视频"],
    ["zone", "分区视频"],
    ["bangumi", "番剧"],
    ["cinema", "影视"],
    ["dynamic", "动态"],
    ["live", "直播"],
    ["my", "我的"]
  ].map(([id, name]) => createFolder(id, name));
  const myMenu = () => [
    ["my/favorite", "收藏夹"],
    ["my/history", "历史记录"],
    ["my/bangumi", "追番"],
    ["my/drama", "追剧"],
    ["my/watchlater", "稍后再看"],
    ["my/like", "点赞"]
  ].map(([id, name]) => createFolder(id, name));
  const parsePath = (path = "") => {
    const pageMatch = String(path).match(/[?&]page=(\d+)/);
    return {
      page: pageMatch ? parseInt(pageMatch[1], 10) || 1 : 1,
      cleanPath: (pageMatch ? String(path).replace(/\?.*$/, "") : String(path)).replace(/^\/|\/$/g, "") || "root"
    };
  };
  const listHistory = async (client, cookie, page, ps) => {
    var _a, _b;
    const state = getState(cookie);
    if (page === 1) state.historyCursor = null;
    const cursor = state.historyCursor || {};
    const json2 = await fetchJson(client, withQuery(API.historyCursor, {
      max: cursor.max || 0,
      view_at: cursor.viewAt || cursor.view_at || 0,
      ps,
      type: "archive"
    }), { cookie });
    checkApiResponse(json2, "get history failed");
    state.historyCursor = ((_a = json2.data) == null ? void 0 : _a.cursor) || null;
    return withPage(parseVideoCards(((_b = json2.data) == null ? void 0 : _b.list) || []).map((v) => toMediaItem$1(v)), !!state.historyCursor, ps);
  };
  const listDynamic = async (client, cookie, page, ps) => {
    var _a, _b;
    const state = getState(cookie);
    if (page === 1) state.dynamicOffset = null;
    const json2 = await fetchJson(client, withQuery(API.dynamicAllVideo, {
      type: "video",
      offset: state.dynamicOffset || "",
      timezone_offset: "-480"
    }), { cookie });
    checkApiResponse(json2, "get dynamic failed");
    state.dynamicOffset = ((_a = json2.data) == null ? void 0 : _a.offset) || "";
    const items = (((_b = json2.data) == null ? void 0 : _b.items) || []).map((item) => {
      var _a2, _b2, _c;
      return (_c = (_b2 = (_a2 = item == null ? void 0 : item.modules) == null ? void 0 : _a2.module_dynamic) == null ? void 0 : _b2.major) == null ? void 0 : _c.archive;
    }).filter(Boolean).map((archive) => toMediaItem$1(parseVideoCard({
      bvid: archive.bvid,
      aid: archive.aid,
      title: archive.title,
      pic: archive.cover,
      duration: archive.duration,
      owner: archive.author,
      stat: archive.stat,
      pubdate: archive.pub_ts
    })));
    return withPage(items, !!state.dynamicOffset, ps);
  };
  const listPopular = async (client, cookie, page, ps) => {
    var _a, _b;
    const json2 = await fetchJson(client, withQuery(API.popular, { pn: page, ps }), { cookie });
    checkApiResponse(json2, "get popular failed");
    return withPage(parseVideoCards(((_a = json2.data) == null ? void 0 : _a.list) || []).map((v) => toMediaItem$1(v)), !((_b = json2.data) == null ? void 0 : _b.no_more), ps);
  };
  const listRecommend = async (client, cookie, page, ps) => {
    var _a;
    const url = await signedWbiUrl(client, API.recommend, { ps, fresh_idx: page, fresh_idx_1h: page, fetch_row: "1", feed_version: "V8" }, cookie);
    const json2 = await fetchJson(client, url, { cookie });
    return withPage(parseVideoCards(((_a = json2.data) == null ? void 0 : _a.item) || []).map((v) => toMediaItem$1(v)), true, ps);
  };
  const listZone = async (client, cookie, id, page, ps) => {
    var _a, _b;
    if (!id) return [
      [1, "动画"],
      [3, "音乐"],
      [129, "舞蹈"],
      [4, "游戏"],
      [36, "知识"],
      [188, "科技"],
      [160, "生活"],
      [211, "美食"],
      [217, "动物圈"],
      [119, "鬼畜"],
      [155, "时尚"],
      [5, "娱乐"],
      [181, "影视"]
    ].map(([zid, name]) => createFolder(`zone/${zid}`, name));
    const json2 = await fetchJson(client, withQuery(API.regionLatest, { rid: id, pn: page, ps }), { cookie });
    checkApiResponse(json2, "get region failed");
    const pageInfo = ((_a = json2.data) == null ? void 0 : _a.page) || {};
    const total = pageInfo.count || 0;
    return withPage(parseVideoCards(((_b = json2.data) == null ? void 0 : _b.archives) || []).map((v) => toMediaItem$1(v)), total ? (pageInfo.num || page) * (pageInfo.size || ps) < total : true, ps);
  };
  const listPgc = async (client, cookie, type, page, ps) => {
    var _a, _b, _c, _d;
    const json2 = await fetchJson(client, withQuery(type === "bangumi" ? API.pgcBangumiPage : API.pgcCinemaPage, {
      season_type: type === "bangumi" ? 1 : 2,
      type: 1,
      sort: 0,
      page,
      pagesize: ps
    }), { cookie });
    const items = (((_a = json2.data) == null ? void 0 : _a.list) || ((_b = json2.result) == null ? void 0 : _b.list) || []).map((item) => toMediaItem$1({
      seasonId: item.season_id || item.seasonId,
      title: item.title,
      coverUrl: item.cover,
      badge: item.badge,
      seasonType: item.season_type_name,
      path: `/bangumi/${item.season_id || item.seasonId}`
    }, "bangumi")).filter((item) => item.sourcePath !== "/bangumi/undefined");
    const total = ((_c = json2.data) == null ? void 0 : _c.total) || ((_d = json2.result) == null ? void 0 : _d.total) || 0;
    return withPage(items, total ? page * ps < total : items.length >= ps, ps);
  };
  const listMy = async (client, cookie, id, page, ps, account = {}) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    const uid = currentUid(cookie, account.uid);
    if (!id) return myMenu();
    if (id === "history") return listHistory(client, cookie, page, ps);
    if (id === "watchlater") {
      const json2 = await fetchJson(client, API.toView, { cookie });
      checkApiResponse(json2, "get watch later failed");
      return (((_a = json2.data) == null ? void 0 : _a.list) || []).map((v) => toMediaItem$1(parseVideoCard(v))).filter(Boolean);
    }
    if (id === "like") {
      const json2 = await fetchJson(client, withQuery(API.likeVideo, { vmid: uid, pn: page, ps }), { cookie });
      checkApiResponse(json2, "get liked videos failed");
      return withPage(parseVideoCards(((_b = json2.data) == null ? void 0 : _b.list) || []).map((v) => toMediaItem$1(v)), (((_d = (_c = json2.data) == null ? void 0 : _c.page) == null ? void 0 : _d.count) || 0) > page * ps, ps);
    }
    if (id === "bangumi" || id === "drama") {
      const json2 = await fetchJson(client, withQuery(API.pgcFollowList, { vmid: uid, type: id === "bangumi" ? 1 : 2, pn: page, ps, follow_status: 0 }), { cookie });
      checkApiResponse(json2, "get pgc follow failed");
      return withPage((((_e = json2.data) == null ? void 0 : _e.list) || []).map((b) => toMediaItem$1({
        seasonId: b.season_id,
        title: b.title,
        coverUrl: b.cover,
        path: `/bangumi/${b.season_id}`
      }, "bangumi")), (((_f = json2.data) == null ? void 0 : _f.total) || 0) > page * ps, ps);
    }
    if (id === "favorite") {
      const json2 = await fetchJson(client, withQuery(API.favFolders, { up_mid: uid, type: 2, web_location: "333.1387" }), { cookie });
      checkApiResponse(json2, "get favorite folders failed");
      return (((_g = json2.data) == null ? void 0 : _g.list) || []).map((f) => createFolder(`my/favorite/${f.id}`, f.title, f.media_count, f.cover));
    }
    if (id.startsWith("favorite/")) {
      const mediaId = id.replace("favorite/", "");
      const json2 = await fetchJson(client, withQuery(API.favResources, { media_id: mediaId, pn: page, ps, keyword: "", order: "mtime", type: 0, tid: 0, platform: "web" }), { cookie });
      checkApiResponse(json2, "get favorite resources failed");
      return withPage(parseVideoCards(((_h = json2.data) == null ? void 0 : _h.medias) || []).map((v) => toMediaItem$1(v)), !!((_i = json2.data) == null ? void 0 : _i.has_more), ps);
    }
    return [];
  };
  const listUser = async (client, cookie, id, page, ps) => {
    var _a, _b, _c;
    const mid = parseInt(id, 10);
    if (!mid) return [];
    const url = await signedWbiUrl(client, API.spaceArcSearch, { mid, pn: page, ps, index: 1, order: "pubdate" }, cookie);
    const json2 = await fetchJson(client, url, { cookie });
    checkApiResponse(json2, "get user videos failed");
    const pageInfo = ((_a = json2.data) == null ? void 0 : _a.page) || {};
    return withPage(parseVideoCards(((_c = (_b = json2.data) == null ? void 0 : _b.list) == null ? void 0 : _c.vlist) || []).map((v) => toMediaItem$1(v)), (pageInfo.count || 0) > page * ps, ps);
  };
  const listLive = async (client, cookie, id, page, ps) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    if (!id) return [
      ["live/following", "关注主播"],
      ["live/recommend", "推荐直播"],
      ["live/area", "直播分区"]
    ].map(([key, name]) => createFolder(key, name));
    if (id === "following") {
      const json2 = await fetchJson(client, withQuery(API.liveFollowing, { page, page_size: ps }), { cookie, headers: { Referer: "https://live.bilibili.com/" } });
      checkApiResponse(json2, "get live following failed");
      const list = ((_a = json2.data) == null ? void 0 : _a.list) || ((_b = json2.data) == null ? void 0 : _b.rooms) || [];
      return withPage(list.map((room) => toLiveItem({
        roomId: room.roomid || room.room_id,
        uid: room.uid,
        title: room.title,
        uname: room.uname,
        cover: room.face || room.cover_from_user || room.keyframe,
        online: room.online,
        areaName: room.area_name
      })), !!((_c = json2.data) == null ? void 0 : _c.has_more), ps);
    }
    if (id === "recommend") {
      const json2 = await fetchJson(client, withQuery(page <= 1 ? API.liveRecommendIndex : API.liveRecommendMore, { platform: "web", page }), { cookie, headers: { Referer: "https://live.bilibili.com/" } });
      const rooms = (((_d = json2.data) == null ? void 0 : _d.recommend_room_list) || ((_e = json2.data) == null ? void 0 : _e.list) || ((_f = json2.data) == null ? void 0 : _f.card_list) || []).flatMap((item) => (item == null ? void 0 : item.list) || (item == null ? void 0 : item.rooms) || item || []);
      return withPage(rooms.map((room) => toLiveItem({
        roomId: room.roomid || room.room_id,
        uid: room.uid,
        title: room.title,
        uname: room.uname,
        cover: room.cover || room.keyframe,
        online: room.online,
        areaName: room.area_name
      })), rooms.length > 0 && page < 8, ps);
    }
    if (id === "area") {
      const json2 = await fetchJson(client, API.liveAreaList, { cookie, headers: { Referer: "https://live.bilibili.com/" } });
      checkApiResponse(json2, "get live areas failed");
      return (((_g = json2.data) == null ? void 0 : _g.data) || json2.data || []).map((p) => createFolder(`live/area/${p.id}`, p.name));
    }
    if (id.startsWith("area/")) {
      const [, parentId, childId] = id.split("/");
      const areas = await fetchJson(client, API.liveAreaList, { cookie, headers: { Referer: "https://live.bilibili.com/" } }).catch(() => ({}));
      if (!childId) {
        const parent = (((_h = areas.data) == null ? void 0 : _h.data) || areas.data || []).find((area) => String(area.id) === String(parentId));
        return ((parent == null ? void 0 : parent.list) || (parent == null ? void 0 : parent.children) || []).map((c) => createFolder(`live/area/${parentId}/${c.id}`, c.name));
      }
      const json2 = await fetchJson(client, withQuery(API.liveAreaRooms, { platform: "web", parent_area_id: parentId, area_id: childId, page, sort_type: "" }), { cookie, headers: { Referer: "https://live.bilibili.com/" } });
      const rooms = ((_i = json2.data) == null ? void 0 : _i.list) || [];
      return withPage(rooms.map((room) => toLiveItem({
        roomId: room.roomid || room.room_id,
        uid: room.uid,
        title: room.title,
        uname: room.uname,
        cover: room.cover || room.keyframe,
        online: room.online,
        areaName: room.area_name
      })), rooms.length >= ps, ps);
    }
    return [];
  };
  const listDirectory$1 = async (client, payload) => {
    const cookie = ensureCookie(payload);
    const account = (payload == null ? void 0 : payload.account) || {};
    const { page, cleanPath } = parsePath((payload == null ? void 0 : payload.path) || "root");
    const [type, ...rest] = cleanPath.split("/");
    const id = rest.join("/");
    const ps = Math.max(1, Math.min(50, Number((payload == null ? void 0 : payload.pageSize) || 20)));
    if (type === "root") return rootMenu();
    if (type === "history") return listHistory(client, cookie, page, ps);
    if (type === "popular") return listPopular(client, cookie, page, ps);
    if (type === "recommend") return listRecommend(client, cookie, page, ps);
    if (type === "zone") return listZone(client, cookie, id, page, ps);
    if (type === "bangumi" || type === "cinema") return listPgc(client, cookie, type, page, ps);
    if (type === "dynamic") return listDynamic(client, cookie, page, ps);
    if (type === "my") return listMy(client, cookie, id, page, ps, account);
    if (type === "user") return listUser(client, cookie, id, page, ps);
    if (type === "live") return listLive(client, cookie, id, page, ps);
    return [];
  };
  const cache = /* @__PURE__ */ new Map();
  const decodeUtf8 = (bytes) => {
    let text = "";
    for (let index = 0; index < bytes.length; ) {
      const first = bytes[index++];
      let codePoint;
      let length;
      if (first < 128) {
        codePoint = first;
        length = 0;
      } else if (first >= 194 && first <= 223) {
        codePoint = first & 31;
        length = 1;
      } else if (first >= 224 && first <= 239) {
        codePoint = first & 15;
        length = 2;
      } else if (first >= 240 && first <= 244) {
        codePoint = first & 7;
        length = 3;
      } else {
        text += "�";
        continue;
      }
      if (index + length > bytes.length) {
        text += "�";
        break;
      }
      let valid = true;
      for (let offset = 0; offset < length; offset += 1) {
        const next = bytes[index + offset];
        if ((next & 192) !== 128) {
          valid = false;
          break;
        }
        codePoint = codePoint << 6 | next & 63;
      }
      if (!valid || length === 2 && codePoint < 2048 || length === 3 && codePoint < 65536 || codePoint >= 55296 && codePoint <= 57343 || codePoint > 1114111) {
        text += "�";
        continue;
      }
      index += length;
      text += codePoint <= 65535 ? String.fromCharCode(codePoint) : String.fromCharCode(55296 + (codePoint - 65536 >> 10), 56320 + (codePoint - 65536 & 1023));
    }
    return text;
  };
  const readVarint = (bytes, start) => {
    let value = 0;
    let shift = 0;
    let index = start;
    while (index < bytes.length) {
      const byte = bytes[index++];
      value += (byte & 127) * 2 ** shift;
      if (!(byte & 128)) break;
      shift += 7;
    }
    return [value, index];
  };
  const readBytes = (bytes, start) => {
    const [length, index] = readVarint(bytes, start);
    const end = Math.min(bytes.length, index + length);
    return [bytes.subarray(index, end), end];
  };
  const skip = (bytes, index, wire) => wire === 0 ? readVarint(bytes, index)[1] : wire === 1 ? index + 8 : wire === 2 ? readBytes(bytes, index)[1] : wire === 5 ? index + 4 : bytes.length;
  const mode = (value) => Number(value) === 4 ? 2 : Number(value) === 5 ? 1 : 0;
  const color = (value) => `#${Number(value || 16777215).toString(16).padStart(6, "0").slice(-6)}`;
  const decodeItem = (bytes) => {
    const item = {};
    let index = 0;
    while (index < bytes.length) {
      const [tag, next] = readVarint(bytes, index);
      index = next;
      const field = tag >> 3;
      const wire = tag & 7;
      if ([2, 3, 4, 5].includes(field) && wire === 0) {
        [item[field], index] = readVarint(bytes, index);
      } else if (field === 7 && wire === 2) {
        const [value, end] = readBytes(bytes, index);
        item[7] = decodeUtf8(value);
        index = end;
      } else index = skip(bytes, index, wire);
    }
    const text = String(item[7] || "").trim();
    return text ? {
      text,
      time: Number(item[2] || 0) / 1e3,
      mode: mode(item[3]),
      color: color(item[5]),
      fontSize: Number(item[4] || 25)
    } : null;
  };
  const decodeDanmakuSegment = (bytes) => {
    const items = [];
    let index = 0;
    while (index < bytes.length) {
      const [tag, next] = readVarint(bytes, index);
      index = next;
      if (tag >> 3 === 1 && (tag & 7) === 2) {
        const [value, end] = readBytes(bytes, index);
        index = end;
        const item = decodeItem(value);
        if (item) items.push(item);
      } else index = skip(bytes, index, tag & 7);
    }
    return items;
  };
  const segmentCount = (bytes) => {
    let count = 0;
    let index = 0;
    while (index < bytes.length) {
      const [tag, next] = readVarint(bytes, index);
      index = next;
      if (tag >> 3 === 4 && (tag & 7) === 2) {
        const [value, end] = readBytes(bytes, index);
        index = end;
        let child = 0;
        while (child < value.length) {
          const [childTag, childNext] = readVarint(value, child);
          child = childNext;
          if (childTag >> 3 === 2 && (childTag & 7) === 0) [count, child] = readVarint(value, child);
          else child = skip(value, child, childTag & 7);
        }
      } else index = skip(bytes, index, tag & 7);
    }
    return Math.max(1, Number(count || 1));
  };
  const fetchDanmaku = async (client, cid, cookie = "") => {
    if (!cid) return [];
    const key = String(cid);
    if (cache.has(key)) return cache.get(key);
    const request2 = (async () => {
      const view = await fetchBytes(client, withQuery("https://api.bilibili.com/x/v2/dm/web/view", { type: "1", oid: String(cid) }), { cookie, headers: BILI_HEADERS });
      const count = segmentCount(view);
      const segments = await Promise.allSettled(Array.from({ length: count }, async (_, index) => {
        const bytes = await fetchBytes(client, withQuery("https://api.bilibili.com/x/v2/dm/web/seg.so", { type: "1", oid: String(cid), segment_index: String(index + 1) }), {
          cookie,
          headers: { ...BILI_CDN_HEADERS, Referer: "https://www.bilibili.com/" }
        });
        return decodeDanmakuSegment(bytes);
      }));
      const items = segments.flatMap((result) => result.status === "fulfilled" ? result.value : []).sort((a, b) => a.time - b.time);
      return items;
    })();
    cache.set(key, request2);
    try {
      const items = await request2;
      cache.set(key, items);
      return items;
    } catch (error) {
      cache.delete(key);
      throw error;
    }
  };
  const mpdCache = /* @__PURE__ */ new Map();
  const hostOf = (url = "") => {
    try {
      return new URL(url).host.toLowerCase();
    } catch {
      return "";
    }
  };
  const isMcdn = (url) => {
    const host = hostOf(url);
    return host.includes("mcdn") && host.includes("bilivideo");
  };
  const isBilivideo = (url) => {
    const host = hostOf(url);
    return host.includes("bilivideo") && !isMcdn(url);
  };
  const sortCdnUrls = (urls = []) => {
    const candidates = [...new Set(urls.filter(Boolean))];
    const edge = candidates.filter((url) => !isBilivideo(url) && !isMcdn(url));
    const bilivideo = candidates.filter(isBilivideo);
    const mcdn = candidates.filter(isMcdn);
    return [...edge, ...bilivideo, ...mcdn];
  };
  const parseStream = (item) => {
    var _a, _b, _c, _d;
    return {
      id: item.id,
      baseUrl: item.baseUrl || item.base_url,
      baseUrls: sortCdnUrls([item.baseUrl || item.base_url, ...item.backupUrl || item.backup_url || []]),
      codecs: item.codecs || "",
      bandwidth: item.bandwidth || 0,
      width: item.width || 0,
      height: item.height || 0,
      frameRate: item.frameRate || item.frame_rate || "",
      mimeType: item.mimeType || item.mime_type || "",
      segmentBase: {
        initialization: ((_a = item.segment_base) == null ? void 0 : _a.initialization) || ((_b = item.segmentBase) == null ? void 0 : _b.initialization) || "",
        indexRange: ((_c = item.segment_base) == null ? void 0 : _c.index_range) || ((_d = item.segmentBase) == null ? void 0 : _d.indexRange) || ""
      }
    };
  };
  const parsePlayUrl = (data) => {
    var _a, _b;
    const supportFormats = data.support_formats || [];
    return {
      quality: data.quality,
      acceptQuality: data.accept_quality || supportFormats.map((item) => item.quality).filter(Boolean),
      acceptDescription: data.accept_description || supportFormats.map((item) => item.new_description || item.display_desc || `${item.quality}P`),
      dash: data.dash ? {
        duration: data.dash.duration || 3600,
        video: (data.dash.video || []).map(parseStream),
        audio: [
          ...data.dash.audio || [],
          ...((_a = data.dash.dolby) == null ? void 0 : _a.audio) || [],
          ...((_b = data.dash.flac) == null ? void 0 : _b.audio) ? [data.dash.flac.audio] : []
        ].map(parseStream)
      } : null,
      durl: (data.durl || []).map((item) => ({ url: item.url, size: item.size, length: item.length }))
    };
  };
  const parseSubtitles = (data) => {
    var _a;
    return (((_a = data == null ? void 0 : data.subtitle) == null ? void 0 : _a.subtitles) || []).map((item) => {
      var _a2;
      return {
        name: item.lan_doc || item.lan || "",
        lang: item.lan || "",
        url: ((_a2 = item.subtitle_url) == null ? void 0 : _a2.startsWith("//")) ? `https:${item.subtitle_url}` : item.subtitle_url || "",
        default: String(item.lan || "").toLowerCase().includes("zh")
      };
    }).filter((item) => item.url);
  };
  const isAvc = (codecs = "") => /(^|,|\s)(avc1|avc3)(\.|$)/i.test(codecs);
  const isM4a = (codecs = "") => !codecs || /(^|,|\s)mp4a(\.|$)/i.test(codecs);
  const sameQn = (a, b) => String(a) === String(b);
  const dashTracks = (list = [], qn) => [...list].filter((item) => {
    var _a, _b;
    return (item == null ? void 0 : item.baseUrl) && ((_a = item == null ? void 0 : item.segmentBase) == null ? void 0 : _a.initialization) && ((_b = item == null ? void 0 : item.segmentBase) == null ? void 0 : _b.indexRange) && (!qn || sameQn(item.id, qn));
  }).sort((a, b) => Number(b.bandwidth || 0) - Number(a.bandwidth || 0));
  const pickDashTrack = (list = [], qn) => dashTracks(list, qn)[0];
  const xmlEscape = (value = "") => String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const proxiedUrl = (url = "") => `${PRIVATE_BASE$2}/api/bilibili/proxy?url=${encodeURIComponent(url)}`;
  const putMpd = (mpd) => {
    const key = `${now$2().toString(36)}-${Math.random().toString(36).slice(2)}`;
    mpdCache.set(key, { mpd, expiresAt: now$2() + 2 * 60 * 1e3 });
    return `${PRIVATE_BASE$2}/api/bilibili/mpd/${key}`;
  };
  const baseUrlLines = (stream) => {
    var _a;
    return (((_a = stream.baseUrls) == null ? void 0 : _a.length) ? stream.baseUrls : [stream.baseUrl]).filter(Boolean).map((url) => `        <BaseURL>${xmlEscape(proxiedUrl(url))}</BaseURL>`).join("\n");
  };
  const videoCodecId = (video) => {
    const codec = String((video == null ? void 0 : video.codecs) || "");
    if (/hevc|hvc1/i.test(codec)) return "hevc";
    if (/av01/i.test(codec)) return "av1";
    if (/avc1|avc3/i.test(codec)) return "avc";
    return "video";
  };
  const videoAttributes = (video, index) => [
    `id="video_qn_${xmlEscape(video.id)}_codec_${videoCodecId(video)}_index_${index}"`,
    `mimeType="${xmlEscape(video.mimeType || "video/mp4")}"`,
    video.bandwidth ? `bandwidth="${Number(video.bandwidth || 0)}"` : "",
    video.codecs ? `codecs="${xmlEscape(video.codecs)}"` : "",
    video.width ? `width="${Number(video.width || 0)}"` : "",
    video.height ? `height="${Number(video.height || 0)}"` : "",
    video.frameRate ? `frameRate="${xmlEscape(video.frameRate)}"` : ""
  ].filter(Boolean).join(" ");
  const createMpdUrl = (videos, audio, duration = 3600) => {
    var _a, _b;
    const videoList = (Array.isArray(videos) ? videos : [videos]).filter((video) => video == null ? void 0 : video.baseUrl);
    if (!videoList.length || !(audio == null ? void 0 : audio.baseUrl)) return "";
    const durationAttr = `PT${Math.floor(duration || 3600)}S`;
    const videoSets = [...new Set(videoList.map(videoCodecId))].map((codecId) => {
      const representations = videoList.filter((video) => videoCodecId(video) === codecId).map((video, index) => {
        var _a2, _b2;
        return `      <Representation ${videoAttributes(video, index)}>
${baseUrlLines(video)}
        <SegmentBase indexRange="${xmlEscape(((_a2 = video.segmentBase) == null ? void 0 : _a2.indexRange) || "0-0")}"><Initialization range="${xmlEscape(((_b2 = video.segmentBase) == null ? void 0 : _b2.initialization) || "0-0")}"/></SegmentBase>
      </Representation>`;
      }).join("\n");
      return `    <AdaptationSet contentType="video" mimeType="video/mp4" segmentAlignment="true" startWithSAP="1" id="${xmlEscape(codecId)}">
${representations}
    </AdaptationSet>`;
    }).join("\n");
    const mpd = `<?xml version="1.0" encoding="UTF-8"?>
<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" type="static" minBufferTime="PT0.75S" mediaPresentationDuration="${durationAttr}">
  <Period start="PT0S" duration="${durationAttr}">
${videoSets}
    <AdaptationSet contentType="audio" mimeType="${xmlEscape(audio.mimeType || "audio/mp4")}">
      <Representation id="audio_${xmlEscape(audio.id)}" mimeType="${xmlEscape(audio.mimeType || "audio/mp4")}" bandwidth="${Number(audio.bandwidth || 0)}" codecs="${xmlEscape(audio.codecs || "")}">
${baseUrlLines(audio)}
        <SegmentBase indexRange="${xmlEscape(((_a = audio.segmentBase) == null ? void 0 : _a.indexRange) || "0-0")}"><Initialization range="${xmlEscape(((_b = audio.segmentBase) == null ? void 0 : _b.initialization) || "0-0")}"/></SegmentBase>
      </Representation>
    </AdaptationSet>
  </Period>
</MPD>`;
    return putMpd(mpd);
  };
  const resolvePlayParams = async (client, path, cookie) => {
    var _a, _b, _c, _d, _e;
    const cleanPath = String(path || "").replace(/^bilibili:\/\//, "");
    const page = parseInt(((_a = cleanPath.match(/[?&]p=(\d+)/)) == null ? void 0 : _a[1]) || "1", 10) || 1;
    const plainPath = cleanPath.replace(/[?&]p=\d+/, "").replace(/[?&]$/, "");
    if (plainPath.startsWith("live/")) return { isLive: true, roomId: parseInt(plainPath.replace("live/", ""), 10) };
    if (plainPath.includes("|")) {
      const parts = Object.fromEntries(plainPath.split("|").map((part) => part.split(":")));
      if (parts.bvid && !isValidBvid(parts.bvid)) throw new Error(`invalid bilibili bvid: ${parts.bvid}`);
      return {
        bvid: parts.bvid || "",
        cid: parseInt(parts.cid, 10) || 0,
        page: parseInt(parts.page, 10) || 1,
        epid: parts.epid ? parseInt(parts.epid, 10) : void 0
      };
    }
    const videoMatch = plainPath.match(/^\/?video\/(.+)/);
    if (videoMatch) {
      const bvid = String(videoMatch[1] || "").trim();
      if (!isValidBvid(bvid)) throw new Error(`invalid bilibili bvid: ${bvid}`);
      const json2 = await fetchJson(client, withQuery(API.view, { bvid }), { cookie });
      checkApiResponse(json2, "get video info failed");
      const pages = ((_b = json2.data) == null ? void 0 : _b.pages) || [];
      const current = pages.find((item) => item.page === page) || pages[page - 1] || pages[0];
      if (!current) throw new Error("video page not found");
      return { bvid, cid: current.cid, page: current.page || page };
    }
    const epMatch = plainPath.match(/^\/?bangumi\/ep(\d+)/);
    if (epMatch) {
      const json2 = await fetchJson(client, withQuery(API.pgcSeason, { ep_id: epMatch[1] }), { cookie });
      checkApiResponse(json2, "get bangumi detail failed");
      const episodes = ((_c = json2.result) == null ? void 0 : _c.episodes) || [];
      const current = episodes.find((episode) => String(episode.id) === String(epMatch[1])) || episodes[0];
      if (!current) throw new Error("episode not found");
      return { bvid: current.bvid || "", cid: current.cid, page: parseInt(current.title, 10) || page, epid: current.id, seasonId: Number(((_d = json2.result) == null ? void 0 : _d.season_id) || 0) };
    }
    const bangumiMatch = plainPath.match(/^\/?bangumi\/(\d+)/);
    if (bangumiMatch) {
      const json2 = await fetchJson(client, withQuery(API.pgcSeason, { season_id: bangumiMatch[1] }), { cookie });
      checkApiResponse(json2, "get bangumi detail failed");
      const episodes = ((_e = json2.result) == null ? void 0 : _e.episodes) || [];
      const current = episodes[page - 1] || episodes[0];
      if (!current) throw new Error("episode not found");
      return { bvid: current.bvid || "", cid: current.cid, page, epid: current.id, seasonId: Number(bangumiMatch[1]) };
    }
    throw new Error(`invalid bilibili path: ${path}`);
  };
  const fetchPlayerInfo = async (client, params, cookie) => {
    if (!params.bvid || !params.cid) return {};
    try {
      const url = await signedWbiUrl(client, API.playerInfo, { bvid: params.bvid, cid: String(params.cid) }, cookie);
      const json2 = await fetchJson(client, url, { cookie, headers: { Referer: "https://www.bilibili.com", "X-Blbl-Skip-Origin": "1" } });
      checkApiResponse(json2, "get player info failed");
      return { subtitles: parseSubtitles(json2.data || {}) };
    } catch {
      return {};
    }
  };
  const fetchPlayUrl = async (client, params, cookie) => {
    if (params.epid) {
      const json3 = await fetchJson(client, withQuery(API.pgcPlayUrl, {
        ep_id: params.epid,
        cid: params.cid,
        qn: 127,
        fnval: 4048,
        fnver: 0,
        fourk: 1
      }), { cookie });
      checkApiResponse(json3, "get pgc play url failed");
      return parsePlayUrl(json3.result || json3.data || {});
    }
    const url = await signedWbiUrl(client, API.playUrl, {
      bvid: params.bvid,
      cid: String(params.cid),
      qn: "127",
      fnval: "4048",
      fnver: "0",
      fourk: "1"
    }, cookie);
    const json2 = await fetchJson(client, url, { cookie });
    checkApiResponse(json2, "get play url failed");
    return parsePlayUrl(json2.data || {});
  };
  const fetchLive = async (client, roomId, cookie) => {
    var _a, _b;
    const json2 = await fetchJson(client, withQuery(API.livePlayInfo, {
      room_id: roomId,
      protocol: "0,1",
      format: "0,1,2",
      codec: "0,1",
      qn: "10000",
      platform: "web",
      ptype: "8"
    }), { cookie, headers: { Referer: `https://live.bilibili.com/${roomId}` } });
    checkApiResponse(json2, "get live play url failed");
    const playurl = ((_b = (_a = json2.data) == null ? void 0 : _a.playurl_info) == null ? void 0 : _b.playurl) || {};
    const lines = [];
    for (const stream of playurl.stream || []) {
      for (const format of stream.format || []) {
        for (const codec of format.codec || []) {
          for (const info of codec.url_info || []) {
            if (codec.base_url && info.host) lines.push(info.host + codec.base_url + (info.extra || ""));
          }
        }
      }
    }
    return lines[0] || "";
  };
  const mapQualities = (params, playUrl) => {
    var _a, _b, _c, _d;
    const dashVideo = (((_a = playUrl.dash) == null ? void 0 : _a.video) || []).filter((video) => isAvc(video.codecs));
    const audio = pickDashTrack((((_b = playUrl.dash) == null ? void 0 : _b.audio) || []).filter((track) => isM4a(track.codecs)));
    const rawQuality = ((_c = playUrl.acceptQuality) == null ? void 0 : _c.length) ? playUrl.acceptQuality : dashVideo.map((video) => video.id);
    const rawDescription = ((_d = playUrl.acceptDescription) == null ? void 0 : _d.length) ? playUrl.acceptDescription : rawQuality.map((qn) => `${qn}P`);
    const descriptionByQn = new Map(rawQuality.map((qn, index) => [String(qn), rawDescription[index] || `${qn}P`]));
    const acceptQuality = rawQuality.filter((qn) => dashVideo.some((video) => sameQn(video.id, qn)));
    const qualities = acceptQuality.map((qn, index) => {
      var _a2, _b2;
      const videos = dashTracks(dashVideo, qn);
      const url = createMpdUrl(videos, audio, ((_a2 = playUrl.dash) == null ? void 0 : _a2.duration) || 3600);
      return url ? {
        default: index === 0,
        html: descriptionByQn.get(String(qn)) || `${qn}P`,
        url,
        type: "mpd",
        extra: { type: "mpd", qn, codecs: ((_b2 = videos[0]) == null ? void 0 : _b2.codecs) || "", cid: params.cid, bvid: params.bvid || "" }
      } : null;
    }).filter(Boolean);
    if (qualities.length) return qualities;
    return playUrl.durl.map((item, index) => {
      var _a2;
      return {
        default: index === 0,
        html: rawDescription[index] || `${((_a2 = playUrl.acceptQuality) == null ? void 0 : _a2[index]) || ""}P` || "默认",
        url: proxiedUrl(item.url),
        type: "auto",
        extra: { type: "auto", cid: params.cid, bvid: params.bvid || "" }
      };
    });
  };
  const resolvePlayback$2 = async (client, payload) => {
    var _a, _b, _c;
    const cookie = String((payload == null ? void 0 : payload.cookie) || "");
    const path = String((payload == null ? void 0 : payload.path) || "");
    if (!cookie) throw new Error("missing bilibili cookie");
    const params = await resolvePlayParams(client, path, cookie);
    if (params.isLive) {
      const url = proxiedUrl(await fetchLive(client, params.roomId, cookie));
      return {
        url,
        qualities: [{ default: true, html: "直播", url, extra: { isLive: true, roomId: params.roomId } }],
        runtime: {}
      };
    }
    const playUrl = await fetchPlayUrl(client, params, cookie);
    const qualities = mapQualities(params, playUrl);
    return {
      url: ((_a = qualities[0]) == null ? void 0 : _a.url) || proxiedUrl(((_c = (_b = playUrl.durl) == null ? void 0 : _b[0]) == null ? void 0 : _c.url) || ""),
      qualities,
      runtime: {
        subtitles: [],
        videoShot: null,
        danmakuTracks: []
      }
    };
  };
  const resolveAuxiliary = async (client, payload) => {
    const cookie = String((payload == null ? void 0 : payload.cookie) || "");
    const params = await resolvePlayParams(client, String((payload == null ? void 0 : payload.path) || ""), cookie);
    if (params.isLive) return {};
    const wantSubtitles = (payload == null ? void 0 : payload.subtitles) !== false;
    const wantDanmaku = (payload == null ? void 0 : payload.danmaku) !== false;
    const [playerInfo, danmaku] = await Promise.all([
      wantSubtitles ? fetchPlayerInfo(client, params, cookie) : Promise.resolve({ subtitles: [] }),
      wantDanmaku ? fetchDanmaku(client, params.cid, cookie).catch(() => []) : Promise.resolve([])
    ]);
    return {
      subtitles: playerInfo.subtitles || [],
      danmakuTracks: danmaku.length ? [{ id: `bilibili:${params.cid}`, name: "Bilibili", source: "bilibili", items: danmaku, default: true }] : []
    };
  };
  const getCachedMpd = (key) => {
    const cached = mpdCache.get(key);
    if (!cached || cached.expiresAt < now$2()) {
      mpdCache.delete(key);
      return null;
    }
    return cached.mpd;
  };
  const createMediaItemFromPath$1 = async (client, payload) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
    const cookie = ensureCookie(payload);
    const path = String((payload == null ? void 0 : payload.path) || "");
    const params = await resolvePlayParams(client, path, cookie);
    if (params.isLive) {
      const roomJson = await fetchJson(client, withQuery(API.liveRoomInfo, { room_id: params.roomId }), { cookie, headers: { Referer: `https://live.bilibili.com/${params.roomId}` } }).catch(() => ({}));
      const room = roomJson.data || {};
      return toLiveItem({
        roomId: params.roomId,
        uid: room.uid,
        title: room.title || `直播 ${params.roomId}`,
        uname: room.uname || ((_b = (_a = room.anchor_info) == null ? void 0 : _a.base_info) == null ? void 0 : _b.uname),
        cover: room.user_cover || room.keyframe,
        online: room.online,
        areaName: room.area_name
      });
    }
    const info = await fetchView(client, cookie, params.bvid);
    const page = info.pages.find((item) => item.page === params.page || item.cid === params.cid) || info.pages[0] || {};
    return toMediaItem$1({
      ...info,
      bvid: params.bvid,
      cid: page.cid || params.cid,
      page: page.page || params.page,
      duration: page.duration || info.duration,
      path,
      title: info.pages.length > 1 ? `${info.title} - ${page.part || `P${params.page}`}` : info.title,
      ownerName: (_c = info.owner) == null ? void 0 : _c.name,
      ownerMid: (_d = info.owner) == null ? void 0 : _d.mid,
      ownerFace: (_e = info.owner) == null ? void 0 : _e.face,
      viewCount: (_f = info.stat) == null ? void 0 : _f.view,
      danmakuCount: (_g = info.stat) == null ? void 0 : _g.danmaku,
      likeCount: (_h = info.stat) == null ? void 0 : _h.like,
      coinCount: (_i = info.stat) == null ? void 0 : _i.coin,
      favoriteCount: (_j = info.stat) == null ? void 0 : _j.favorite,
      shareCount: (_k = info.stat) == null ? void 0 : _k.share,
      replyCount: (_l = info.stat) == null ? void 0 : _l.reply,
      ...(payload == null ? void 0 : payload.timeParams) || {},
      isLoop: ((_m = payload == null ? void 0 : payload.timeParams) == null ? void 0 : _m.endTime) !== void 0
    });
  };
  const loadEpisodes = async (client, payload) => {
    var _a, _b, _c;
    const cookie = ensureCookie(payload);
    const path = String((payload == null ? void 0 : payload.path) || "");
    if (path.startsWith("/bangumi/")) {
      const seasonId = parseInt(path.replace("/bangumi/", ""), 10);
      const json2 = await fetchJson(client, withQuery(API.pgcSeason, { season_id: seasonId }), { cookie });
      checkApiResponse(json2, "get bangumi detail failed");
      const episodes = ((_a = json2.result) == null ? void 0 : _a.episodes) || [];
      return {
        pages: episodes.map((ep) => ({
          title: `${ep.title || ""}${ep.long_title ? ` - ${ep.long_title}` : ""}`.trim(),
          path: `bvid:${ep.bvid || ""}|cid:${ep.cid}|page:1|epid:${ep.id}`,
          bvid: ep.bvid || "",
          cid: ep.cid,
          page: 1,
          duration: ep.duration || 0,
          thumbnail: proxyAssetUrl(ep.cover),
          epid: ep.id,
          selected: false
        }))
      };
    }
    const params = await resolvePlayParams(client, path, cookie);
    const info = await fetchView(client, cookie, params.bvid);
    const seasonItems = (((_b = info.ugc_season) == null ? void 0 : _b.sections) || []).flatMap((section) => (section.episodes || []).map((ep) => {
      var _a2;
      const arc = ep.arc || {};
      const bvid = (ep.bvid || arc.bvid || "").trim();
      const cid = ep.cid || arc.cid || 0;
      const page = arc.page || 1;
      return bvid ? {
        title: (ep.title || arc.title || "").trim() || "未命名",
        path: `bvid:${bvid}|cid:${cid}|page:${page}`,
        bvid,
        cid,
        page,
        duration: arc.duration || 0,
        thumbnail: proxyAssetUrl(arc.pic || ""),
        viewCount: ((_a2 = arc.stat) == null ? void 0 : _a2.view) || 0,
        selected: bvid === params.bvid && cid === params.cid && page === params.page
      } : null;
    }).filter(Boolean));
    return {
      pages: info.pages.length > 1 ? info.pages.map((p) => {
        var _a2;
        return {
          title: ((_a2 = p.part) == null ? void 0 : _a2.trim()) ? `P${p.page} ${p.part}` : `P${p.page}`,
          path: `bvid:${params.bvid}|cid:${p.cid}|page:${p.page}`,
          bvid: params.bvid,
          cid: p.cid,
          page: p.page,
          duration: p.duration,
          thumbnail: proxyAssetUrl(p.first_frame || ""),
          selected: p.page === params.page
        };
      }) : void 0,
      season: seasonItems.length ? { title: ((_c = info.ugc_season) == null ? void 0 : _c.title) || "合集", items: seasonItems } : void 0
    };
  };
  const mapSearchVideo = (item) => {
    const bvid = pickBvid(item.bvid, item.arcurl, item.url, item.uri, item.share_url);
    return bvid ? {
      ...toMediaItem$1({
        bvid,
        aid: item.aid,
        title: stripHtmlTags(item.title || ""),
        coverUrl: item.pic ? String(item.pic).startsWith("//") ? `https:${item.pic}` : item.pic : "",
        durationSec: parseDuration(item.duration),
        ownerName: item.author || "",
        ownerMid: item.mid,
        view: item.play,
        danmaku: item.video_review,
        pubDate: item.pubdate,
        path: `/video/${bvid}`
      }),
      artist: item.author || "",
      album: "BBLL"
    } : null;
  };
  const mapSearchBangumi = (item, album = "番剧") => {
    var _a, _b;
    return {
      ...toMediaItem$1({
        seasonId: item.season_id || item.pgc_season_id,
        title: stripHtmlTags(item.title || ""),
        coverUrl: item.cover,
        badge: item.angle_title || ((_b = (_a = item.display_info) == null ? void 0 : _a[0]) == null ? void 0 : _b.text),
        seasonType: item.season_type_name,
        path: `/bangumi/${item.season_id || item.pgc_season_id}`
      }, "bangumi"),
      album: item.season_type_name || album
    };
  };
  const mapSearchLive = (item) => ({
    ...toLiveItem({
      roomId: item.roomid,
      uid: item.uid || item.mid,
      title: stripHtmlTags(item.title || ""),
      uname: stripHtmlTags(item.uname || ""),
      cover: item.user_cover || item.cover,
      online: item.online || 0,
      areaName: item.cate_name
    }),
    artist: stripHtmlTags(item.uname || ""),
    album: item.cate_name || "直播"
  });
  const mapSearchUser = (item) => ({
    id: `bilibili-user-${item.mid}`,
    name: item.uname || "",
    title: item.uname || "",
    type: "folder",
    source: "bilibili",
    sourcePath: `/user/${item.mid}`,
    localPath: `/user/${item.mid}/`,
    path: `/user/${item.mid}`,
    url: "#",
    thumbnail: proxyAssetUrl(item.upic),
    artist: item.usign || "",
    album: "用户",
    added: now$2(),
    size: 0,
    isDir: true,
    is_dir: true
  });
  const searchOne = async (client, cookie, keyword, page, type) => {
    var _a, _b, _c, _d;
    if (!keyword.trim() && type !== "hints") return { items: [], page, hasMore: false };
    if (type === "user") {
      const json3 = await fetchJson(client, withQuery(API.searchType, { search_type: "bili_user", keyword, page }), { cookie });
      checkApiResponse(json3, "user search failed");
      return { items: (((_a = json3.data) == null ? void 0 : _a.result) || []).map(mapSearchUser), page, hasMore: (((_b = json3.data) == null ? void 0 : _b.numPages) || 0) > page };
    }
    const searchType = type === "bangumi" ? "media_bangumi" : type === "media" ? "media_ft" : type === "live" ? "live_room" : "video";
    const url = await signedWbiUrl(client, API.searchTypeWbi, { search_type: searchType, keyword, page, order: type === "live" ? "online" : "totalrank" }, cookie);
    const json2 = await fetchJson(client, url, { cookie });
    checkApiResponse(json2, `${type} search failed`);
    const result = ((_c = json2.data) == null ? void 0 : _c.result) || [];
    const mapper = type === "bangumi" ? (item) => mapSearchBangumi(item, "番剧") : type === "media" ? (item) => mapSearchBangumi(item, "影视") : type === "live" ? mapSearchLive : mapSearchVideo;
    return { items: result.map(mapper).filter((item) => (item == null ? void 0 : item.id) && (item == null ? void 0 : item.title)), page, hasMore: (((_d = json2.data) == null ? void 0 : _d.numPages) || 0) > page };
  };
  const searchAll$1 = async (client, payload) => {
    const cookie = String((payload == null ? void 0 : payload.cookie) || "");
    const keyword = String((payload == null ? void 0 : payload.keyword) || "");
    const page = Math.max(1, Number((payload == null ? void 0 : payload.page) || 1));
    const type = String((payload == null ? void 0 : payload.type) || "all");
    if (type !== "all") return searchOne(client, cookie, keyword, page, type);
    const empty = { items: [], page, hasMore: false };
    const [video, bangumi, media, live] = await Promise.all([
      searchOne(client, cookie, keyword, page, "video").catch(() => empty),
      searchOne(client, cookie, keyword, page, "bangumi").catch(() => empty),
      searchOne(client, cookie, keyword, page, "media").catch(() => empty),
      searchOne(client, cookie, keyword, page, "live").catch(() => empty)
    ]);
    return { items: [...video.items, ...bangumi.items, ...media.items, ...live.items], page, hasMore: video.hasMore || bangumi.hasMore || media.hasMore || live.hasMore };
  };
  const searchHints = async (client, payload) => {
    var _a;
    const cookie = String((payload == null ? void 0 : payload.cookie) || "");
    const keyword = String((payload == null ? void 0 : payload.keyword) || "");
    if (keyword.trim()) {
      const json3 = await fetchJson(client, withQuery(API.searchSuggest, { term: keyword, main_ver: "v1", func: "suggest", suggest_type: "accurate", sub_type: "tag" }), { cookie });
      return (((_a = json3.result) == null ? void 0 : _a.tag) || []).map((item) => item.value || item.term || "").filter(Boolean);
    }
    const json2 = await fetchJson(client, API.searchHotword, { cookie });
    return (json2.list || []).slice(0, 8).map((item) => item.keyword || "").filter(Boolean);
  };
  const resolveSocialVideo = async (client, cookie, item = {}) => {
    const bvid = String((item == null ? void 0 : item.bvid) || "").trim();
    const aid = Number((item == null ? void 0 : item.aid) || (bvid ? (await fetchView(client, cookie, bvid)).aid : 0));
    if (!bvid && !aid) throw new Error("缺少视频标识");
    return { bvid, aid };
  };
  const payloadId = (bvid, aid) => bvid ? { bvid } : { aid };
  const socialAction = async (client, payload) => {
    var _a, _b;
    const cookie = ensureCookie(payload);
    const action = String((payload == null ? void 0 : payload.action) || "");
    const { bvid, aid } = await resolveSocialVideo(client, cookie, (payload == null ? void 0 : payload.item) || {});
    const csrf = csrfOf(cookie);
    if (!csrf) throw new Error("缺少 bili_jct");
    if (action === "like") {
      const json2 = await postFormJson(client, API.socialLike, { ...payloadId(bvid, aid), like: 1, csrf }, { cookie, headers: { Referer: "https://www.bilibili.com" } });
      checkApiResponse(json2, "点赞操作失败");
      return true;
    }
    if (action === "coin") {
      const state = await fetchJson(client, withQuery(API.socialCoinState, payloadId(bvid, aid)), { cookie });
      checkApiResponse(state, "获取投币状态失败");
      if (Math.max(0, ((_a = state.data) == null ? void 0 : _a.multiply) || 0) >= 2) throw new Error("最多只能投 2 个币");
      const json2 = await postFormJson(client, API.socialCoin, { ...payloadId(bvid, aid), multiply: Math.min(2, Math.max(1, Number((payload == null ? void 0 : payload.multiply) || 1))), select_like: 0, csrf }, { cookie });
      checkApiResponse(json2, "投币失败");
      return true;
    }
    if (action === "favorite") {
      currentUid(cookie, (_b = payload == null ? void 0 : payload.account) == null ? void 0 : _b.uid);
      const mediaId = Number((payload == null ? void 0 : payload.mediaId) || 0);
      if (mediaId) {
        const json3 = await postFormJson(client, API.favResourceDeal, { rid: aid, type: 2, add_media_ids: mediaId, del_media_ids: "", csrf }, { cookie });
        checkApiResponse(json3, "收藏失败");
        return true;
      }
      const folders = await favoriteFolders(client, { cookie, item: payload == null ? void 0 : payload.item, account: payload == null ? void 0 : payload.account });
      const folder = folders.find((item) => item.title === "默认收藏夹") || folders[0];
      if (!(folder == null ? void 0 : folder.mediaId)) throw new Error("未找到可用收藏夹");
      const json2 = await postFormJson(client, API.favResourceDeal, { rid: aid, type: 2, add_media_ids: folder.mediaId, del_media_ids: "", csrf }, { cookie });
      checkApiResponse(json2, "收藏失败");
      return true;
    }
    throw new Error(`unknown bilibili action: ${action}`);
  };
  const favoriteFolders = async (client, payload) => {
    var _a, _b;
    const cookie = ensureCookie(payload);
    const uid = currentUid(cookie, (_a = payload == null ? void 0 : payload.account) == null ? void 0 : _a.uid);
    const { aid } = await resolveSocialVideo(client, cookie, (payload == null ? void 0 : payload.item) || {});
    const json2 = await fetchJson(client, withQuery(API.favFolders, { up_mid: uid, type: 2, rid: aid, web_location: "333.1387" }), { cookie });
    checkApiResponse(json2, "获取收藏夹失败");
    return (((_b = json2.data) == null ? void 0 : _b.list) || []).map((item) => ({
      mediaId: item.id,
      title: item.title,
      mediaCount: item.media_count,
      coverUrl: item.cover,
      favState: !!item.fav_state
    }));
  };
  const comments = async (client, payload, replies = false) => {
    var _a;
    const cookie = ensureCookie(payload);
    const { aid } = await resolveSocialVideo(client, cookie, (payload == null ? void 0 : payload.item) || {});
    const params = replies ? { type: 1, oid: aid, root: payload == null ? void 0 : payload.rootRpid, pn: Math.max(1, Number((payload == null ? void 0 : payload.page) || 1)), ps: 20 } : { type: 1, oid: aid, sort: (payload == null ? void 0 : payload.sort) || 1, pn: Math.max(1, Number((payload == null ? void 0 : payload.page) || 1)), ps: 20, nohot: 1 };
    const json2 = await fetchJson(client, withQuery(replies ? API.replyReplies : API.reply, params), { cookie, headers: { Referer: "https://www.bilibili.com" } });
    checkApiResponse(json2, replies ? "获取回复失败" : "获取评论失败");
    return ((_a = json2.data) == null ? void 0 : _a.replies) || [];
  };
  const parseJsonBody$2 = async (request2) => {
    var _a, _b;
    const body = ((_a = request2 == null ? void 0 : request2.request) == null ? void 0 : _a.body) || ((_b = request2 == null ? void 0 : request2.Request) == null ? void 0 : _b.Body) || {};
    const data = body.data ?? body.Data;
    if (!data) return {};
    if (typeof data.json === "function") return await data.json();
    if (typeof data.text === "function") {
      const text = await data.text();
      return text ? JSON.parse(text) : {};
    }
    if (typeof data === "string") return data ? JSON.parse(data) : {};
    return data;
  };
  const queryValue$1 = (request2, key) => {
    const url = (request2 == null ? void 0 : request2.url) || (request2 == null ? void 0 : request2.URL) || {};
    const query = url.query || url.Query || {};
    const value = query[key];
    return Array.isArray(value) ? String(value[0] || "") : String(value || "");
  };
  const jsonRoute$2 = (handler, errorStatus = 500) => async (request2) => {
    try {
      return jsonResponse(success(await handler(await parseJsonBody$2(request2), request2)));
    } catch (error) {
      return jsonResponse(failure((error == null ? void 0 : error.message) || String(error), errorStatus), errorStatus);
    }
  };
  const proxyRoute$2 = (request2) => {
    var _a, _b, _c;
    const url = queryValue$1(request2, "url");
    if (!/^https?:\/\//i.test(url)) return textResponse("invalid proxy url", 400);
    const requestHeaders = ((_a = request2 == null ? void 0 : request2.request) == null ? void 0 : _a.headers) || ((_b = request2 == null ? void 0 : request2.Request) == null ? void 0 : _b.Headers) || {};
    const range = (_c = Object.entries(requestHeaders || {}).find(([key]) => key.toLowerCase() === "range")) == null ? void 0 : _c[1];
    return proxyResponse(url, {
      ...BILI_CDN_HEADERS,
      ...range ? { Range: Array.isArray(range) ? String(range[0] || "") : String(range) } : {}
    });
  };
  const createBilibiliHandlers = ({ client }) => ({
    "POST /api/bilibili/check": async (request2) => {
      try {
        return jsonResponse(success(await checkConnection$1(client, await parseJsonBody$2(request2))));
      } catch (error) {
        return jsonResponse(success({ connected: false, message: `连接失败: ${(error == null ? void 0 : error.message) || String(error)}` }));
      }
    },
    "POST /api/bilibili/login/qrcode": jsonRoute$2(() => qrLogin(client)),
    "POST /api/bilibili/login/poll": jsonRoute$2((payload) => qrPoll(client, payload)),
    "POST /api/bilibili/directory": jsonRoute$2((payload) => listDirectory$1(client, payload)),
    "POST /api/bilibili/media": jsonRoute$2((payload) => createMediaItemFromPath$1(client, payload)),
    "POST /api/bilibili/episodes": jsonRoute$2((payload) => loadEpisodes(client, payload)),
    "POST /api/bilibili/search": jsonRoute$2((payload) => searchAll$1(client, payload)),
    "POST /api/bilibili/search/hints": jsonRoute$2((payload) => searchHints(client, payload)),
    "POST /api/bilibili/resolve": jsonRoute$2((payload) => resolvePlayback$2(client, payload)),
    "POST /api/bilibili/auxiliary": jsonRoute$2((payload) => resolveAuxiliary(client, payload)),
    "POST /api/bilibili/favorite-folders": jsonRoute$2((payload) => favoriteFolders(client, payload)),
    "POST /api/bilibili/social": jsonRoute$2((payload) => socialAction(client, payload)),
    "POST /api/bilibili/comments": jsonRoute$2((payload) => comments(client, payload, false)),
    "POST /api/bilibili/comment-replies": jsonRoute$2((payload) => comments(client, payload, true)),
    "GET /api/bilibili/mpd/:key": async (request2) => {
      var _a, _b;
      const path = ((_a = request2 == null ? void 0 : request2.context) == null ? void 0 : _a.path) || ((_b = request2 == null ? void 0 : request2.Context) == null ? void 0 : _b.Path) || "";
      const key = path.split("/").pop() || "";
      const mpd = getCachedMpd(key);
      if (!mpd) return textResponse("mpd not found", 404);
      return textResponse(mpd, 200, "application/dash+xml; charset=utf-8");
    },
    "ANY /api/bilibili/proxy": proxyRoute$2
  });
  const parseJsonBody$1 = async (request2) => {
    var _a, _b;
    const body = ((_a = request2 == null ? void 0 : request2.request) == null ? void 0 : _a.body) || ((_b = request2 == null ? void 0 : request2.Request) == null ? void 0 : _b.Body) || {};
    const data = body.data ?? body.Data;
    if (!data) return {};
    if (typeof data.json === "function") return await data.json();
    if (typeof data.text === "function") {
      const text = await data.text();
      return text ? JSON.parse(text) : {};
    }
    return typeof data === "string" ? JSON.parse(data) : data;
  };
  const scalar = (value) => String((Array.isArray(value) ? value[0] : value) || "");
  const queryValue = (request2, key) => {
    const url = (request2 == null ? void 0 : request2.url) || (request2 == null ? void 0 : request2.URL) || {};
    return scalar((url.query || url.Query || {})[key]);
  };
  const headerValue = (headers, name) => {
    var _a;
    return scalar((_a = Object.entries(headers || {}).find(([key]) => key.toLowerCase() === name.toLowerCase())) == null ? void 0 : _a[1]);
  };
  const pick = (value, lowerName, upperName) => {
    if (!value) return void 0;
    if (value[lowerName] !== void 0) return value[lowerName];
    if (value[upperName] !== void 0) return value[upperName];
    return void 0;
  };
  const decodePath = (path) => {
    try {
      return decodeURIComponent(path);
    } catch {
      return path;
    }
  };
  const requestPath = (request2) => {
    const context = pick(request2, "context", "Context");
    const url = pick(request2, "url", "URL");
    const fromContext = pick(context, "path", "Path");
    const fromUrl = pick(url, "path", "Path");
    const raw = fromContext || fromUrl || "/";
    return decodePath(raw.replace(/^\/plugin\/private\/[^/]+/, "") || "/");
  };
  const requestMethod = (request2) => {
    const meta = pick(request2, "request", "Request");
    return String(pick(meta, "method", "Method") || "GET").toUpperCase();
  };
  const matchDynamicHandler = (handlers, method, path) => {
    for (const [route, handler] of Object.entries(handlers)) {
      const [routeMethod, routePath] = route.split(" ");
      if (routeMethod !== method && routeMethod !== "ANY") continue;
      if (!(routePath == null ? void 0 : routePath.includes(":"))) continue;
      const pattern = `^${routePath.replace(/:[^/]+/g, "[^/]+")}$`;
      if (new RegExp(pattern).test(path)) return handler;
    }
    return null;
  };
  const createRouter = ({ handlers, statusPayload, logger }) => async (request2) => {
    var _a;
    const method = requestMethod(request2);
    const path = requestPath(request2);
    const key = `${method} ${path}`;
    const anyKey = `ANY ${path}`;
    try {
      if (path === "/" || path === "/status") return jsonResponse(success(statusPayload()));
      const handler = handlers[key] || handlers[anyKey];
      if (handler) return await handler(request2);
      const dynamicHandler = matchDynamicHandler(handlers, method, path);
      if (dynamicHandler) return await dynamicHandler(request2);
      return jsonResponse(failure(`route not implemented: ${key}`, 404), 404);
    } catch (error) {
      (_a = logger == null ? void 0 : logger.error) == null ? void 0 : _a.call(logger, "[siyuan-media-player]", (error == null ? void 0 : error.stack) || (error == null ? void 0 : error.message) || String(error));
      return jsonResponse(failure((error == null ? void 0 : error.message) || String(error), 500), 500);
    }
  };
  const APP_USER_AGENT = "com.ss.android.ugc.aweme/350101 (Linux; U; Android 14; zh_CN; Pixel 7; Build/UP1A.231005.007; Cronet/TTNetVersion:5a3f1d02 2024-01-01)";
  const FEED_API_CANDIDATES = [
    { origin: "https://api5-normal-c-hl.amemv.com", aid: "1128" },
    { origin: "https://aweme.snssdk.com", aid: "1128" },
    { origin: "https://api5-normal-c-hl.amemv.com", aid: "6383" },
    { origin: "https://aweme.snssdk.com", aid: "6383" }
  ];
  const fetchFeedFromOrigin = async (client, awemeId, { origin, aid }) => {
    var _a, _b, _c;
    if (!client || typeof client.fetch !== "function") throw new Error("思源内核网络客户端不可用");
    const url = new URL("/aweme/v1/feed/", origin);
    url.searchParams.set("aweme_id", String(awemeId));
    url.searchParams.set("aid", aid);
    url.searchParams.set("device_platform", "android");
    const response = await client.fetch("/api/network/forwardProxy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: url.toString(),
        method: "GET",
        headers: [
          { "User-Agent": APP_USER_AGENT },
          { Accept: "application/json" },
          { Referer: "https://www.douyin.com/" },
          { "Accept-Encoding": "identity" }
        ],
        payloadEncoding: "text"
      })
    });
    const raw = await response.text();
    let forwarded;
    try {
      forwarded = JSON.parse(raw);
    } catch {
      throw new Error("抖音公开接口代理返回了无效响应");
    }
    if ((forwarded == null ? void 0 : forwarded.code) !== 0) throw new Error((forwarded == null ? void 0 : forwarded.msg) || "抖音公开接口请求失败");
    const status = Number(((_a = forwarded == null ? void 0 : forwarded.data) == null ? void 0 : _a.status) || 0);
    if (status && (status < 200 || status >= 300)) throw new Error(`抖音公开接口 HTTP ${status}`);
    let responseHost = "未知主机";
    try {
      responseHost = new URL(String(((_b = forwarded == null ? void 0 : forwarded.data) == null ? void 0 : _b.url) || origin)).hostname || responseHost;
    } catch {
    }
    const body = String(((_c = forwarded == null ? void 0 : forwarded.data) == null ? void 0 : _c.body) || "");
    if (!body || body.length > 2 * 1024 * 1024) throw new Error("抖音公开接口响应为空或超过 2 MiB 限制");
    try {
      return {
        data: JSON.parse(body),
        httpStatus: status || 0,
        responseHost
      };
    } catch {
      throw new Error("抖音公开接口返回了无效 JSON");
    }
  };
  const fetchPublicFeed = async (client, awemeId) => {
    const errors = [];
    for (const candidate of FEED_API_CANDIDATES) {
      try {
        const { data, httpStatus, responseHost } = await fetchFeedFromOrigin(client, awemeId, candidate);
        const items = Array.isArray(data == null ? void 0 : data.aweme_list) ? data.aweme_list : [];
        const detail = items.find((item) => String((item == null ? void 0 : item.aweme_id) || (item == null ? void 0 : item.awemeId) || (item == null ? void 0 : item.id) || "") === String(awemeId));
        if (detail) return { detail, userAgent: APP_USER_AGENT };
        const statusCode = Number((data == null ? void 0 : data.status_code) ?? (data == null ? void 0 : data.statusCode) ?? 0);
        const statusMessage = String((data == null ? void 0 : data.status_msg) || (data == null ? void 0 : data.statusMsg) || "").trim().slice(0, 100);
        const responseInfo = `HTTP ${httpStatus || "未知"}, 响应主机 ${responseHost}`;
        errors.push(`${new URL(candidate.origin).hostname} aid=${candidate.aid}: ${responseInfo}; ${statusCode ? `业务状态 ${statusCode}${statusMessage ? ` (${statusMessage})` : ""}` : "没有匹配的作品"}`);
      } catch (error) {
        errors.push(`${new URL(candidate.origin).hostname} aid=${candidate.aid}: ${String((error == null ? void 0 : error.message) || error || "请求失败").slice(0, 120)}`);
      }
    }
    throw new Error(`抖音公开 Feed 接口未命中作品 ${awemeId}（${errors.join("；")}）`);
  };
  const PRIVATE_BASE$1 = "/plugin/private/siyuan-media-player";
  const MAX_CAPTURE_LENGTH = 2 * 1024 * 1024;
  const PROXY_TTL_MS = 15 * 60 * 1e3;
  const MAX_PROXY_ENTRIES = 64;
  const MEDIA_DOMAINS = SOCIAL_SITES.douyin.mediaHosts;
  const mediaProxyEntries = /* @__PURE__ */ new Map();
  const ownsDomain = (hostname, domains) => domains.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
  const safeHttpsUrl = (value, domains) => {
    try {
      const url = new URL(value);
      const hostname = url.hostname.toLowerCase().replace(/\.$/, "");
      if (url.protocol !== "https:" || url.username || url.password || url.port && url.port !== "443" || !ownsDomain(hostname, domains)) return null;
      return url;
    } catch {
      return null;
    }
  };
  const safePageUrl$1 = (value) => {
    try {
      const url = new URL(value);
      const hostname = url.hostname.toLowerCase().replace(/\.$/, "");
      return url.protocol === "https:" && !url.username && !url.password && (!url.port || url.port === "443") && DOUYIN_PAGE_HOSTS.includes(hostname) ? url : null;
    } catch {
      return null;
    }
  };
  const workIdFromUrl = (value = "") => {
    var _a;
    try {
      const url = new URL(value);
      return ((_a = url.pathname.match(/\/(?:video|share\/video)\/(\d+)(?:\/|$)/i)) == null ? void 0 : _a[1]) || ["aweme_id", "modal_id", "item_id"].map((key) => url.searchParams.get(key)).find((id) => /^\d+$/.test(id || "")) || "";
    } catch {
      return "";
    }
  };
  const purgeExpiredProxies = () => {
    const now2 = Date.now();
    for (const [key, value] of mediaProxyEntries) if (value.expiresAt <= now2) mediaProxyEntries.delete(key);
    while (mediaProxyEntries.size >= MAX_PROXY_ENTRIES) {
      const oldest = mediaProxyEntries.keys().next().value;
      if (!oldest) break;
      mediaProxyEntries.delete(oldest);
    }
  };
  const putMediaProxy = (url, userAgent, pageUrl) => {
    purgeExpiredProxies();
    const key = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
    mediaProxyEntries.set(key, { url, userAgent, referer: `${new URL(pageUrl).origin}/`, expiresAt: Date.now() + PROXY_TTL_MS });
    return `${PRIVATE_BASE$1}/api/douyin/proxy?key=${encodeURIComponent(key)}`;
  };
  const firstUrl = (value) => (Array.isArray(value) ? value : []).map((url) => String(url || "").trim()).find(Boolean) || "";
  const resolveCapturedPlayback = (payload, shareUrl) => {
    var _a, _b;
    const capture = (payload == null ? void 0 : payload.capture) || {};
    const body = String(capture.body || "");
    if (!body || body.length > MAX_CAPTURE_LENGTH) throw new Error("抖音详情响应为空或超过 2 MiB 限制");
    const status = Number(capture.status || 0);
    if (status < 200 || status >= 300) throw new Error(`抖音详情接口返回 HTTP ${status || "未知状态"}`);
    const finalPage = safePageUrl$1(String(capture.finalUrl || ""));
    if (!finalPage) throw new Error("抖音页面跳转到了不受支持的地址");
    const userAgent = String(capture.userAgent || "").slice(0, 512);
    if (!/^Mozilla\/\d/i.test(userAgent) || !/Chrome\/[\d.]+/i.test(userAgent) || /Electron\//i.test(userAgent)) {
      throw new Error("抖音浏览器标识无效，请更新思源桌面版后重试");
    }
    let response;
    try {
      response = JSON.parse(body);
    } catch {
      throw new Error("抖音作品详情响应不是有效 JSON");
    }
    const detail = (response == null ? void 0 : response.aweme_detail) || (response == null ? void 0 : response.awemeDetail) || ((_a = response == null ? void 0 : response.data) == null ? void 0 : _a.aweme_detail) || ((_b = response == null ? void 0 : response.data) == null ? void 0 : _b.awemeDetail);
    if (!detail || typeof detail !== "object") throw new Error((response == null ? void 0 : response.status_msg) || (response == null ? void 0 : response.message) || "抖音详情响应中没有作品信息");
    const id = String(detail.aweme_id || detail.awemeId || detail.item_id || "");
    if (!/^\d+$/.test(id)) throw new Error("抖音详情响应缺少作品编号");
    const detailRequestId = String(capture.detailRequestId || "");
    if (/^\d+$/.test(detailRequestId) && id !== detailRequestId) throw new Error("抖音详情接口返回的作品编号不匹配");
    const expectedId = workIdFromUrl(shareUrl) || workIdFromUrl(finalPage.toString()) || String(capture.detailRequestId || "");
    if (expectedId && id !== expectedId) throw new Error("抖音返回的作品与分享链接不匹配，请重新复制作品链接");
    return buildPlayback(detail, { expectedId, userAgent, pageUrl: finalPage.toString() });
  };
  const resolvePublicPlayback = async (client, shareUrl) => {
    const id = workIdFromUrl(shareUrl);
    if (!id) throw new Error("公开接口解析需要作品编号，短链将尝试浏览器回退");
    const { detail, userAgent } = await fetchPublicFeed(client, id);
    return buildPlayback(detail, { expectedId: id, userAgent, pageUrl: `https://www.douyin.com/video/${id}` });
  };
  const buildPlayback = (detail, { expectedId, userAgent, pageUrl }) => {
    var _a, _b, _c, _d, _e, _f, _g;
    const id = String((detail == null ? void 0 : detail.aweme_id) || (detail == null ? void 0 : detail.awemeId) || (detail == null ? void 0 : detail.item_id) || (detail == null ? void 0 : detail.id) || "");
    if (!/^\d+$/.test(id)) throw new Error("抖音详情响应缺少作品编号");
    if (expectedId && id !== expectedId) throw new Error("抖音返回的作品与分享链接不匹配，请重新复制作品链接");
    const isBrowserUa = /^Mozilla\/\d/i.test(userAgent) && /Chrome\/[\d.]+/i.test(userAgent) && !/Electron\//i.test(userAgent);
    const isAppUa = /^com\.ss\.android\.ugc\.aweme\/\d+/i.test(userAgent);
    if (!isBrowserUa && !isAppUa) throw new Error("抖音请求浏览器标识无效");
    const video = detail.video || {};
    const mediaUrl2 = firstUrl(((_a = video.play_addr) == null ? void 0 : _a.url_list) || ((_b = video.playAddr) == null ? void 0 : _b.urlList));
    if (!safeHttpsUrl(mediaUrl2, MEDIA_DOMAINS)) throw new Error("抖音作品没有可播放的视频地址");
    const poster = firstUrl(((_c = video.cover) == null ? void 0 : _c.url_list) || ((_d = video.origin_cover) == null ? void 0 : _d.url_list) || ((_e = video.dynamic_cover) == null ? void 0 : _e.url_list));
    const safePoster = poster && safeHttpsUrl(poster, MEDIA_DOMAINS) ? putMediaProxy(poster, userAgent, pageUrl) : "";
    const title = String(detail.desc || video.desc || "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, 300) || `抖音视频 ${id}`;
    const author = String(((_f = detail.author) == null ? void 0 : _f.nickname) || ((_g = detail.author) == null ? void 0 : _g.unique_id) || "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, 100);
    const duration = Math.max(0, Number(video.duration || 0) / 1e3);
    const url = putMediaProxy(mediaUrl2, userAgent, pageUrl);
    return {
      url,
      duration,
      poster: safePoster,
      qualities: [{ name: "默认", html: "默认", url, default: true }],
      title,
      runtime: { source: "douyin", awemeId: id, author, title, poster: safePoster, duration }
    };
  };
  const resolvePlayback$1 = async (client, payload = {}) => {
    const shareUrl = normalizeDouyinShareUrl(String((payload == null ? void 0 : payload.path) || ""));
    if (!shareUrl) throw new Error("请提供有效的抖音视频分享链接");
    return (payload == null ? void 0 : payload.capture) ? resolveCapturedPlayback(payload, shareUrl) : resolvePublicPlayback(client, shareUrl);
  };
  const getMediaProxy = (key) => {
    const value = mediaProxyEntries.get(String(key || ""));
    if (!value || value.expiresAt <= Date.now()) {
      mediaProxyEntries.delete(String(key || ""));
      return null;
    }
    return value;
  };
  const jsonRoute$1 = (handler, errorStatus = 502) => async (request2) => {
    try {
      return jsonResponse(success(await handler(await parseJsonBody$1(request2), request2)));
    } catch (error) {
      return jsonResponse(failure((error == null ? void 0 : error.message) || String(error), errorStatus), errorStatus);
    }
  };
  const proxyRoute$1 = (request2) => {
    var _a, _b;
    const method = requestMethod(request2);
    if (method !== "GET" && method !== "HEAD") return textResponse("method not allowed", 405);
    const entry = getMediaProxy(queryValue(request2, "key"));
    if (!entry) return textResponse("media link expired; resolve it again", 404);
    const requestHeaders = ((_a = request2 == null ? void 0 : request2.request) == null ? void 0 : _a.headers) || ((_b = request2 == null ? void 0 : request2.Request) == null ? void 0 : _b.Headers) || {};
    const range = headerValue(requestHeaders, "range");
    return proxyResponse(entry.url, {
      Referer: entry.referer,
      "User-Agent": entry.userAgent,
      ...range ? { Range: range } : {}
    }, method);
  };
  const createDouyinHandlers = ({ client } = {}) => ({
    "POST /api/douyin/resolve": jsonRoute$1((payload) => resolvePlayback$1(client, payload)),
    "ANY /api/douyin/proxy": proxyRoute$1
  });
  const MAX_SOURCE = 2 * 1024 * 1024;
  const parseJavaScriptValue = (source) => {
    if (typeof source !== "string" || source.length > MAX_SOURCE) return null;
    try {
      return JSON.parse(source);
    } catch {
    }
    let index = 0, nodes = 0;
    const fail = () => {
      throw new Error("invalid embedded value");
    };
    const skip2 = () => {
      for (; ; ) {
        while (/\s/.test(source[index] || "")) index++;
        if (source.startsWith("//", index)) {
          index = source.indexOf("\n", index + 2);
          if (index < 0) index = source.length;
          continue;
        }
        if (source.startsWith("/*", index)) {
          const end = source.indexOf("*/", index + 2);
          if (end < 0) fail();
          index = end + 2;
          continue;
        }
        break;
      }
    };
    const string = () => {
      const quote = source[index++];
      let value2 = "";
      while (index < source.length) {
        const char = source[index++];
        if (char === quote) return value2;
        if (char !== "\\") {
          value2 += char;
          continue;
        }
        if (index >= source.length) fail();
        const escape2 = source[index++];
        const simple = { n: "\n", r: "\r", t: "	", b: "\b", f: "\f", v: "\v", "0": "\0" };
        if (escape2 === "u") {
          const hex = source.slice(index, index + 4);
          if (!/^[\da-f]{4}$/i.test(hex)) fail();
          value2 += String.fromCharCode(parseInt(hex, 16));
          index += 4;
        } else if (escape2 === "x") {
          const hex = source.slice(index, index + 2);
          if (!/^[\da-f]{2}$/i.test(hex)) fail();
          value2 += String.fromCharCode(parseInt(hex, 16));
          index += 2;
        } else if (escape2 === "\n") ;
        else value2 += simple[escape2] ?? escape2;
      }
      return fail();
    };
    const value = (depth = 0) => {
      if (++nodes > 1e5 || depth > 80) fail();
      skip2();
      const char = source[index];
      if (char === "{") {
        index++;
        skip2();
        const result = /* @__PURE__ */ Object.create(null);
        if (source[index] === "}") {
          index++;
          return result;
        }
        for (; ; ) {
          skip2();
          const key = source[index] === '"' || source[index] === "'" ? string() : (() => {
            const m = source.slice(index).match(/^[A-Za-z_$][\w$]*/);
            if (!m) return fail();
            index += m[0].length;
            return m[0];
          })();
          skip2();
          if (source[index++] !== ":") fail();
          result[key] = value(depth + 1);
          skip2();
          if (source[index] === "}") {
            index++;
            return result;
          }
          if (source[index++] !== ",") fail();
          skip2();
          if (source[index] === "}") {
            index++;
            return result;
          }
        }
      }
      if (char === "[") {
        index++;
        skip2();
        const result = [];
        if (source[index] === "]") {
          index++;
          return result;
        }
        for (; ; ) {
          result.push(value(depth + 1));
          skip2();
          if (source[index] === "]") {
            index++;
            return result;
          }
          if (source[index++] !== ",") fail();
          skip2();
          if (source[index] === "]") {
            index++;
            return result;
          }
        }
      }
      if (char === '"' || char === "'") return string();
      const rest = source.slice(index);
      const collection = rest.match(/^new\s+(Map|Set)\s*\(/);
      if (collection) {
        index += collection[0].length;
        skip2();
        const entries = source[index] === ")" ? [] : value(depth + 1);
        skip2();
        if (source[index++] !== ")" || !Array.isArray(entries)) fail();
        if (collection[1] === "Set") return entries;
        const result = /* @__PURE__ */ Object.create(null);
        for (const entry of entries) {
          if (!Array.isArray(entry) || entry.length !== 2 || !["string", "number"].includes(typeof entry[0])) fail();
          result[entry[0]] = entry[1];
        }
        return result;
      }
      const primitive = rest.match(/^(?:true|false|null|undefined|NaN|Infinity)\b/);
      if (primitive) {
        index += primitive[0].length;
        return primitive[0] === "true" ? true : primitive[0] === "false" ? false : primitive[0] === "null" ? null : null;
      }
      const number = rest.match(/^-?(?:0[xX][\da-fA-F]+|(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)/);
      if (number) {
        index += number[0].length;
        const n = Number(number[0]);
        return Number.isFinite(n) ? n : null;
      }
      fail();
    };
    try {
      return value();
    } catch {
      return null;
    }
  };
  function extractAssignedJson(html, names = []) {
    if (typeof html !== "string" || html.length > 16 * 1024 * 1024) return null;
    for (const name of names) {
      let from = 0;
      while ((from = html.indexOf(name, from)) >= 0) {
        let cursor = from + name.length;
        while (/\s/.test(html[cursor] || "")) cursor++;
        if (html[cursor] === ":" || html[cursor] === "=") cursor++;
        else {
          from += name.length;
          continue;
        }
        while (cursor < html.length && !/[{[]/.test(html[cursor])) cursor++;
        if (cursor >= html.length) break;
        const start = cursor, stack = [], quote = { value: "" };
        let escaped = false;
        for (; cursor < html.length; cursor++) {
          const ch = html[cursor];
          if (quote.value) {
            if (escaped) escaped = false;
            else if (ch === "\\") escaped = true;
            else if (ch === quote.value) quote.value = "";
            continue;
          }
          if (ch === '"' || ch === "'") {
            quote.value = ch;
            continue;
          }
          if (ch === "{" || ch === "[") stack.push(ch);
          else if (ch === "}" || ch === "]") {
            const open = stack.pop();
            if (ch === "}" && open !== "{" || ch === "]" && open !== "[") break;
            if (!stack.length) {
              const parsed = parseJavaScriptValue(html.slice(start, cursor + 1));
              if (parsed && Object.keys(parsed).length) return parsed;
              break;
            }
          }
        }
        from += name.length;
      }
    }
    return null;
  }
  function collectObjects(root, predicate) {
    const found = [], seen = /* @__PURE__ */ new Set(), queue = [{ value: root, depth: 0 }];
    for (let index = 0; index < queue.length && index < 5e4; index++) {
      const { value, depth } = queue[index];
      if (!value || typeof value !== "object" || seen.has(value) || depth > 40) continue;
      seen.add(value);
      if (!Array.isArray(value) && predicate(value)) found.push(value);
      for (const child of Object.values(value)) if (child && typeof child === "object") queue.push({ value: child, depth: depth + 1 });
    }
    return found;
  }
  const ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
  function decodeText(value) {
    return String(value ?? "").replace(/&(#x[\da-f]+|#\d+|[a-z]+);/gi, (match, entity) => {
      if (entity[0] === "#") {
        const n = entity[1].toLowerCase() === "x" ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
        return Number.isFinite(n) && n > 0 && n <= 1114111 ? String.fromCodePoint(n) : match;
      }
      return ENTITIES[entity.toLowerCase()] ?? match;
    });
  }
  function mediaUrl(value, base = "") {
    if (typeof value !== "string" || !value.trim()) return "";
    try {
      const raw = value.trim();
      const url = new URL(raw.startsWith("//") ? `https:${raw}` : raw, base || void 0);
      if (url.protocol === "http:") {
        url.protocol = "https:";
        if (url.port === "80") url.port = "";
      }
      if (url.protocol !== "https:" || url.username || url.password || url.port && url.port !== "443") return "";
      return url.href;
    } catch {
      return "";
    }
  }
  const MOBILE_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
  async function resolveKuaishou(context, url) {
    var _a, _b;
    const headers = { "User-Agent": MOBILE_UA, Referer: "https://v.kuaishou.com/" };
    let page = await context.request(url, { headers });
    const resolved = page.url || url;
    if (resolved.includes("/fw/long-video/")) {
      page = await context.request(resolved.replace("/fw/long-video/", "/fw/photo/"), { headers });
    }
    if (page.status === 404 || page.status === 410) throw new Error("快手作品不存在或已删除");
    if ([403, 418, 429].includes(page.status)) throw new Error("快手请求受到风控限制，请稍后重试");
    if (page.status >= 400) throw new Error(`快手页面请求失败（HTTP ${page.status}），请稍后重试`);
    const state = extractAssignedJson(page.text, ["window.INIT_STATE", "INIT_STATE", "window.__INITIAL_STATE__", "__INITIAL_STATE__"]);
    if (!state) {
      if (/captcha|验证码|安全验证|verify/i.test(page.text)) throw new Error("快手需要安全验证，请在浏览器完成验证后重试");
      if (/登录后|请登录/.test(page.text)) throw new Error("快手作品需要登录后访问");
      throw new Error("快手页面没有作品数据，作品可能已删除或页面结构已变化");
    }
    const photos = collectObjects(state, (node) => Array.isArray(node.mainMvUrls) || !!node.videoResource || !!node.photoId && !!node.caption);
    const id = (_a = (page.url || resolved).match(/\/(?:photo|short-video)\/([\w-]+)/)) == null ? void 0 : _a[1];
    const photo = photos.find((node) => id && String(node.photoId || node.id) === id) || photos[0];
    if (!photo) throw new Error("快手页面没有可识别的视频数据，可能需要验证或页面结构已变化");
    const videos = [];
    const seen = /* @__PURE__ */ new Set();
    const add = (value, name) => {
      const target = mediaUrl(value, page.url || resolved);
      if (!target || seen.has(target)) return;
      seen.add(target);
      videos.push({ url: target, name: decodeText(name || "默认"), type: /\.m3u8(?:[?#]|$)/i.test(target) ? "m3u8" : "auto", headers });
    };
    for (const item of collectObjects(photo.videoResource || {}, (node) => typeof node.url === "string" && (!!node.qualityType || !!node.qualityLabel || !!node.height))) {
      add(item.url, item.qualityLabel || item.qualityType || `${item.height}p`);
    }
    for (const item of photo.mainMvUrls || []) add(typeof item === "string" ? item : item == null ? void 0 : item.url, (item == null ? void 0 : item.qualityLabel) || "默认");
    if (!videos.length) throw new Error("快手作品没有可播放视频地址，可能为图集或需要登录");
    const cover = (_b = photo.coverUrls) == null ? void 0 : _b[0];
    return {
      title: decodeText(photo.caption || photo.title || "快手视频"),
      poster: mediaUrl(typeof cover === "string" ? cover : cover == null ? void 0 : cover.url, page.url || resolved),
      duration: Number(photo.duration) > 0 ? Number(photo.duration) / 1e3 : void 0,
      videos
    };
  }
  function resultFromInfo(info, fallbackTitle) {
    var _a;
    const videos = [];
    const seen = /* @__PURE__ */ new Set();
    const headers = { Referer: "https://weibo.com/" };
    const add = (value, name) => {
      const url = mediaUrl(value);
      if (!url || seen.has(url)) return;
      seen.add(url);
      videos.push({ url, name: decodeText(name || "默认"), type: /\.m3u8(?:[?#]|$)/i.test(url) ? "m3u8" : "auto", headers });
    };
    for (const [name, value] of Object.entries(info.urls || {})) add(value, name);
    const media = info.media_info || {};
    for (const item of media.playback_list || []) {
      const play = item.play_info || item;
      add(play.url, play.quality_desc || play.quality_label || (play.height ? `${play.height}p` : "默认"));
    }
    for (const key of ["mp4_1080p_mp4", "mp4_720p_mp4", "mp4_hd_mp4", "mp4_ld_mp4", "stream_url_hd", "stream_url", "h5_url"]) {
      add(media[key] || info[key], key);
    }
    return {
      title: decodeText(info.title || info.page_title || fallbackTitle || "微博视频").replace(/<[^>]*>/g, "").trim(),
      poster: mediaUrl(info.cover_image || ((_a = info.page_pic) == null ? void 0 : _a.url) || media.poster),
      duration: Number(media.duration || info.duration) > 0 ? Number(media.duration || info.duration) : void 0,
      videos
    };
  }
  function assertApi(data) {
    if (!data || typeof data !== "object") throw new Error("微博接口未返回有效数据，请稍后重试");
    if (data.ok === 0 || data.code === 100001) {
      const message = String(data.msg || data.message || "");
      if (/登录|login|passport/i.test(message)) throw new Error("微博内容需要登录后访问");
      if (/删除|不存在|权限/.test(message)) throw new Error("微博内容不存在、已删除或无权访问");
      throw new Error("微博接口拒绝访问，请稍后重试或检查作品是否公开");
    }
  }
  async function resolveWeibo(context, url) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const page = await context.request(url, { headers: { Referer: "https://weibo.com/" } });
    if ([404, 410].includes(page.status)) throw new Error("微博内容不存在或已删除");
    if ([403, 418, 429].includes(page.status)) throw new Error("微博请求受到风控限制，请稍后重试");
    if (page.status >= 400) throw new Error(`微博页面请求失败（HTTP ${page.status}），请稍后重试`);
    const resolved = new URL(page.url || url);
    const original = new URL(url);
    resolved.pathname = resolved.pathname.replace(/%3a/gi, ":");
    original.pathname = original.pathname.replace(/%3a/gi, ":");
    const fid = resolved.searchParams.get("fid") || ((_a = resolved.pathname.match(/\/(?:show|tv\/show)\/(\d+:\d+)/)) == null ? void 0 : _a[1]) || original.searchParams.get("fid") || ((_b = original.pathname.match(/\/(?:show|tv\/show)\/(\d+:\d+)/)) == null ? void 0 : _b[1]);
    if (fid && /^\d+:\d+$/.test(fid)) {
      const data = await context.json(`https://h5.video.weibo.com/api/component?page=${encodeURIComponent(`/show/${fid}`)}`, {
        method: "POST",
        headers: { Referer: `https://h5.video.weibo.com/show/${fid}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ data: JSON.stringify({ Component_Play_Playinfo: { oid: fid } }) }).toString()
      });
      assertApi(data);
      const info = (_c = data.data) == null ? void 0 : _c.Component_Play_Playinfo;
      if (!info) throw new Error("微博视频不存在或需要登录后访问");
      const result = resultFromInfo(info);
      if (!result.videos.length) throw new Error("微博视频没有可播放地址，请检查作品权限");
      return result;
    }
    const id = resolved.searchParams.get("mid") || resolved.searchParams.get("id") || ((_d = resolved.pathname.match(/\/(?:status|detail)\/([a-zA-Z0-9]+)/)) == null ? void 0 : _d[1]) || ((_e = resolved.pathname.match(/^\/\d+\/([a-zA-Z0-9]+)\/?$/)) == null ? void 0 : _e[1]) || original.searchParams.get("mid") || original.searchParams.get("id") || ((_f = original.pathname.match(/\/(?:status|detail)\/([a-zA-Z0-9]+)/)) == null ? void 0 : _f[1]) || ((_g = original.pathname.match(/^\/\d+\/([a-zA-Z0-9]+)\/?$/)) == null ? void 0 : _g[1]);
    let status = extractAssignedJson(page.text, ["$render_data", "window.$render_data"]);
    status = Array.isArray(status) ? (_h = status[0]) == null ? void 0 : _h.status : status == null ? void 0 : status.status;
    if (!status && id) {
      const data = await context.json(`https://m.weibo.cn/statuses/show?id=${encodeURIComponent(id)}`, {
        headers: { Accept: "application/json, text/plain, */*", Referer: `https://m.weibo.cn/detail/${id}`, Origin: "https://m.weibo.cn", "X-Requested-With": "XMLHttpRequest", "MWeibo-Pwa": "1" }
      });
      assertApi(data);
      status = data.data;
    }
    if (!status) {
      if (/passport|登录|login/i.test(page.text)) throw new Error("微博访问需要登录或安全验证，请在浏览器确认链接可访问");
      throw new Error("无法识别微博作品，请使用微博正文或视频分享链接");
    }
    for (const candidate of [status, status.retweeted_status].filter(Boolean)) {
      const result = resultFromInfo(candidate.page_info || {}, candidate.text_raw || candidate.text);
      if (result.videos.length) return result;
    }
    throw new Error("该微博没有可播放视频，或视频已删除/无权访问");
  }
  const HOME = "https://www.xiaohongshu.com";
  const UPDATE_COOKIE = "请在浏览器重新登录小红书，并在「账号凭证」中更新完整 Cookie";
  function assertPage(response, fallbackUrl) {
    const page = new URL(response.url || fallbackUrl);
    if (/\/login|website-login/i.test(page.pathname)) throw new Error(`小红书已跳转登录页，当前 Cookie 未被接受。${UPDATE_COOKIE}`);
    if (/captcha|verify/i.test(page.pathname)) throw new Error("小红书要求安全验证，请在浏览器完成验证后更新「账号凭证」中的 Cookie");
    if (response.status === 401) throw new Error(`小红书未接受登录凭证（HTTP 401）。${UPDATE_COOKIE}`);
    if (response.status === 403) throw new Error("小红书拒绝访问（HTTP 403），请在浏览器确认作品权限及是否需要安全验证");
    if (/^\/404(?:\/|$)/.test(page.pathname)) {
      const code = page.searchParams.get("error_code");
      if (code === "300031") throw new Error("小红书返回：当前笔记暂时无法浏览（300031）。请确认当前登录浏览器可以播放该视频，并重新复制带 xsec_token 的完整作品链接");
      throw new Error("小红书将请求转到了访问限制页面，请在浏览器确认作品可访问，并更新 Cookie 和完整分享链接");
    }
    if (response.status >= 400) throw new Error("小红书笔记访问失败，可能已删除或暂时不可用");
    return page;
  }
  function noteFrom(state, id) {
    var _a, _b, _c, _d, _e;
    return ((_c = (_b = (_a = state == null ? void 0 : state.note) == null ? void 0 : _a.noteDetailMap) == null ? void 0 : _b[id]) == null ? void 0 : _c.note) || ((_e = (_d = state == null ? void 0 : state.noteData) == null ? void 0 : _d.data) == null ? void 0 : _e.noteData);
  }
  function resultFrom(note, page) {
    var _a, _b, _c, _d, _e, _f, _g;
    const videos = [];
    const seen = /* @__PURE__ */ new Set();
    for (let media of [(_a = note == null ? void 0 : note.video) == null ? void 0 : _a.media, (_b = note == null ? void 0 : note.video) == null ? void 0 : _b.mediaV2]) {
      if (typeof media === "string") {
        if (media.length > 2 * 1024 * 1024) continue;
        try {
          media = JSON.parse(media);
        } catch {
          continue;
        }
      }
      const groups = Object.entries((media == null ? void 0 : media.stream) || {}).sort(([a], [b]) => Number(b === "h264") - Number(a === "h264"));
      for (const [codec, renditions] of groups) {
        for (const item of Array.isArray(renditions) ? renditions : []) {
          if (!item || typeof item !== "object") continue;
          const url = mediaUrl(item.masterUrl || item.master_url, page);
          if (!url || seen.has(url)) continue;
          seen.add(url);
          videos.push({ url, name: decodeText(item.qualityType || item.quality_type || item.height && `${item.height}P` || codec.toUpperCase()), type: /\.m3u8(?:[?#]|$)/i.test(url) ? "m3u8" : "auto", headers: { Referer: `${HOME}/` } });
        }
      }
      if (videos.length) break;
    }
    if (!videos.length) throw new Error((note == null ? void 0 : note.video) ? "小红书视频没有可用流地址，可能受限或页面结构已变化" : "该小红书笔记不包含可播放视频");
    const cover = (_c = note == null ? void 0 : note.imageList) == null ? void 0 : _c[0];
    const rawDuration = Number(((_e = (_d = note == null ? void 0 : note.video) == null ? void 0 : _d.consumer) == null ? void 0 : _e.videoDuration) || ((_f = note == null ? void 0 : note.video) == null ? void 0 : _f.duration) || 0);
    const duration = rawDuration > 3600 ? rawDuration / 1e3 : rawDuration;
    return { title: decodeText(note.title || note.desc || "小红书视频"), poster: mediaUrl((cover == null ? void 0 : cover.urlDefault) || (cover == null ? void 0 : cover.url) || ((_g = note == null ? void 0 : note.video) == null ? void 0 : _g.cover), page) || void 0, duration: duration > 0 ? duration : void 0, videos };
  }
  async function resolveXiaohongshu(context, url) {
    var _a, _b;
    if (!((_a = context.cookie) == null ? void 0 : _a.trim())) throw new Error("未配置小红书 Cookie，请在「账号凭证」中添加或启用小红书凭证");
    const headers = { Referer: `${HOME}/`, Cookie: context.cookie, Accept: "text/html,application/xhtml+xml" };
    let response;
    try {
      response = await context.request(url, { headers });
    } catch {
      throw new Error("小红书页面请求失败，请检查网络后重试");
    }
    const final = assertPage(response, url);
    const id = (_b = final.pathname.match(/\/(?:explore|discovery\/item)\/([a-z\d]+)/i)) == null ? void 0 : _b[1];
    if (!id) throw new Error("小红书分享链接未能展开为有效笔记，请重新复制作品分享链接");
    let note = noteFrom(extractAssignedJson(response.text, ["window.__INITIAL_STATE__", "__INITIAL_STATE__"]), id);
    if (note) return resultFrom(note, final.href);
    const alternate = final.pathname.startsWith("/explore/") ? `/discovery/item/${id}` : `/explore/${id}`;
    const query = final.search || new URL(url).search;
    try {
      response = await context.request(`${HOME}${alternate}${query}`, { headers });
    } catch {
      throw new Error("小红书页面请求失败，请检查网络后重试");
    }
    const alternatePage = assertPage(response, `${HOME}${alternate}${query}`);
    note = noteFrom(extractAssignedJson(response.text, ["window.__INITIAL_STATE__", "__INITIAL_STATE__"]), id);
    if (!note) throw new Error("小红书页面未提供笔记数据，请更新 Cookie 和分享链接；也可能遇到验证码或页面改版");
    return resultFrom(note, alternatePage.href);
  }
  const REFERER$1 = "https://www.acfun.cn/";
  function playData(value) {
    if (value && typeof value === "object") return value;
    if (typeof value !== "string") return null;
    try {
      return JSON.parse(value);
    } catch {
      return null;
    }
  }
  async function resolveAcfun(context, url) {
    var _a, _b, _c;
    const input = new URL(url);
    const id = ((_a = input.pathname.match(/\/(?:v\/)?ac(\d+)/i)) == null ? void 0 : _a[1]) || input.searchParams.get("ac");
    if (!/^\d+$/.test(id || "")) throw new Error("AcFun 链接中没有有效视频 ID");
    url = `https://www.acfun.cn/v/ac${id}`;
    let response;
    const headers = { Referer: REFERER$1 };
    try {
      response = await context.request(url, { headers });
    } catch {
      throw new Error("AcFun 页面请求失败，请检查网络后重试");
    }
    if (response.status >= 400) throw new Error("AcFun 视频访问失败，可能已删除或受限");
    let page = response.url || url;
    let info = extractAssignedJson(response.text, ["window.videoInfo", "videoInfo"]);
    if (!info) {
      const parsed = new URL(page);
      const id2 = ((_b = parsed.pathname.match(/\/v\/ac(\d+)/i)) == null ? void 0 : _b[1]) || parsed.searchParams.get("ac");
      if (!id2) throw new Error("AcFun 分享链接未能展开为有效视频链接");
      const target = new URL(page);
      target.searchParams.set("quickViewId", "videoInfo_new");
      target.searchParams.set("ajaxpipe", "1");
      try {
        response = await context.request(target.href, { headers });
      } catch {
        throw new Error("AcFun 视频详情请求失败，请检查网络后重试");
      }
      if (response.status >= 400) throw new Error("AcFun 视频访问失败，可能已删除或受限");
      page = response.url || target.href;
      info = extractAssignedJson(response.text, ["window.videoInfo", "videoInfo"]);
    }
    if (!info) throw new Error("AcFun 页面没有视频信息，可能已删除、需要登录或页面结构已变化");
    const current = info.currentVideoInfo || info;
    const play = playData(current.ksPlayJson);
    const videos = [];
    const seen = /* @__PURE__ */ new Set();
    for (const set of Array.isArray(play == null ? void 0 : play.adaptationSet) ? play.adaptationSet : []) {
      if (set.contentType === "audio" || ((_c = set.mimeType) == null ? void 0 : _c.startsWith("audio/"))) continue;
      for (const representation of Array.isArray(set.representation) ? set.representation : []) {
        const url2 = mediaUrl(representation.url, page);
        if (!url2 || seen.has(url2)) continue;
        seen.add(url2);
        videos.push({ url: url2, name: decodeText(representation.qualityLabel || representation.qualityType || representation.height && `${representation.height}P` || `清晰度 ${videos.length + 1}`), type: "m3u8", headers: { Referer: REFERER$1 } });
      }
    }
    if (!videos.length) throw new Error("AcFun 未提供可播放视频流，可能受限或视频数据结构已变化");
    const duration = Number(current.durationMillis) / 1e3;
    return { title: decodeText(info.title || "AcFun 视频"), poster: mediaUrl(info.coverUrl || current.coverUrl, page) || void 0, duration: duration > 0 ? duration : void 0, videos };
  }
  const REFERER = "https://www.pixiv.net/";
  const imageUrl = (value) => {
    try {
      const u = new URL(value);
      return u.protocol === "https:" && /(^|\.)pximg\.net$/i.test(u.hostname) && !u.username && !u.password ? u.href : "";
    } catch {
      return "";
    }
  };
  async function resolvePixiv(context, url) {
    var _a, _b, _c;
    const parsed = new URL(url);
    const id = ((_a = parsed.pathname.match(/\/artworks\/(\d+)/)) == null ? void 0 : _a[1]) || parsed.searchParams.get("illust_id");
    if (!/^\d+$/.test(id || "")) throw new Error("Pixiv：链接中没有有效作品 ID");
    const headers = { Referer: REFERER, ...context.cookie ? { Cookie: context.cookie } : {} };
    const get = async (suffix) => {
      let result2;
      try {
        result2 = await context.json(`https://www.pixiv.net/ajax/illust/${id}${suffix}`, { headers });
      } catch {
        throw new Error("Pixiv：作品请求失败，请检查网络或有效 Cookie");
      }
      if (!result2 || result2.error || !result2.body) throw new Error("Pixiv：作品不存在、已删除或受限，请检查作品链接及有效 Cookie");
      return result2.body;
    };
    const detail = await get("");
    const pages = await get("/pages");
    if (!Array.isArray(pages) || !pages.length || pages.length > 1e3) throw new Error("Pixiv：作品分页数据无效");
    const images = pages.map((page, index) => {
      var _a2;
      const url2 = imageUrl((_a2 = page == null ? void 0 : page.urls) == null ? void 0 : _a2.original);
      if (!url2) throw new Error("Pixiv：作品原图地址无效");
      return { url: url2, name: `${detail.title || id} · ${index + 1}`, headers: { Referer: REFERER } };
    });
    const result = { title: String(detail.title || `Pixiv ${id}`), poster: imageUrl(((_b = detail.urls) == null ? void 0 : _b.regular) || ((_c = detail.urls) == null ? void 0 : _c.small)) || images[0].url, images };
    if (Number(detail.illustType) === 2) {
      const meta = await get("/ugoira_meta");
      const url2 = imageUrl(meta.originalSrc || meta.src);
      if (!url2 || !Array.isArray(meta.frames) || !meta.frames.length || meta.frames.length > 1e3) throw new Error("Pixiv：动图帧信息无效");
      const seen = /* @__PURE__ */ new Set();
      const frames = meta.frames.map((frame) => {
        if (typeof frame.file !== "string" || !/^[a-zA-Z0-9_-]+\.(?:jpe?g|png|webp|gif)$/i.test(frame.file) || seen.has(frame.file) || !Number.isFinite(frame.delay) || frame.delay < 1 || frame.delay > 6e4) throw new Error("Pixiv：动图帧信息无效");
        seen.add(frame.file);
        return { file: frame.file, delay: frame.delay };
      });
      result.animation = { url: url2, headers: { Referer: REFERER }, frames };
    }
    return result;
  }
  const PRIVATE_BASE = "/plugin/private/siyuan-media-player/api/social/proxy?key=";
  const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
  const MAX_PAGE_BYTES = 8 * 1024 * 1024;
  const MAX_MEDIA_BYTES = 8 * 1024 * 1024;
  const MAX_COOKIE_LENGTH = 16 * 1024;
  const PROXY_TTL = 15 * 60 * 1e3;
  const MAX_PROXIES = 2048;
  const PARSERS = { kuaishou: resolveKuaishou, weibo: resolveWeibo, xiaohongshu: resolveXiaohongshu, acfun: resolveAcfun, pixiv: resolvePixiv };
  const proxyEntries = /* @__PURE__ */ new Map();
  const owns = (host, roots) => roots.some((domain) => host === domain || host.endsWith(`.${domain}`));
  const safeHttps = (value, domains) => {
    try {
      const url = new URL(String(value || ""));
      const host = url.hostname.toLowerCase().replace(/\.$/, "");
      return url.protocol === "https:" && !url.username && !url.password && (!url.port || url.port === "443") && owns(host, domains) ? url : null;
    } catch {
      return null;
    }
  };
  const safePageUrl = (source, value) => {
    var _a;
    const target = safeHttps(value, ((_a = SOCIAL_SITES[source]) == null ? void 0 : _a.pageHosts) || []);
    if (!target || !target.pathname || target.pathname.length > 4096) return null;
    return target;
  };
  const safeMediaUrl = (source, value) => {
    var _a;
    return safeHttps(value, ((_a = SOCIAL_SITES[source]) == null ? void 0 : _a.mediaHosts) || []);
  };
  const isSensitiveSource = (source) => {
    var _a;
    return !!((_a = SOCIAL_SITES[source]) == null ? void 0 : _a.cookieHosts.length);
  };
  const isHlsUrl = (url) => /\.m3u8(?:$|[?#])/i.test(url);
  const mediaType = (media) => /\.mpd(?:$|[?#])/i.test(media.url) ? "mpd" : isHlsUrl(media.url) ? "m3u8" : media.type || "auto";
  const cleanHeader = (value) => String(value || "").replace(/[\r\n\0]/g, "").slice(0, 8192);
  const cleanCookie = (value) => String(value || "").replace(/[\r\n\0]/g, "").slice(0, MAX_COOKIE_LENGTH);
  const purgeProxyEntries = () => {
    const now2 = Date.now();
    for (const [key, entry] of proxyEntries) if (entry.expiresAt <= now2) proxyEntries.delete(key);
    while (proxyEntries.size >= MAX_PROXIES) proxyEntries.delete(proxyEntries.keys().next().value);
  };
  const makeKey = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
  const putProxy = (source, url, headers, cookie = "", referer = "") => {
    const safe = safeMediaUrl(source, url);
    if (!safe) throw new Error(`${source} 返回了不受支持的媒体地址`);
    purgeProxyEntries();
    const key = makeKey();
    proxyEntries.set(key, {
      source,
      url: safe.href,
      headers: { ...headers },
      cookie: isSensitiveSource(source) ? cleanCookie(cookie) : "",
      referer: referer || `${new URL(url).origin}/`,
      hls: isHlsUrl(safe.href),
      expiresAt: Date.now() + PROXY_TTL
    });
    return `${PRIVATE_BASE}${encodeURIComponent(key)}`;
  };
  const normalizeHeaders = (headers) => Object.fromEntries(Object.entries(headers || {}).map(([key, value]) => [key.toLowerCase(), Array.isArray(value) ? value[0] : value]));
  const forward = async (client, url, { method = "GET", headers = {}, body = "", responseLimit = MAX_PAGE_BYTES } = {}) => {
    if (!client || typeof client.fetch !== "function") throw new Error("思源内核网络代理不可用");
    const contentType = cleanHeader(headers["Content-Type"] || headers["content-type"] || "application/json");
    const forwardedHeaders = [];
    for (const [name, raw] of Object.entries(headers)) {
      if (/^(host|content-length|connection|transfer-encoding)$/i.test(name)) continue;
      const value = cleanHeader(raw);
      if (value) forwardedHeaders.push({ [name]: value });
    }
    const response = await client.fetch("/api/network/forwardProxy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url,
        method,
        timeout: 15e3,
        redirect: false,
        headers: forwardedHeaders,
        contentType,
        payload: String(body || ""),
        payloadEncoding: "json",
        responseEncoding: "text"
      })
    });
    let payload;
    try {
      payload = JSON.parse(await response.text());
    } catch {
      throw new Error("思源网络代理返回了无效响应");
    }
    if ((payload == null ? void 0 : payload.code) !== 0 || !(payload == null ? void 0 : payload.data)) throw new Error("思源网络代理请求失败");
    const data = payload.data;
    const status = Number(data.status || 0);
    const text = String(data.body || "");
    if (text.length > responseLimit) throw new Error("站点响应超过 8 MiB 限制");
    return { status, url: String(data.url || url), text, headers: normalizeHeaders(data.headers) };
  };
  const headersFor = (source, url, headers = {}, cookie = "") => {
    var _a;
    const target = safePageUrl(source, url) || safeMediaUrl(source, url);
    if (!target) throw new Error(`${source} 请求地址不在允许范围内`);
    const clean2 = {};
    for (const [name, value] of Object.entries(headers || {})) {
      if (/^(cookie|host|content-length|connection|transfer-encoding)$/i.test(name)) continue;
      const safe = cleanHeader(value);
      if (safe) clean2[name] = safe;
    }
    if (!clean2["User-Agent"] && !clean2["user-agent"]) clean2["User-Agent"] = USER_AGENT;
    const authHosts = ((_a = SOCIAL_SITES[source]) == null ? void 0 : _a.cookieHosts) || [];
    if (cookie && isSensitiveSource(source) && owns(target.hostname.toLowerCase(), authHosts)) {
      clean2.Cookie = cleanCookie(cookie);
    }
    return clean2;
  };
  const request = async (client, source, initialUrl, options = {}, cookie = "") => {
    let url = safePageUrl(source, initialUrl);
    if (!url) throw new Error(`${source} 链接不在允许范围内`);
    let headers = headersFor(source, url.href, options.headers, cookie);
    for (let redirects = 0; redirects <= 5; redirects++) {
      const result = await forward(client, url.href, { method: options.method || "GET", headers, body: options.body || "" });
      const finalUrl = safePageUrl(source, result.url);
      if (!finalUrl) throw new Error(`${source} 页面跳转到了不受支持的地址`);
      if ([301, 302, 303, 307, 308].includes(result.status)) {
        const location = result.headers.location;
        if (!location) throw new Error(`${source} 页面跳转缺少目标地址`);
        if (redirects === 5) throw new Error(`${source} 分享链接跳转次数超限`);
        const next = safePageUrl(source, new URL(location, finalUrl).href);
        if (!next) throw new Error(`${source} 页面跳转到了不受支持的地址`);
        if (result.status === 303 || (result.status === 301 || result.status === 302) && options.method === "POST") options = { ...options, method: "GET", body: "" };
        url = next;
        headers = headersFor(source, url.href, headers, cookie);
        continue;
      }
      return { ...result, url: finalUrl.href };
    }
    throw new Error(`${source} 分享链接跳转失败`);
  };
  const json = async (client, source, url, options = {}, cookie = "") => {
    const response = await request(client, source, url, options, cookie);
    if (response.status < 200 || response.status >= 300) throw new Error(`${source} 接口请求失败（HTTP ${response.status}）`);
    try {
      return JSON.parse(response.text);
    } catch {
      throw new Error(`${source} 接口返回了无效 JSON`);
    }
  };
  const proxyUrl = (source, media, cookie, fallbackReferer) => {
    const target = safeMediaUrl(source, media.url);
    if (!target) throw new Error(`${source} 返回了不受支持的媒体地址`);
    const headers = headersFor(source, target.href, media.headers, cookie);
    if (!headers.Referer && !headers.referer) headers.Referer = fallbackReferer;
    const referer = headers.Referer || headers.referer || fallbackReferer;
    return putProxy(source, target.href, headers, cookie, referer);
  };
  const forwardMedia = async (client, entry, initialUrl, headers) => {
    let url = safeMediaUrl(entry.source, initialUrl);
    if (!url) throw new Error("媒体跳转地址不受支持");
    let outgoing = { ...headers };
    for (let redirects = 0; redirects <= 5; redirects++) {
      const response = await forward(client, url.href, { method: "GET", headers: outgoing, responseLimit: MAX_MEDIA_BYTES });
      const final = safeMediaUrl(entry.source, response.url);
      if (!final) throw new Error("媒体跳转地址不受支持");
      if (![301, 302, 303, 307, 308].includes(response.status)) return { ...response, url: final.href };
      if (redirects === 5 || !response.headers.location) throw new Error("媒体地址跳转次数超限");
      const next = safeMediaUrl(entry.source, new URL(response.headers.location, final).href);
      if (!next) throw new Error("媒体跳转地址不受支持");
      url = next;
      outgoing = headersFor(entry.source, url.href, outgoing, entry.cookie);
    }
    throw new Error("媒体地址跳转失败");
  };
  const resolveSocial = async (client, payload = {}) => {
    var _a, _b, _c;
    const source = String(payload.source || "");
    const parser = PARSERS[source];
    if (!parser) throw new Error("不支持的社交媒体来源");
    const url = safePageUrl(source, payload.path);
    if (!url) throw new Error("请提供有效的作品分享链接");
    const cookie = cleanCookie(payload.cookie);
    const context = {
      cookie,
      request: (target, options = {}) => request(client, source, target, options, cookie),
      json: (target, options = {}) => json(client, source, target, options, cookie)
    };
    const result = await parser(context, url.href);
    const referer = `${url.origin}/`;
    const videos = (result.videos || []).map((media) => ({ ...media, type: mediaType(media), url: proxyUrl(source, media, cookie, referer) }));
    const images = (result.images || []).map((media) => ({ ...media, url: proxyUrl(source, media, cookie, referer) }));
    const animation = result.animation ? { ...result.animation, url: proxyUrl(source, result.animation, cookie, referer) } : void 0;
    const qualities = videos.map((video, index) => ({ name: video.name || `清晰度 ${index + 1}`, html: video.name || `清晰度 ${index + 1}`, url: video.url, type: video.type || "auto", default: index === 0 }));
    return {
      url: ((_a = videos[0]) == null ? void 0 : _a.url) || ((_b = images[0]) == null ? void 0 : _b.url) || "",
      type: ((_c = videos[0]) == null ? void 0 : _c.type) || (images.length ? "image" : "auto"),
      title: String(result.title || "").slice(0, 300),
      poster: result.poster ? proxyUrl(source, { url: result.poster, headers: result.posterHeaders || {} }, cookie, referer) : "",
      duration: Number(result.duration || 0),
      qualities,
      images: images.map(({ url: url2, name }) => ({ url: url2, name })),
      animation: animation ? { url: animation.url, frames: animation.frames } : void 0,
      runtime: { source, title: String(result.title || "").slice(0, 300) }
    };
  };
  const getProxy = (key) => {
    const entry = proxyEntries.get(String(key || ""));
    if (!entry || entry.expiresAt <= Date.now()) {
      proxyEntries.delete(String(key || ""));
      return null;
    }
    entry.expiresAt = Date.now() + PROXY_TTL;
    return entry;
  };
  const rewriteManifest = (text, entry, finalUrl) => {
    const rewrite = (value) => {
      const target = safeMediaUrl(entry.source, new URL(value, finalUrl).href);
      if (!target) throw new Error("HLS 清单包含不受支持的媒体地址");
      return putProxy(entry.source, target.href, entry.headers, entry.cookie, entry.referer);
    };
    return text.split(/\r?\n/).map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;
      if (trimmed.startsWith("#")) return line.replace(/URI=(['"])(.*?)\1/g, (_match, quote, uri) => `URI=${quote}${rewrite(uri)}${quote}`);
      return rewrite(trimmed);
    }).join("\n");
  };
  const proxyRoute = (client, requestObject) => {
    var _a, _b;
    const method = requestMethod(requestObject);
    if (method !== "GET" && method !== "HEAD") return textResponse("method not allowed", 405);
    const entry = getProxy(queryValue(requestObject, "key"));
    if (!entry) return textResponse("media link expired; resolve it again", 404);
    const target = safeMediaUrl(entry.source, entry.url);
    if (!target) return textResponse("media link is no longer supported", 404);
    const incomingHeaders = ((_a = requestObject == null ? void 0 : requestObject.request) == null ? void 0 : _a.headers) || ((_b = requestObject == null ? void 0 : requestObject.Request) == null ? void 0 : _b.Headers) || {};
    const range = headerValue(incomingHeaders, "range");
    const headers = { ...headersFor(entry.source, target.href, entry.headers, entry.cookie), ...range ? { Range: cleanHeader(range) } : {} };
    if (entry.hls && method === "GET") {
      return forwardMedia(client, entry, target.href, headers).then((response) => {
        if (response.status < 200 || response.status >= 300) return textResponse("HLS playlist request failed", response.status || 502);
        return textResponse(rewriteManifest(response.text, entry, response.url), 200, "application/vnd.apple.mpegurl; charset=utf-8");
      }).catch((error) => textResponse((error == null ? void 0 : error.message) || "HLS playlist request failed", 502));
    }
    return proxyResponse(target.href, headers, method);
  };
  const createSocialVideoHandlers = ({ client } = {}) => ({
    "POST /api/social/resolve": async (requestObject) => {
      try {
        return jsonResponse(success(await resolveSocial(client, await parseJsonBody$1(requestObject))));
      } catch (error) {
        return jsonResponse(failure((error == null ? void 0 : error.message) || "社交媒体解析失败", 502), 502);
      }
    },
    "ANY /api/social/proxy": (requestObject) => proxyRoute(client, requestObject)
  });
  const FETCH_TIMEOUT = 12e3;
  const SITE_CACHE_TTL = 6e4;
  const DETAIL_CACHE_TTL$1 = 6e4;
  const NAME_SPLIT_RE = /[,，、\s]+/;
  let sitesCache = null;
  const detailCache$1 = /* @__PURE__ */ new Map();
  const now$1 = () => Date.now();
  const safeJsonParse = (text = "") => {
    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  };
  const decodeSafe$1 = (value = "") => {
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  };
  const decodeBase64 = (text = "") => {
    try {
      if (typeof atob === "function") return atob(text);
      if (typeof Buffer !== "undefined") return Buffer.from(text, "base64").toString("utf-8");
    } catch {
    }
    return "";
  };
  const getCached = (cached) => cached && cached.expiresAt > now$1() ? cached.value : null;
  const looksLikeJson = (contentType = "", text = "") => {
    const clean2 = String(text || "").trim();
    return /json/i.test(contentType || "") || clean2.startsWith("{") || clean2.startsWith("[");
  };
  const stripCdata = (value = "") => String(value || "").replace(/^<!\[CDATA\[/, "").replace(/\]\]>$/, "").trim();
  const xmlDecode = (value = "") => stripCdata(value).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
  const xmlBlocks = (xml = "", tag = "") => [...String(xml || "").matchAll(new RegExp(`<${tag}\\b[^>]*>[\\s\\S]*?<\\/${tag}>`, "gi"))].map((match) => match[0]);
  const xmlAttr = (xml = "", name = "") => {
    var _a;
    return xmlDecode(((_a = String(xml || "").match(new RegExp(`\\b${name}=["']([^"']*)["']`, "i"))) == null ? void 0 : _a[1]) || "");
  };
  const xmlText = (xml = "", tag = "") => {
    var _a;
    return xmlDecode(((_a = String(xml || "").match(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"))) == null ? void 0 : _a[1]) || "");
  };
  const TVBOX_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
  const timeoutFetch = async (client, url, timeout = FETCH_TIMEOUT) => {
    var _a, _b, _c;
    const response = await Promise.race([
      client.fetch("/api/network/forwardProxy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url,
          method: "GET",
          headers: [{ "User-Agent": TVBOX_UA }],
          payloadEncoding: "text"
        })
      }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("Request timeout")), timeout))
    ]);
    const result = JSON.parse(await response.text());
    if ((result == null ? void 0 : result.code) !== 0) throw new Error((result == null ? void 0 : result.msg) || "forward request failed");
    const status = Number((_a = result == null ? void 0 : result.data) == null ? void 0 : _a.status);
    if (status >= 400) throw new Error(`HTTP ${status}`);
    return { contentType: String(((_b = result == null ? void 0 : result.data) == null ? void 0 : _b.contentType) || ""), text: String(((_c = result == null ? void 0 : result.data) == null ? void 0 : _c.body) || "") };
  };
  const buildUrlCandidates = (rawUrl = "") => {
    const out = /* @__PURE__ */ new Set();
    if (rawUrl) out.add(rawUrl);
    try {
      const url = new URL(rawUrl);
      if (url.protocol === "http:") {
        url.protocol = "https:";
        out.add(url.toString());
      }
    } catch {
    }
    return [...out];
  };
  const normalizeSite = (raw = {}, sourceFrom = "", i = 0) => ({
    key: String((raw == null ? void 0 : raw.key) || (raw == null ? void 0 : raw.id) || (raw == null ? void 0 : raw.name) || i),
    name: String((raw == null ? void 0 : raw.name) || (raw == null ? void 0 : raw.title) || (raw == null ? void 0 : raw.key) || (raw == null ? void 0 : raw.id) || `Source ${i + 1}`),
    api: (raw == null ? void 0 : raw.api) || (raw == null ? void 0 : raw.base) || (raw == null ? void 0 : raw.endpoint) || void 0,
    type: typeof (raw == null ? void 0 : raw.type) === "number" ? raw.type : typeof (raw == null ? void 0 : raw.type) === "string" ? parseInt(raw.type, 10) : void 0,
    searchable: (raw == null ? void 0 : raw.searchable) ?? (raw == null ? void 0 : raw.search) ?? 1,
    ext: raw == null ? void 0 : raw.ext,
    sourceFrom
  });
  const dedupeSites = (sites = []) => {
    const map = /* @__PURE__ */ new Map();
    for (const site of sites) {
      if (!(site == null ? void 0 : site.name) && !(site == null ? void 0 : site.key)) continue;
      const key = String(site.api || site.key || site.name || "").trim();
      if (!key || map.has(key)) continue;
      map.set(key, site);
    }
    return [...map.values()];
  };
  const parseSiteArrayFromJson = (obj, sourceFrom = "") => {
    var _a;
    const arr = (obj == null ? void 0 : obj.sites) || (obj == null ? void 0 : obj.list) || (obj == null ? void 0 : obj.rules) || ((_a = obj == null ? void 0 : obj.data) == null ? void 0 : _a.sites) || [];
    if (!Array.isArray(arr)) return [];
    return dedupeSites(arr.map((it, i) => normalizeSite(it, sourceFrom, i)));
  };
  const extractSitesFromText = (text = "", sourceFrom = "") => {
    const found = [];
    const addSites = (obj) => found.push(...parseSiteArrayFromJson(obj, sourceFrom));
    const parsed = safeJsonParse(text);
    if (parsed) addSites(parsed);
    const stripped = text.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ");
    for (const line of stripped.split(/\r?\n/)) {
      const clean2 = line.trim();
      if (!clean2.includes("$")) continue;
      const [name, api] = clean2.split("$");
      if (name && api && /^https?:\/\//i.test(api.trim())) found.push({ key: name.trim(), name: name.trim(), api: api.trim(), sourceFrom });
    }
    for (const match of text.matchAll(/atob\(["']([A-Za-z0-9+/=]+)["']\)/g)) {
      const decoded = decodeBase64(match[1] || "");
      const obj = safeJsonParse(decoded) || safeJsonParse(decodeSafe$1(decoded));
      if (obj) addSites(obj);
    }
    for (const block of (text.match(/[A-Za-z0-9+/=]{200,}/g) || []).slice(0, 10)) {
      let decoded = decodeBase64(block);
      if (!decoded) continue;
      for (let i = 0; i < 2; i++) {
        const compact = decoded.replace(/\s+/g, "");
        if (!compact || !/^[A-Za-z0-9+/=]+$/.test(compact)) break;
        decoded = decodeBase64(compact);
        if (!decoded) break;
      }
      const obj = safeJsonParse(decoded);
      if (obj) addSites(obj);
    }
    return dedupeSites(found);
  };
  async function requestFirstMatch(client, urls, parse, timeout = FETCH_TIMEOUT) {
    for (const url of urls) {
      try {
        const { text, contentType } = await timeoutFetch(client, url, timeout);
        const value = parse(text, contentType);
        if (Array.isArray(value) ? value.length : value) return value;
      } catch {
      }
    }
    return null;
  }
  const loadAllSites = async (client, config = {}) => {
    const key = JSON.stringify((config == null ? void 0 : config.sources) || []);
    const cached = getCached(sitesCache);
    if (cached && sitesCache.key === key) return cached;
    const rules = (Array.isArray(config == null ? void 0 : config.sources) ? config.sources : []).filter((rule) => rule.enabled !== false);
    const results = await Promise.allSettled(rules.map((source) => fetchSitesFromSource(client, source)));
    const all = [];
    for (const result of results) {
      if (result.status !== "fulfilled") continue;
      const picked = result.value.filter((site) => /^https?:\/\//i.test(site.api || ""));
      all.push(...picked.length ? picked : result.value);
    }
    const value = dedupeSites(all);
    sitesCache = { key, value, expiresAt: now$1() + SITE_CACHE_TTL };
    return value;
  };
  const getHomeSiteKey = (config = {}) => typeof (config == null ? void 0 : config.homeSiteKey) === "string" ? config.homeSiteKey : "";
  async function fetchSitesFromSource(client, source = {}) {
    if (source.kind === "inline" || String(source.url || "").startsWith("inline://")) {
      return dedupeSites((Array.isArray(source.sites) ? source.sites : []).map((it, i) => normalizeSite(it, "inline", i)));
    }
    for (const url of buildUrlCandidates(source.url || "")) {
      try {
        const { text, contentType } = await timeoutFetch(client, url);
        if (looksLikeJson(contentType, text)) {
          const fromJson = parseSiteArrayFromJson(safeJsonParse(text), source.kind || "site");
          if (fromJson.length) return dedupeSites(fromJson.filter((site) => !!site.api));
        }
        const fromText = extractSitesFromText(text, source.kind || "site");
        if (fromText.length) return dedupeSites(fromText.filter((site) => !!site.api));
      } catch {
      }
    }
    return [];
  }
  const parseJsonList = (obj) => {
    var _a;
    const arr = (obj == null ? void 0 : obj.list) || ((_a = obj == null ? void 0 : obj.data) == null ? void 0 : _a.list) || (obj == null ? void 0 : obj.data) || [];
    if (!Array.isArray(arr)) return [];
    return arr.map((v) => ({
      id: String((v == null ? void 0 : v.vod_id) ?? (v == null ? void 0 : v.id) ?? (v == null ? void 0 : v.vid) ?? (v == null ? void 0 : v.ids) ?? ""),
      title: String((v == null ? void 0 : v.vod_name) ?? (v == null ? void 0 : v.name) ?? (v == null ? void 0 : v.title) ?? ""),
      pic: String((v == null ? void 0 : v.vod_pic) ?? (v == null ? void 0 : v.pic) ?? (v == null ? void 0 : v.cover) ?? ""),
      vod_id: v == null ? void 0 : v.vod_id,
      vod_name: v == null ? void 0 : v.vod_name,
      vod_pic: v == null ? void 0 : v.vod_pic,
      remarks: (v == null ? void 0 : v.vod_remarks) || (v == null ? void 0 : v.remarks) || (v == null ? void 0 : v.note) || (v == null ? void 0 : v.vod_state) || "",
      year: (v == null ? void 0 : v.vod_year) || (v == null ? void 0 : v.year) || "",
      area: (v == null ? void 0 : v.vod_area) || (v == null ? void 0 : v.area) || "",
      type_name: (v == null ? void 0 : v.type_name) || (v == null ? void 0 : v.vod_tag) || ""
    })).filter((item) => item.id && item.title);
  };
  const parseXmlList = (xml = "") => {
    const blocks = [...xmlBlocks(xml, "video"), ...xmlBlocks(xml, "item")];
    return blocks.map((block) => ({
      id: xmlText(block, "id") || xmlAttr(block, "id"),
      title: xmlText(block, "name") || xmlText(block, "title"),
      pic: xmlText(block, "pic") || xmlAttr(block, "pic")
    })).filter((item) => item.id && item.title);
  };
  const parseJsonCategories = (obj) => {
    var _a;
    const classes = (obj == null ? void 0 : obj.class) || (obj == null ? void 0 : obj.types) || ((_a = obj == null ? void 0 : obj.data) == null ? void 0 : _a.class) || [];
    if (!Array.isArray(classes)) return [];
    return classes.map((c, i) => ({
      id: String((c == null ? void 0 : c.type_id) ?? (c == null ? void 0 : c.tid) ?? (c == null ? void 0 : c.id) ?? i + 1),
      name: String((c == null ? void 0 : c.type_name) ?? (c == null ? void 0 : c.name) ?? `Category ${i + 1}`)
    })).filter((c) => c.id && c.name);
  };
  const parseXmlCategories = (xml = "") => {
    const tys = xmlBlocks(xml, "ty").map((block) => ({ id: xmlAttr(block, "id"), name: xmlDecode(block.replace(/^<ty\b[^>]*>|<\/ty>$/gi, "")) }));
    const types = xmlBlocks(xml, "type").map((block) => ({ id: xmlAttr(block, "id"), name: xmlAttr(block, "name") || xmlDecode(block.replace(/^<type\b[^>]*>|<\/type>$/gi, "")) }));
    return [...tys, ...types].filter((c) => c.id && c.name);
  };
  const parseListAuto = (text, contentType) => looksLikeJson(contentType, text) ? parseJsonList(safeJsonParse(text)) : parseXmlList(text);
  const parseCategoriesAuto = (text, contentType) => looksLikeJson(contentType, text) ? parseJsonCategories(safeJsonParse(text)) : parseXmlCategories(text);
  const parseEpisodeUrls = (value = "") => String(value || "").split("#").map((line) => {
    const [name, url] = line.split("$");
    const finalUrl = (url || name || "").trim();
    return { name: name || "Play", url: finalUrl };
  }).filter((ep) => /^https?:\/\//i.test(ep.url));
  const parsePlayFromJson = (obj) => {
    var _a, _b;
    const item = ((_a = obj == null ? void 0 : obj.list) == null ? void 0 : _a[0]) || ((_b = obj == null ? void 0 : obj.data) == null ? void 0 : _b[0]) || (obj == null ? void 0 : obj.data) || (obj == null ? void 0 : obj.list);
    if (!item) return "";
    const urls = (item == null ? void 0 : item.vod_play_url) || (item == null ? void 0 : item.play_url) || "";
    if (typeof urls === "string" && urls) {
      const list = parseEpisodeUrls(urls).map((it) => it.url);
      return list.find((url) => /\.m3u8(\?|$)/i.test(url)) || list[0] || "";
    }
    if (Array.isArray(urls)) {
      const list = urls.filter((url) => typeof url === "string" && /^https?:\/\//i.test(url));
      return list.find((url) => /\.m3u8(\?|$)/i.test(url)) || list[0] || "";
    }
    const match = JSON.stringify(item).match(/https?:\/\/[^\s"'\\]+/g);
    if (!(match == null ? void 0 : match.length)) return "";
    return (match.find((url) => /\.m3u8(\?|$)/i.test(url)) || match[0] || "").replace(/\\\\/g, "\\");
  };
  const parsePlayFromXml = (xml = "") => {
    const urls = xmlBlocks(xml, "dd").flatMap((block) => parseEpisodeUrls(xmlDecode(block.replace(/^<dd\b[^>]*>|<\/dd>$/gi, ""))).map((it) => it.url));
    return urls.find((url) => /\.m3u8(\?|$)/i.test(url)) || urls[0] || "";
  };
  const fetchListPreferCovers = async (client, site, candidates) => {
    let fallback = null;
    for (const url of candidates) {
      try {
        const { text, contentType } = await timeoutFetch(client, url);
        const list = parseListAuto(text, contentType).map((item) => ({ ...item, site }));
        if (!list.length) continue;
        if (list.some((item) => !!item.pic)) return list;
        if (!fallback) fallback = list;
      } catch {
      }
    }
    return fallback || [];
  };
  const cmsHome = async (client, site) => {
    if (!(site == null ? void 0 : site.api)) return [];
    return await requestFirstMatch(client, [`${site.api}?ac=list`, `${site.api}?ac=class`, `${site.api}`], (text, contentType) => {
      const list = parseCategoriesAuto(text, contentType);
      return list.length ? list : null;
    }) || [];
  };
  const cmsListByType = (client, site, typeId, page = 1) => {
    if (!(site == null ? void 0 : site.api)) return [];
    const tid = encodeURIComponent(typeId);
    return fetchListPreferCovers(client, site, [
      `${site.api}?ac=list&t=${tid}&pg=${page}`,
      `${site.api}?ac=detail&t=${tid}&pg=${page}`,
      `${site.api}?ac=videolist&t=${tid}&pg=${page}`,
      `${site.api}?t=${tid}&pg=${page}`
    ]);
  };
  const cmsSearch = (client, site, keyword) => {
    if (!(site == null ? void 0 : site.api)) return [];
    const wd = encodeURIComponent(keyword);
    return fetchListPreferCovers(client, site, [`${site.api}?wd=${wd}`, `${site.api}?ac=detail&wd=${wd}`, `${site.api}?ac=list&wd=${wd}`]);
  };
  const splitNames = (text = "") => String(text || "").split(NAME_SPLIT_RE).map((value) => value.trim()).filter(Boolean).map((name) => ({ name }));
  const parseDetailFromJson = (obj) => {
    var _a, _b;
    const item = ((_a = obj == null ? void 0 : obj.list) == null ? void 0 : _a[0]) || ((_b = obj == null ? void 0 : obj.data) == null ? void 0 : _b[0]) || (obj == null ? void 0 : obj.data) || (obj == null ? void 0 : obj.list);
    if (!item) return {};
    const froms = String((item == null ? void 0 : item.vod_play_from) || (item == null ? void 0 : item.play_from) || "").split("$$$").filter(Boolean);
    const segs = String((item == null ? void 0 : item.vod_play_url) || (item == null ? void 0 : item.play_url) || "").split("$$$").filter(Boolean);
    const sources = froms.map((from, i) => ({ from, episodes: parseEpisodeUrls(segs[i] || "") })).filter((source) => source.episodes.length);
    if (!sources.length) {
      const single = parsePlayFromJson({ list: [item] });
      if (single) sources.push({ from: "default", episodes: [{ name: "Play", url: single }] });
    }
    return {
      title: (item == null ? void 0 : item.vod_name) || (item == null ? void 0 : item.title) || "",
      pic: (item == null ? void 0 : item.vod_pic) || (item == null ? void 0 : item.pic) || "",
      remarks: (item == null ? void 0 : item.vod_remarks) || (item == null ? void 0 : item.remarks) || "",
      url: parsePlayFromJson({ list: [item] }),
      sources,
      year: item == null ? void 0 : item.vod_year,
      area: item == null ? void 0 : item.vod_area,
      directors: splitNames(item == null ? void 0 : item.vod_director),
      casts: splitNames(item == null ? void 0 : item.vod_actor),
      content: item == null ? void 0 : item.vod_content,
      genres: String((item == null ? void 0 : item.vod_class) || (item == null ? void 0 : item.type_name) || "").split(NAME_SPLIT_RE).filter(Boolean),
      score: (item == null ? void 0 : item.vod_score) || (item == null ? void 0 : item.vod_douban_score) || (item == null ? void 0 : item.score),
      pubdate: (item == null ? void 0 : item.vod_pubdate) || (item == null ? void 0 : item.vod_release_date) || (item == null ? void 0 : item.pubdate),
      duration: (item == null ? void 0 : item.vod_duration) || (item == null ? void 0 : item.duration) || (item == null ? void 0 : item.vod_length) || (item == null ? void 0 : item.vod_len),
      lang: (item == null ? void 0 : item.vod_lang) || (item == null ? void 0 : item.lang)
    };
  };
  const parseDetailFromXml = (xml = "") => {
    const vod = xmlBlocks(xml, "video")[0] || xmlBlocks(xml, "vod")[0] || "";
    if (!vod) return {};
    const sources = xmlBlocks(vod || xml, "dd").map((block) => ({
      from: xmlAttr(block, "flag") || "default",
      episodes: parseEpisodeUrls(xmlDecode(block.replace(/^<dd\b[^>]*>|<\/dd>$/gi, "")))
    })).filter((source) => source.episodes.length);
    if (!sources.length) {
      const single = parsePlayFromXml(xml);
      if (single) sources.push({ from: "default", episodes: [{ name: "Play", url: single }] });
    }
    return {
      title: xmlText(vod, "name"),
      pic: xmlText(vod, "pic"),
      remarks: xmlText(vod, "note"),
      url: parsePlayFromXml(xml),
      sources,
      year: xmlText(vod, "year"),
      area: xmlText(vod, "area"),
      directors: splitNames(xmlText(vod, "director")),
      casts: splitNames(xmlText(vod, "actor")),
      content: xmlText(vod, "des"),
      genres: xmlText(vod, "class").split(NAME_SPLIT_RE).filter(Boolean),
      score: xmlText(vod, "score") || xmlText(vod, "douban_score"),
      pubdate: xmlText(vod, "pubdate") || xmlText(vod, "last"),
      duration: xmlText(vod, "duration") || xmlText(vod, "len") || xmlText(vod, "length"),
      lang: xmlText(vod, "lang")
    };
  };
  const cmsDetailInfo = async (client, site, id) => {
    if (!(site == null ? void 0 : site.api) || !id) return {};
    const cacheKey = `${site.api}|${id}`;
    const cached = getCached(detailCache$1.get(cacheKey));
    if (cached) return { ...cached, site };
    const itemId = encodeURIComponent(id);
    const detail = await requestFirstMatch(client, [
      `${site.api}?ac=detail&ids=${itemId}`,
      `${site.api}?ac=videolist&ids=${itemId}`,
      `${site.api}?ids=${itemId}`
    ], (text, contentType) => {
      var _a;
      const info = looksLikeJson(contentType, text) ? parseDetailFromJson(safeJsonParse(text)) : parseDetailFromXml(text);
      return info && (((_a = info.sources) == null ? void 0 : _a.length) || info.url) ? info : null;
    });
    const value = detail || {};
    detailCache$1.set(cacheKey, { value, expiresAt: now$1() + DETAIL_CACHE_TTL$1 });
    return { ...value, site };
  };
  const DOUBAN_BASE = "https://m.douban.com/rexxar/api/v2";
  const sanitizeTvTitle = (title = "") => String(title || "").replace(/[（(]\s*第?\s*\d+\s*[集话季部篇期]\s*[）)]/g, "").replace(/第\s*\d+\s*[集话季部篇期]/g, "").replace(/\s*[-_]\s*第?\s*\d+\s*[集话季部篇期].*$/g, "").replace(/\s+/g, " ").trim();
  const doubanFetch = async (client, path, params = {}) => {
    const url = new URL(`${DOUBAN_BASE}${path}`);
    Object.entries(params).forEach(([key, value]) => url.searchParams.append(key, String(value)));
    try {
      const response = await client.fetch(url.toString(), {
        method: "GET",
        headers: { Referer: "https://m.douban.com/" }
      });
      if ((response == null ? void 0 : response.status) && response.status >= 400) throw new Error(`HTTP ${response.status}`);
      return JSON.parse(await response.text());
    } catch {
      return null;
    }
  };
  const searchMovie = async (client, query) => {
    var _a, _b;
    const key = String(query || "").trim();
    if (!key) return null;
    const data = await doubanFetch(client, "/search/subjects", { q: key, type: "movie", count: 1 });
    const item = (_b = (_a = data == null ? void 0 : data.subjects) == null ? void 0 : _a.items) == null ? void 0 : _b[0];
    return item ? { id: item.target_id, ...item.target } : null;
  };
  const getMovieDetail = (client, id) => id ? doubanFetch(client, `/movie/${id}`) : null;
  const enrichTvboxDetailWithDouban = async (client, title, detail = {}) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
    const query = sanitizeTvTitle(title || (detail == null ? void 0 : detail.title) || (detail == null ? void 0 : detail.vod_name) || "");
    if (!query) return detail || {};
    const match = await searchMovie(client, query);
    if (!(match == null ? void 0 : match.id)) return detail || {};
    const douban = await getMovieDetail(client, match.id);
    if (!douban) return detail || {};
    return {
      ...detail,
      title: douban.title || (detail == null ? void 0 : detail.title),
      original_title: douban.original_title || (detail == null ? void 0 : detail.original_title) || "",
      pic: ((_a = douban.pic) == null ? void 0 : _a.large) || ((_b = douban.pic) == null ? void 0 : _b.normal) || (detail == null ? void 0 : detail.pic) || "",
      genres: ((_c = douban.genres) == null ? void 0 : _c.length) ? douban.genres : detail == null ? void 0 : detail.genres,
      rating: douban.rating || (detail == null ? void 0 : detail.rating),
      score: ((_d = douban.rating) == null ? void 0 : _d.value) || (detail == null ? void 0 : detail.score) || "",
      directors: ((_e = douban.directors) == null ? void 0 : _e.length) ? douban.directors : detail == null ? void 0 : detail.directors,
      casts: ((_f = douban.actors) == null ? void 0 : _f.length) ? douban.actors : detail == null ? void 0 : detail.casts,
      year: douban.year || (detail == null ? void 0 : detail.year) || "",
      countries: ((_g = douban.countries) == null ? void 0 : _g.length) ? douban.countries : detail == null ? void 0 : detail.countries,
      summary: douban.intro || (detail == null ? void 0 : detail.summary) || (detail == null ? void 0 : detail.content) || "",
      aka: ((_h = douban.aka) == null ? void 0 : _h.length) ? douban.aka : detail == null ? void 0 : detail.aka,
      durations: ((_i = douban.durations) == null ? void 0 : _i.length) ? douban.durations : detail == null ? void 0 : detail.durations,
      trailers: ((_j = douban.trailers) == null ? void 0 : _j.length) ? douban.trailers : detail == null ? void 0 : detail.trailers,
      pubdate: douban.pubdate || (detail == null ? void 0 : detail.pubdate) || "",
      languages: ((_k = douban.languages) == null ? void 0 : _k.length) ? douban.languages : detail == null ? void 0 : detail.languages,
      episodes_count: douban.episodes_count || (detail == null ? void 0 : detail.episodes_count) || 0
    };
  };
  const DETAIL_CACHE_TTL = 6e4;
  const PLAYABLE_CACHE_TTL = 3e4;
  const SOURCE_ID = "tvbox";
  const PROTOCOL = "tvbox://";
  const normalizeAssetUrl = (value = "") => {
    const url = String(value || "").trim();
    return url.startsWith("//") ? `https:${url}` : url.replace(/^http:\/\//i, "https://");
  };
  const itemCache = /* @__PURE__ */ new Map();
  const detailCache = /* @__PURE__ */ new Map();
  const playableCache = /* @__PURE__ */ new Map();
  const now = () => Date.now();
  const pickFirst = (item, ...keys) => keys.map((key) => item == null ? void 0 : item[key]).find(Boolean) || "";
  const joinText = (list = []) => list.filter(Boolean).map((item) => `${item}`).join(" / ");
  const hasM3u8Episode = (source) => ((source == null ? void 0 : source.episodes) || []).some((ep) => /\.m3u8(\?|$)/i.test((ep == null ? void 0 : ep.url) || ""));
  const sortTvboxSources = (sources = []) => [...sources].sort((a, b) => Number(hasM3u8Episode(b)) - Number(hasM3u8Episode(a)));
  const decodeSafe = (value = "") => {
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  };
  const parseJsonBody = async (request2) => {
    var _a, _b;
    const body = ((_a = request2 == null ? void 0 : request2.request) == null ? void 0 : _a.body) || ((_b = request2 == null ? void 0 : request2.Request) == null ? void 0 : _b.Body) || {};
    const data = body.data ?? body.Data;
    if (!data) return {};
    if (typeof data.json === "function") return await data.json();
    if (typeof data.text === "function") {
      const text = await data.text();
      return text ? JSON.parse(text) : {};
    }
    if (typeof data === "string") return data ? JSON.parse(data) : {};
    return data;
  };
  const jsonRoute = (handler) => async (request2) => {
    try {
      return jsonResponse(success(await handler(await parseJsonBody(request2), request2)));
    } catch (error) {
      return jsonResponse(failure((error == null ? void 0 : error.message) || String(error), 500), 500);
    }
  };
  const normalizePath = (path = "") => {
    const raw = String(path || "").split("?")[0];
    const clean2 = decodeSafe(raw).replace(/\\/g, "/");
    if (!clean2) return "/";
    return clean2.startsWith("/") ? clean2 : `/${clean2}`;
  };
  const getPage = (path = "") => {
    var _a;
    return Math.max(1, parseInt(((_a = String(path || "").match(/[?&]page=(\d+)/)) == null ? void 0 : _a[1]) || "1", 10) || 1);
  };
  const parseNavPath = (path = "") => {
    const clean2 = normalizePath(path).replace(/^\/|\/$/g, "");
    if (!clean2 || clean2 === "root") return { type: "root" };
    const parts = clean2.split("/");
    if (parts[0] === "sites") {
      if (parts[1] && parts[2] === "cat" && parts[3]) return { type: "category", siteKey: parts[1], categoryId: parts[3] };
      if (parts[1]) return { type: "site", siteKey: parts[1] };
      return { type: "sites" };
    }
    if (parts[0] === "search" && parts[1]) return { type: "search", keyword: decodeSafe(parts[1]) };
    return { type: "root" };
  };
  const parsePlayPath = (fileId = "") => {
    const rawPath = normalizePath(fileId);
    const parts = rawPath.replace(/^\/|\/$/g, "").split("/").filter(Boolean);
    if (!parts.length) return { rawPath, itemId: "" };
    if (parts[0] === "sites" && parts[1] && parts[2] === "cat" && parts[3] && parts[4]) {
      return { rawPath, siteKey: parts[1], categoryId: parts[3], itemId: parts[4] };
    }
    if (parts[0] === "search" && parts.length >= 4) return { rawPath, siteKey: parts[parts.length - 2], itemId: parts[parts.length - 1] };
    if (parts[0] === "search" && parts.length >= 3) return { rawPath, itemId: parts[parts.length - 1] };
    return { rawPath, itemId: parts[parts.length - 1] || "" };
  };
  const getSites = (client, payload = {}) => loadAllSites(client, (payload == null ? void 0 : payload.config) || {});
  const findSite = async (client, payload, siteKey = "") => {
    const sites = await getSites(client, payload);
    return sites.find((site) => site.key === siteKey || site.name === siteKey) || null;
  };
  const ensureSite = async (client, payload) => {
    const sites = await getSites(client, payload);
    const homeKey = getHomeSiteKey((payload == null ? void 0 : payload.config) || {});
    const site = homeKey ? sites.find((item) => {
      var _a;
      return item.key === homeKey || ((_a = item.name) == null ? void 0 : _a.includes(homeKey));
    }) || sites[0] : sites[0];
    if (!site) throw new Error("No TVBox site available");
    return site;
  };
  const buildDirEntry = (id, name, path) => {
    const ts = now();
    return { id, name, path, size: 0, isDir: true, is_dir: true, modified: ts, created: ts };
  };
  const cacheItem = (item, fullPath) => {
    var _a;
    itemCache.set(fullPath, item);
    if (!itemCache.has(item.id)) itemCache.set(item.id, item);
    if ((_a = item.site) == null ? void 0 : _a.key) itemCache.set(`${item.site.key}|${item.id}`, item);
  };
  const convertItemsToFiles = (items = [], basePath = "") => {
    const ts = now();
    return items.map((item) => {
      const fullPath = `${basePath}/${item.id}`;
      cacheItem(item, fullPath);
      return {
        id: fullPath,
        name: item.title,
        path: fullPath,
        size: 0,
        isDir: false,
        is_dir: false,
        modified: ts,
        created: ts,
        thumbnail: normalizeAssetUrl(item.pic),
        _tvboxItem: item
      };
    });
  };
  const listDirectory = async (client, payload) => {
    const nav = parseNavPath((payload == null ? void 0 : payload.path) || "root");
    const page = getPage((payload == null ? void 0 : payload.path) || "");
    const sites = await getSites(client, payload);
    if (nav.type === "root") return [
      buildDirEntry("sites", `影视站点 (${sites.length})`, "/sites"),
      buildDirEntry("search", "搜索影视", "/search")
    ];
    if (nav.type === "sites") return sites.map((site) => {
      const siteKey = site.key || site.name;
      return buildDirEntry(`site-${siteKey}`, site.name || site.key, `/sites/${siteKey}`);
    });
    if (nav.type === "site") {
      const site = await findSite(client, payload, nav.siteKey);
      return site ? (await cmsHome(client, site)).map((cat) => buildDirEntry(`cat-${cat.id}`, cat.name, `/sites/${nav.siteKey}/cat/${cat.id}`)) : [];
    }
    if (nav.type === "category") {
      const site = await findSite(client, payload, nav.siteKey);
      return site ? convertItemsToFiles(await cmsListByType(client, site, nav.categoryId, page), `/sites/${nav.siteKey}/cat/${nav.categoryId}`) : [];
    }
    if (nav.type === "search") {
      const site = await ensureSite(client, payload);
      return convertItemsToFiles(await cmsSearch(client, site, nav.keyword), `/search/${encodeURIComponent(nav.keyword)}`);
    }
    return [];
  };
  const findCachedItem = (rawPath, itemId, siteKey) => itemCache.get(rawPath) || (siteKey ? itemCache.get(`${siteKey}|${itemId}`) : null) || itemCache.get(itemId) || null;
  const getDetail = async (client, site, itemId) => {
    const key = `${site.api || ""}|${itemId}`;
    const cached = detailCache.get(key);
    if (cached && cached.expiresAt > now()) return cached.value;
    const raw = await cmsDetailInfo(client, site, itemId);
    const detail = await enrichTvboxDetailWithDouban(client, (raw == null ? void 0 : raw.title) || "", raw);
    detailCache.set(key, { value: detail, expiresAt: now() + DETAIL_CACHE_TTL });
    return detail;
  };
  const resolveItem = async (client, payload, parsed) => {
    const cached = findCachedItem(parsed.rawPath, parsed.itemId, parsed.siteKey);
    if (cached) return cached;
    if (parsed.siteKey && parsed.categoryId) {
      const site = await findSite(client, payload, parsed.siteKey);
      if (!site) return null;
      const found = (await cmsListByType(client, site, parsed.categoryId, 1)).find((item) => item.id === parsed.itemId) || null;
      if (found) {
        const withSite = { ...found, site };
        cacheItem(withSite, parsed.rawPath);
        return withSite;
      }
    }
    return null;
  };
  const resolvePlayableContext = async (client, payload, fileId) => {
    const cacheKey = `${JSON.stringify((payload == null ? void 0 : payload.config) || {})}|${fileId}`;
    const cached = playableCache.get(cacheKey);
    if (cached && cached.expiresAt > now()) return cached.value;
    const parsed = parsePlayPath(fileId);
    if (!parsed.itemId) throw new Error("Invalid TVBox item path");
    const item = await resolveItem(client, payload, parsed);
    const site = (item == null ? void 0 : item.site) || await findSite(client, payload, parsed.siteKey) || await ensureSite(client, payload);
    const value = { detail: await getDetail(client, site, (item == null ? void 0 : item.id) || parsed.itemId) };
    playableCache.set(cacheKey, { value, expiresAt: now() + PLAYABLE_CACHE_TTL });
    return value;
  };
  const pickPlayableUrl = (detail = {}) => {
    var _a;
    const sources = sortTvboxSources(detail.sources || []);
    for (const source of sources) {
      const m3u8 = (source.episodes || []).find((ep) => /\.m3u8(\?|$)/i.test((ep == null ? void 0 : ep.url) || ""));
      if (m3u8 == null ? void 0 : m3u8.url) return m3u8.url;
    }
    for (const source of sources) {
      const first = (_a = source.episodes) == null ? void 0 : _a[0];
      if (first == null ? void 0 : first.url) return first.url;
    }
    return detail.url || "";
  };
  const getMediaType = (url = "") => /\.mpd([?#]|$)/i.test(url) ? "mpd" : /\.m3u8([?#]|$)/i.test(url) ? "m3u8" : "auto";
  const toMediaItem = async (client, payload, path, item = {}, detail = {}) => {
    var _a;
    const pic = pickFirst(item, "pic") || pickFirst(detail, "pic");
    const parsed = parsePlayPath(path);
    const site = item.site || await findSite(client, payload, parsed.siteKey) || await ensureSite(client, payload);
    const sources = sortTvboxSources(detail.sources || []);
    const title = pickFirst(detail, "title") || pickFirst(item, "title") || "未命名";
    const countries = Array.isArray(detail.countries) ? detail.countries : [];
    const languages = Array.isArray(detail.languages) ? detail.languages : (detail == null ? void 0 : detail.lang) ? [detail.lang] : [];
    const durations = Array.isArray(detail.durations) ? detail.durations : (detail == null ? void 0 : detail.duration) ? [detail.duration] : [];
    const genres = Array.isArray(detail.genres) ? detail.genres : [];
    const score = pickFirst(detail, "score") || ((_a = detail == null ? void 0 : detail.rating) == null ? void 0 : _a.value) || "";
    const meta = [
      score ? `豆瓣: ${score}` : "",
      pickFirst(detail, "year") || pickFirst(item, "year"),
      joinText(countries),
      (detail == null ? void 0 : detail.episodes_count) ? `${detail.episodes_count} 集` : "",
      pickFirst(detail, "remarks") || pickFirst(item, "remarks")
    ].filter(Boolean).join(" · ");
    return {
      id: `tvbox-${path}`,
      title,
      name: title,
      url: `${PROTOCOL}file/${path}`,
      originalUrl: `${PROTOCOL}file/${path}`,
      type: "video",
      source: SOURCE_ID,
      sourcePath: path,
      thumbnail: normalizeAssetUrl(pic),
      added: now(),
      size: 0,
      year: pickFirst(detail, "year") || pickFirst(item, "year"),
      area: pickFirst(detail, "area") || pickFirst(item, "area"),
      remarks: pickFirst(detail, "remarks") || pickFirst(item, "remarks"),
      genre: genres.length ? genres.join(" / ") : item.type_name || "",
      artist: meta,
      desc: pickFirst(detail, "summary", "content"),
      rating: detail.rating,
      score,
      countries,
      languages,
      durations,
      aka: Array.isArray(detail.aka) ? detail.aka : [],
      directors: Array.isArray(detail.directors) ? detail.directors : [],
      casts: Array.isArray(detail.casts) ? detail.casts : [],
      summary: pickFirst(detail, "summary", "content"),
      pubDate: pickFirst(detail, "pubdate"),
      episodesCount: Number(detail.episodes_count || 0),
      originalTitle: pickFirst(detail, "original_title"),
      sources,
      _episodes: { sources },
      site
    };
  };
  const createMediaItemsFromDirectory = async (client, payload) => {
    const path = (payload == null ? void 0 : payload.path) || "";
    const page = Math.max(1, Number((payload == null ? void 0 : payload.page) || 1));
    const files = await listDirectory(client, { ...payload, path: page > 1 ? `${path}${String(path).includes("?") ? "&" : "?"}page=${page}` : path });
    return Promise.all(files.map(async (file) => file.isDir ? {
      id: `tvbox-folder-${file.id}`,
      title: file.name,
      name: file.name,
      type: "folder",
      url: "#",
      originalUrl: `${PROTOCOL}${file.path}`,
      source: SOURCE_ID,
      sourcePath: file.path,
      is_dir: true,
      isDir: true,
      thumbnail: "",
      size: 0,
      added: file.created
    } : {
      ...await toMediaItem(client, payload, file.path, file._tvboxItem || { title: file.name, pic: file.thumbnail }, {}),
      id: `tvbox-${file.id}`,
      added: file.created
    }));
  };
  const createMediaItemFromPath = async (client, payload) => {
    var _a;
    const path = String((payload == null ? void 0 : payload.path) || "");
    const parsed = parsePlayPath(path);
    const item = await resolveItem(client, payload, parsed) || {
      id: parsed.itemId,
      title: parsed.itemId,
      site: await findSite(client, payload, parsed.siteKey) || await ensureSite(client, payload)
    };
    const detail = await getDetail(client, item.site, item.id || parsed.itemId);
    return { ...await toMediaItem(client, payload, path, item, detail), ...(payload == null ? void 0 : payload.timeParams) || {}, isLoop: ((_a = payload == null ? void 0 : payload.timeParams) == null ? void 0 : _a.endTime) !== void 0 };
  };
  const getQualities = async (client, payload) => {
    const { detail } = await resolvePlayableContext(client, payload, (payload == null ? void 0 : payload.path) || "");
    const sources = sortTvboxSources(detail.sources || []);
    const options = [];
    sources.forEach((source, i) => (source.episodes || []).forEach((ep, j) => {
      if (!(ep == null ? void 0 : ep.url)) return;
      options.push({
        default: i === 0 && j === 0,
        html: `${source.from || `线路${i + 1}`} - ${ep.name || `第${j + 1}集`}`,
        url: ep.url,
        extra: { type: getMediaType(ep.url), from: source.from || "" }
      });
    }));
    return options;
  };
  const resolvePlayback = async (client, payload) => {
    const { detail } = await resolvePlayableContext(client, payload, (payload == null ? void 0 : payload.path) || "");
    const url = pickPlayableUrl(detail);
    if (!url) throw new Error("Playback URL not found");
    return { url, qualities: await getQualities(client, payload), runtime: {} };
  };
  const searchAll = async (client, payload) => {
    const keyword = String((payload == null ? void 0 : payload.keyword) || "");
    const siteKey = String((payload == null ? void 0 : payload.siteKey) || "");
    const sites = await getSites(client, payload);
    if (!keyword.trim()) return [];
    const homeKey = getHomeSiteKey((payload == null ? void 0 : payload.config) || {});
    const homeSite = homeKey ? sites.find((site) => {
      var _a;
      return site.key === homeKey || ((_a = site.name) == null ? void 0 : _a.includes(homeKey));
    }) : null;
    const queue = siteKey ? sites.filter((site) => site.key === siteKey || site.name === siteKey) : (homeSite ? [homeSite, ...sites.filter((site) => site !== homeSite)] : sites).filter((site) => site.searchable !== 0).slice(0, 12);
    const groups = await Promise.all(queue.map(async (site) => {
      const items = await cmsSearch(client, site, keyword).catch(() => []);
      return items.map((item) => {
        const path = `/search/${encodeURIComponent(keyword)}/${site.key}/${item.id}`;
        const withSite = { ...item, site };
        cacheItem(withSite, path);
        return {
          id: `tvbox-search-${site.key}-${item.id}`,
          path,
          name: item.title,
          title: item.title,
          type: "video",
          url: `${PROTOCOL}file${path}`,
          originalUrl: `${PROTOCOL}file${path}`,
          source: SOURCE_ID,
          sourcePath: path,
          thumbnail: normalizeAssetUrl(item.pic),
          size: 0,
          added: now(),
          playCount: 0,
          currentTime: 0,
          orderIndex: 0,
          album: site.name,
          searchSource: site.name,
          remarks: item.remarks || "",
          year: item.year || "",
          genre: item.type_name || ""
        };
      });
    }));
    return groups.flat();
  };
  const searchSites = async (client, payload) => (await getSites(client, payload)).filter((site) => site.searchable !== 0).map((site) => ({ key: site.key, name: site.name || site.key }));
  const checkConnection = async (client, payload) => {
    const sites = await getSites(client, payload);
    return { connected: true, message: `Loaded ${sites.length} site(s)`, profile: { sitesCount: sites.length } };
  };
  const createTvboxHandlers = ({ client }) => ({
    "POST /api/tvbox/check": jsonRoute((payload) => checkConnection(client, payload)),
    "POST /api/tvbox/directory": jsonRoute((payload) => listDirectory(client, payload)),
    "POST /api/tvbox/items": jsonRoute((payload) => createMediaItemsFromDirectory(client, payload)),
    "POST /api/tvbox/media": jsonRoute((payload) => createMediaItemFromPath(client, payload)),
    "POST /api/tvbox/resolve": jsonRoute((payload) => resolvePlayback(client, payload)),
    "POST /api/tvbox/search": jsonRoute((payload) => searchAll(client, payload)),
    "POST /api/tvbox/search/sites": jsonRoute((payload) => searchSites(client, payload))
  });
  (function() {
    const handlers = {
      ...createBilibiliHandlers({ client: siyuan.client }),
      ...createDouyinHandlers({ client: siyuan.client }),
      ...createSocialVideoHandlers({ client: siyuan.client }),
      ...createTvboxHandlers({ client: siyuan.client })
    };
    const statusPayload = () => ({
      name: "siyuan-media-player",
      kernel: true,
      capabilities: ["bilibili.resolve", "bilibili.proxy", "bilibili.mpd", "douyin.resolve", "douyin.proxy", "social.resolve", "social.proxy", "tvbox.resolve"],
      routes: Object.keys(handlers).sort()
    });
    const route = createRouter({
      handlers,
      logger: siyuan.logger,
      statusPayload
    });
    siyuan.plugin.lifecycle.onload = async () => {
      await siyuan.rpc.bind("siyuan-media-player.status", async () => statusPayload(), "Return media player kernel runtime status.");
    };
    if ("onrunning" in siyuan.plugin.lifecycle) siyuan.plugin.lifecycle.onrunning = () => {
    };
    siyuan.plugin.lifecycle.onunload = async () => {
    };
    siyuan.server.private.http.handler = async (request2) => {
      return route(request2);
    };
  })();
})();
