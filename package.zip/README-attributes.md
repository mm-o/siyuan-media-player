# 思源媒体播放器 - 自定义属性功能

## 🎯 功能概述

为思源笔记媒体播放器添加了自定义属性功能，实现对媒体内容的精确标识和管理。采用**极限精简**、**简洁高效**、**优雅完美**的设计理念。

## 🏷️ 自定义属性类型

### 1. 时间戳 (media-timestamp)
```typescript
// 创建时间戳
await player.timestamp(playerInstance, mediaItem, config, i18n);
```
**属性**:
- `media-timestamp="true"` - 标识时间戳块
- `media-time="02:03"` - 具体时间格式

### 2. 循环片段 (media-loop)
```typescript
// 设置循环起点
const start = await player.loop(playerInstance, mediaItem, config, i18n, null);
// 创建循环片段
await player.loop(playerInstance, mediaItem, config, i18n, start);
```
**属性**:
- `media-loop="true"` - 标识循环片段块
- `media-start="01:30"` - 开始时间
- `media-end="02:45"` - 结束时间

### 3. 截图 (media-screenshot)
```typescript
// 纯截图
config.settings.screenshotWithTimestamp = false;
await player.screenshot(playerInstance, mediaItem, config, i18n);
```
**属性**:
- `media-screenshot="true"` - 标识纯截图块

### 4. 截图+时间戳 (media-mediacard)
```typescript
// 截图+时间戳
config.settings.screenshotWithTimestamp = true;
await player.screenshot(playerInstance, mediaItem, config, i18n);
```
**属性**:
- `media-mediacard="true"` - 标识截图+时间戳块
- `media-time="02:03"` - 截图时间

### 5. 媒体笔记 (media-note)
```typescript
// 创建媒体笔记
const docId = await mediaNotes.create(mediaItem, config, playerInstance, i18n, plugin);
```
**属性**:
- `media-note="true"` - 标识媒体笔记文档
- `type="MediaNote"` - 笔记类型
- `mediaurl-url="https://..."` - 媒体URL
- `website="B站"` - 来源网站

## 🌐 网站来源自动识别

直接使用播放时已解析的 `MediaItem.source` 字段：

| MediaItem.source | 网站标识 | 说明 |
|------------------|----------|------|
| "bilibili" | B站 | B站视频 |
| "standard" + youtube.com | YouTube | YouTube视频 |
| "openlist" | openlist | OpenList服务器 |
| "webdav" | webdav | WebDAV服务器 |
| "local" | 本地 | 本地文件 |

> 💡 **性能优化**: 复用已解析的来源信息，避免重复URL判断

## 🚀 快速开始

### 1. 导入模块
```typescript
import { player, mediaNotes } from './core/document';
import type { MediaItem } from './core/types';
```

### 2. 准备数据
```typescript
const mediaItem: MediaItem = {
    id: 'video-1',
    title: '测试视频',
    url: 'https://www.bilibili.com/video/BV1234567890',
    type: 'video',
    duration: '10:30',
    source: 'bilibili'  // 关键：使用已解析的来源信息
};

const config = {
    settings: {
        insertMode: 'insertBlock',
        linkFormat: '- [时间 字幕](链接)',
        screenshotWithTimestamp: true
    }
};
```

### 3. 使用功能
```typescript
// 创建时间戳
await player.timestamp(playerInstance, mediaItem, config);

// 创建循环片段
const start = await player.loop(playerInstance, mediaItem, config, null, null);
await player.loop(playerInstance, mediaItem, config, null, start);

// 创建截图
await player.screenshot(playerInstance, mediaItem, config);

// 创建媒体笔记
await mediaNotes.create(mediaItem, config, playerInstance);
```

## 🛠️ 技术实现

### 核心函数
```typescript
// 极限精简的属性设置函数
const setAttrs = async (blockId: string, type: string, extra?: Record<string, string>): Promise<void> => {
    const attrs = { [`media-${type}`]: 'true', ...extra };
    try { await api.setBlockAttrs(blockId, attrs); } catch {}
};

// 网站来源识别 - 直接使用已解析的source信息
const getWebsite = (item: MediaItem): string => {
    switch (item.source) {
        case 'bilibili': return 'B站';
        case 'openlist': return 'openlist';
        case 'local': return '本地';
        case 'webdav': return 'webdav';
        default: return item.url?.includes('youtube.com') ? 'YouTube' : '本地';
    }
};
```

### 特点
- ✨ **极限精简**: 最少代码实现最大功能
- ⚡ **简洁高效**: 统一的属性命名和设置方式  
- 🎨 **优雅完美**: 自动识别和设置，无需手动干预
- 🛡️ **容错处理**: 设置失败不影响主要功能
- 🚀 **性能优化**: 复用播放时已解析的来源信息

## 🔍 SQL查询示例

### 查询时间戳块
```sql
SELECT * FROM blocks WHERE id IN (
    SELECT block_id FROM attributes 
    WHERE name = 'media-timestamp' AND value = 'true'
);
```

### 查询媒体笔记
```sql
SELECT * FROM blocks WHERE id IN (
    SELECT block_id FROM attributes 
    WHERE name = 'type' AND value = 'MediaNote'
);
```

### 查询特定网站内容
```sql
SELECT * FROM blocks WHERE id IN (
    SELECT block_id FROM attributes 
    WHERE name = 'website' AND value = 'B站'
);
```

## 📁 文件结构

```
src/
├── core/
│   └── document.ts          # 核心功能实现
├── test-attributes.ts       # 测试文件
├── demo-attributes.ts       # 演示脚本
└── ...

docs/
├── custom-attributes.md     # 详细说明文档
└── ...

README-attributes.md         # 本文件
```

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个功能！

## 📄 许可证

遵循项目原有许可证。
