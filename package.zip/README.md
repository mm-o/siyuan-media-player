# [DOC 帮助文档 👈](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh)

# [ISSUE 反馈 交流](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-JcVadDDYzoViQNxltupcIrJxnSg)

# [CHANGELOG 更新日志](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-QBqHdeY0VoHRKYxW42ec1M7Anyh)

### v0.2.5 (2025.4.10)
1. Added Bilibili favorites direct import feature, allowing one-click addition of entire favorite folders to playlist
2. Added 4 playlist view modes (detailed view, simple view, grid view, and cover view) to suit different browsing preferences
3. Fixed timestamp and loop segment links for Bilibili multi-part videos, links now correctly jump to the corresponding part
4. Refactored playlist system, split into multiple functional modules for improved performance and user experience

# 打赏、鼓励、催更 🎉

<div>
<img src="https://745201.xyz/e43d21e2c04f47ddcc294cd62a64e6f.jpg" alt="alipay" width="300" />
</div>
<br>
<div>
<img src="https://745201.xyz/c42d51ea098d3a8687eb50012d1689e.jpg" alt="wechat" width="300" />
</div>

# [ACKNOWLEDGMENTS 鸣谢](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-PKecdG4eboPDjAxo4Apc0vuTnJb)