# [DOC 帮助文档 👈](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh)

# [ISSUE 反馈 交流](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-JcVadDDYzoViQNxltupcIrJxnSg)

# [CHANGELOG 更新日志](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-QBqHdeY0VoHRKYxW42ec1M7Anyh)

### v0.2.5 (2025.4.10)
1. 新增B站收藏夹直接导入功能，可一键添加整个收藏夹视频到播放列表
2. 新增4种播放列表视图模式（详细视图、简洁视图、网格视图和封面视图），满足不同浏览习惯
3. 修复B站视频分p生成时间戳和循环片段链接问题，现在链接可正确跳转到对应分p
4. 重构播放列表系统，拆分为多个功能模块，提升性能和用户体验

# 打赏、鼓励、催更 🎉

<div>
<img src="https://745201.xyz/e43d21e2c04f47ddcc294cd62a64e6f.jpg" alt="alipay" width="300" />
</div>
<br>
<div>
<img src="https://745201.xyz/c42d51ea098d3a8687eb50012d1689e.jpg" alt="wechat" width="300" />
</div>

# [ACKNOWLEDGMENTS 鸣谢](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-PKecdG4eboPDjAxo4Apc0vuTnJb)