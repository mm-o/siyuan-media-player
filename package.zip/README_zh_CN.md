<div class="sy__outline" style="max-width: 800px; margin: 0 auto;">
    <div style="text-align: center; padding: 2em; background: linear-gradient(135deg, #6366f1, #8b5cf6); border-radius: 12px;">
        <h1 style="color: white; margin: 0; font-size: 2.2em;">🎬 思源媒体播放器</h1>
        <div style="color: rgba(255,255,255,0.9); margin-top: 0.5em; font-size: 1.1em;">专业的思源笔记媒体播放插件，集成多平台播放、智能笔记管理与高效学习工具</div>
        <div style="margin-top: 1.5em; display: flex; justify-content: center; gap: 12px; flex-wrap: wrap;">
            <a href="https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh"
               style="padding: 8px 16px; background: rgba(255,255,255,0.2); color: white; border-radius: 6px; text-decoration: none; font-size: 0.9em;">📖 帮助文档</a>
            <a href="https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-JcVadDDYzoViQNxltupcIrJxnSg"
               style="padding: 8px 16px; background: rgba(255,255,255,0.2); color: white; border-radius: 6px; text-decoration: none; font-size: 0.9em;">💬 反馈交流</a>
            <a href="https://vcne5rvqxi9z.feishu.cn/wiki/FEDdw8o7ti1IPpkJLjXcNX7En6d"
               style="padding: 8px 16px; background: rgba(255,255,255,0.2); color: white; border-radius: 6px; text-decoration: none; font-size: 0.9em;">📋 更新日志</a>
            <a href="https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-PKecdG4eboPDjAxo4Apc0vuTnJb"
               style="padding: 8px 16px; background: rgba(255,255,255,0.2); color: white; border-radius: 6px; text-decoration: none; font-size: 0.9em;">👏 鸣谢</a>
        </div>
    </div>
    <div style="margin-top: 1.5em; padding: 1.5em; background: linear-gradient(135deg, #eef2ff, #e0e7ff); border: 1px solid #c7d2fe; border-radius: 8px; box-shadow: 0 4px 12px rgba(99,102,241,0.15);">
        <h2 style="color: #6366f1; margin: 0 0 1em; text-align: center; font-size: 1.3em;">🚀 核心功能</h2>
        <ul style="margin: 0; padding-left: 1.2em;">
            <li style="margin: 0.5em 0; padding: 10px 14px; background: white; border-radius: 8px; border-left: 4px solid #6366f1; box-shadow: 0 2px 4px rgba(99,102,241,0.08);">🎥 <strong>多平台播放</strong> - 本地媒体、B站视频、OpenList、WebDAV云存储统一播放</li>
            <li style="margin: 0.5em 0; padding: 10px 14px; background: white; border-radius: 8px; border-left: 4px solid #8b5cf6; box-shadow: 0 2px 4px rgba(139,92,246,0.08);">⏰ <strong>时间戳跳转</strong> - 精确时间戳链接，一键跳转到指定播放位置</li>
            <li style="margin: 0.5em 0; padding: 10px 14px; background: white; border-radius: 8px; border-left: 4px solid #06b6d4; box-shadow: 0 2px 4px rgba(6,182,212,0.08);">🔄 <strong>循环片段</strong> - 自定义循环播放片段，重点内容反复学习</li>
            <li style="margin: 0.5em 0; padding: 10px 14px; background: white; border-radius: 8px; border-left: 4px solid #10b981; box-shadow: 0 2px 4px rgba(16,185,129,0.08);">📔 <strong>媒体笔记</strong> - 截图、字幕、弹幕导出，完整的学习笔记生态</li>
            <li style="margin: 0.5em 0; padding: 10px 14px; background: white; border-radius: 8px; border-left: 4px solid #f59e0b; box-shadow: 0 2px 4px rgba(245,158,11,0.08);">🤖 <strong>媒体助手</strong> - 字幕列表、弹幕列表、AI媒体总结智能分析</li>
            <li style="margin: 0.5em 0; padding: 10px 14px; background: white; border-radius: 8px; border-left: 4px solid #ef4444; box-shadow: 0 2px 4px rgba(239,68,68,0.08);">📋 <strong>播放列表</strong> - 数据库驱动管理，标签分类、拖拽排序、多视图展示</li>
            <li style="margin: 0.5em 0; padding: 10px 14px; background: white; border-radius: 8px; border-left: 4px solid #6366f1; box-shadow: 0 2px 4px rgba(99,102,241,0.08);">⚙️ <strong>设置面板</strong> - 账号配置、播放器设置、通用选项一站式管理</li>
        </ul>
    </div>
    <div style="margin-top: 1.5em; padding: 1.5em; background: #fff9f2; border-left: 4px solid #ffc107; border-radius: 8px;">
        <h2 style="color: #ff9f00; margin: 0 0 1em;">🧧 打赏、鼓励、催更</h2>
        <p style="margin: 0.5em 0;">如果思源媒体播放器对你有帮助，欢迎给作者点个赞或打赏一杯咖啡，这将鼓励作者持续优化和开发更多实用功能：</p>
        <div style="margin: 1em 0; text-align: center; display: flex; justify-content: space-around; flex-wrap: wrap; gap: 20px;">
            <div style="text-align: center;">
                <img src="/plugins/siyuan-media-player/assets/images/alipay.jpg"
                     alt="支付宝付款码"
                     style="width: 280px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <p style="margin: 0.5em 0; color: #666;">支付宝</p>
            </div>
            <div style="text-align: center;">
                <img src="/plugins/siyuan-media-player/assets/images/wechat.jpg"
                     alt="微信付款码"
                     style="width: 280px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <p style="margin: 0.5em 0; color: #666;">微信</p>
            </div>
        </div>
    </div>
    <div style="margin-top: 1.5em; padding: 1.5em; background: #f0f8ff; border-left: 4px solid #4a90e2; border-radius: 8px;">
        <h2 style="color: #2c5aa0; margin: 0 0 1em; text-align: center; font-size: 1.3em;">🚀 近期更新</h2>

<h3 style="margin: 0 0 1em 0; color: #2c5aa0; font-size: 1.2em;">📦 v0.3.7 (2025.7.6)</h3>

<h4 style="margin: 1em 0 0.5em 0; color: #4a90e2; font-size: 1em;">🐛 缺陷修复</h4>
- **📊 播放列表数据库优化**: 修复数据库字段规范性问题，单选多选项具有正确颜色标识，自动创建画廊视图
- **🔄 拖拽排序修复**: 修复拖拽排序后播放列表无法加载的问题，确保多标签环境下数据完整性

<h4 style="margin: 1em 0 0.5em 0; color: #4a90e2; font-size: 1em;">🔧 开发重构</h4>
- **⚡ 代码极限精简**: 优化播放列表组件核心逻辑，提升代码简洁性和执行效率

<details style="margin-top: 1.5em;">
<summary style="color: #666; cursor: pointer; font-weight: 500;">📋 查看历史更新</summary>
<div style="margin-top: 1em; padding-top: 1em; border-top: 1px solid #e0e7ff;">

**0.3.6版本更新 (2025.7.5)：**

### 🆕 新增功能
- **☁️ WebDAV云存储支持**: 新增WebDAV云存储集成
  - 设置面板中的WebDAV服务器配置
  - 标签菜单中的"浏览WebDAV云盘"选项
  - 支持WebDAV服务器直接流式播放
  - WebDAV媒体的时间戳链接和循环片段支持
- **🎛️ 顶部快捷菜单**: 增加顶部紫色小电视图标，快速访问设置
- **🎨 专用图标**: 为OpenList和WebDAV服务添加专用SVG图标

### ✨ 功能改进
- **🖼️ 图片本地化**: 自动转换封面图和艺术家头像为本地资源
  - 提升加载速度和离线显示支持
- **📔 媒体笔记增强**: 新创建的文档自动在右侧标签页打开
- **🔄 循环功能增强**: 增加单项循环和列表循环设置的互斥功能
- **📝 术语优化**: 将"循环次数"更新为"片段循环次数"，"循环后暂停"更新为"片段循环后暂停"
- **📁 思源空间相对路径**: 思源空间媒体现在使用相对路径生成时间戳和循环片段链接
  - 与思源空间菜单项路径格式保持一致
  - 提升可移植性和工作空间独立性

### 🐛 缺陷修复
- **🔗 B站时间戳链接**: 修复时间戳链接生成使用播放地址而非标准链接的问题
- **📤 导出功能**: 修复字幕、弹幕、AI总结导出功能问题
- **📔 媒体笔记**: 修复文档创建失败问题
- **📸 截图功能**: 修复截图不包含时间戳选项失效的问题
- **🏷️ 播放列表标签菜单**: 修复右键菜单重命名功能点击后菜单不隐藏的问题
- **🔄 循环功能**:
  - 修复B站视频单项循环不工作的问题
  - 修复列表循环加载下一个媒体后暂停的问题
  - 增强B站分P视频系列支持
- **🎨 样式作用域**: 修复SCSS选择器影响思源笔记滚动条的问题

### 🔧 技术改进
- 统一核心模块代码结构，提升稳定性和性能
- 实现静音自动播放绕过策略，确保播放列表循环可靠性
- 统一所有媒体类型的循环机制

**0.3.5版本更新 (2025.7.2)：**

> ⚠️ **重要提醒：由于大幅重构，本次更新导致播放列表和设置配置不兼容！**  
> 📋 **请在更新前做好数据迁移备份，配置文件位于：`data\storage\petal\siyuan-media-player\config.json`**  
> 🔄 **更新后需要重新配置播放列表和相关设置**

- **📋 播放列表重构**: 优化播放列表组件结构和性能，提升大量媒体时的响应速度
- **⚙️ 设置组件重构**:
  - 移除复杂样式，简化为直观的开关项界面
  - 统一组件处理逻辑，大幅提升配置效率
  - 增加数据库avid和笔记本ID的实时显示
  - 移除保存和重置按钮，实现实时保存和单项重置
- **📚 数据库配置同步**: 播放列表配置自动同步到数据库，确保数据一致性
- **🎯 拖拽功能增强**:
  - 支持拖拽媒体项进行排序和跨标签移动
  - 支持拖拽播放列表标签重新排序
  - 删除传统排序按钮，统一使用拖拽操作
- **📷 截图功能修复**: 修复截图带时间戳功能，确保截图与时间戳正确关联
- **🏷️ 视觉标签优化**: 增加播放列表项来源和类型的可视化标签，界面更直观美观
- **👨‍💼 账号样式优化**: 改进B站账号显示样式，提升用户体验
- **💬 思源空间增强**: 完整浏览思源笔记工作空间文件系统，支持浏览和播放所有文件夹中的媒体文件
- **🔗 媒体笔记URL修复**: 修复B站媒体笔记中URL使用播放地址而非标准链接的问题
- **🧹 功能精简**: 移除内置脚本加载功能，建议使用思源笔记内置JS脚本功能
- **🔄 网盘重构**: 将AList云盘功能重构为OpenList，统一云存储接口，提升兼容性和稳定性
- **⚡ 代码优化**: 极限精简核心代码，清理冗余逻辑，减少插件体积
- **🎯 专注核心**: 专注于媒体播放和笔记集成功能，提升稳定性和性能

**0.3.4版本更新 (2025.5.26)：**
- **🎛️ 按钮布局**: 优化功能按钮位置，提升使用体验
- **🔄 图标更新**: 修改dock栏图标，提高可识别性
- **🔍 链接逻辑**: 重构媒体链接检查逻辑，支持本地媒体链接
- **🛠️ 问题修复**: 修复本地媒体时间戳链接无法正常工作的问题
- **✨ 细节优化**: 多项细节改进和功能优化

**0.3.3版本更新 (2025.5.18)：**
- **🚀 界面大改**: 移除顶部图标，通过dock栏按钮打开播放器
- **🎛️ 按钮布局**: 将功能按钮移动到顶部，可以通过开关隐藏
- **🔂 循环增强**: 增加单项循环和列表循环功能
- **⏸️ 暂停控制**: 增加循环后暂停功能
- **💬 弹幕列表**: 增加弹幕列表，可以便捷导出弹幕内容
- **👤 账号优化**: 优化账号显示方式
- **🔄 排序功能**: 新增播放列表排序功能，支持按默认、名称、时间和类型排序
- **📜 脚本加载**: 支持加载自定义JavaScript脚本，可通过设置界面管理脚本状态（初步）

**0.3.2版本更新 (2025.5.11)：**
- **🎨 界面统一**: 优化UI，统一助手、播放列表、设置面板风格
- **☁️ 网盘支持**: 增加AList网盘支持，扩展媒体来源
- **📂 文件选择**: 支持本地文件直接选择文件导入
- **📋 菜单优化**: 优化标签菜单，移除复杂的标签+右键逻辑
- **↔️ 面板调整**: 支持面板拖拽放大缩小，灵活调整界面
- **⏸️ 循环设置**: 增加循环播放后暂停设置选项
- **📝 插入方式**: 扩展插入文档的方式，提供更多选择
- **🔗 链接增强**: 扩展链接格式，支持一次插入时间戳和截图
- **📔 媒体笔记**: 增加创建媒体笔记功能，提供自定义模版，支持设置快捷键，可选择笔记本创建或在当前文档中插入
- **🎛️ 格式统一**: 统一自定义格式，增加恢复默认格式功能
- **🔄 打开方式**: 支持自定义播放器标签页打开方式（新标签、右侧标签、底部标签、新窗口）
- **💻 开发增强**: 完善开发者API，提供更丰富的接口和事件支持
- **✨ 更多优化**: 众多细节优化，等待你的探索

**0.3.1版本更新：**
- **💬 B站字幕控制**：支持通过字幕按钮在播放器界面显示或隐藏B站视频字幕
- **📜 字幕自动滚动**：媒体助手字幕列表现在会跟随播放进度自动滚动
- **🎨 界面优化**：改进媒体助手UI界面，提升用户体验
- **🛠️ 问题修复**：解决了文件路径中特殊字符导致的添加错误
- **📸 截图功能优化**：改进截图功能，支持直接复制图片到剪贴板
- **🔄 字幕处理统一**：统一字幕处理逻辑，提升播放器性能

**0.3.0版本更新：**
- **🎯 B站弹幕支持**：添加B站视频弹幕显示功能
- **✨ Pro功能引入**：新增可选的Pro版功能
- **🔖 B站收藏夹增强**：直接选择添加到播放列表
- **🧠 媒体助手功能**：字幕浏览和视频摘要功能
- **💬 字幕支持**：支持本地媒体和B站视频字幕
- **📑 视频摘要**：AI生成视频内容概要（目前仅支持B站视频）

</div>
</details>

    </div>
</div>

## � 功能概述

思源媒体播放器是一款功能强大的多媒体播放插件，帮助您在思源笔记中便捷地播放、管理和引用各类媒体资源。

### 🎥 视频播放

- **📁 本地视频支持**：播放本地视频文件，支持多种常见视频格式
- **🅱️ B站视频支持**：直接播放哔哩哔哩视频，无需离开思源笔记
- **💬 自动字幕识别**：自动检测并加载匹配的字幕文件
- **💭 弹幕支持**：显示B站视频弹幕，提供原生观看体验
- **🎛️ 多种播放控制**：时间跳转、音量调节、播放速度、全屏等功能

### 📋 播放列表管理

- **📚 多列表管理**：创建和管理多个播放列表，便于分类组织媒体
- **👁️ 视图模式切换**：支持详细视图、简洁视图、网格视图和封面视图
- **📥 批量导入**：一键导入B站收藏夹或本地文件夹到播放列表

### � 笔记集成功能

- **⏱️ 时间戳链接**：生成指向视频特定时间点的链接，插入到笔记中
- **🔄 循环片段**：创建循环播放特定片段的链接，便于重复学习
- **📸 视频截图**：捕获视频画面并直接插入到笔记中
- **📔 媒体笔记**：创建综合性媒体笔记，支持自定义模板
- **🖊️ 灵活插入选项**：提供多种插入方式（光标位置、块前/后、文档头/尾或剪贴板）

### ✨ 高级功能（Pro版）

- **🧠 媒体助手**：
  - 📜 字幕列表：便捷浏览和搜索视频字幕内容
  - 📊 视频摘要：AI生成的视频内容概要，快速了解视频要点
  - 📤 一键导出：将字幕和摘要内容导出到笔记中
- **🔖 标签拓展**：
  - � 本地文件夹：直接浏览和管理本地媒体文件
  - � B站收藏夹：无缝集成B站收藏内容
  - � 更多功能开发中...

## 📖 使用指南

<details>
<summary><b>点击展开使用指南</b></summary>

### 🎬 基础操作

<details>
<summary><b>播放本地视频</b></summary>

1. 点击播放器窗口的"添加媒体"按钮
2. 选择本地视频文件
3. 播放器会自动检测并加载同名字幕文件（如果存在）
4. 使用播放器控制栏控制播放
</details>

<details>
<summary><b>播放B站视频</b></summary>

1. 复制B站视频链接（支持标准链接和短链接）
2. 在播放器中点击"添加媒体"按钮
3. 粘贴链接并确认
4. 播放器会自动加载视频、字幕和弹幕
</details>

<details>
<summary><b>使用OpenList云盘</b></summary>

1. 在设置面板中配置OpenList服务器连接
2. 点击"添加媒体"并选择"添加OpenList云盘"
3. 浏览OpenList目录结构查找媒体文件
4. 选择要添加到播放列表的媒体
5. 播放器将直接从OpenList服务器流式播放内容
</details>

<details>
<summary><b>导入B站收藏夹</b></summary>

1. 登录B站账号（在设置面板中）
2. 在播放列表面板中选择"添加B站收藏夹"
3. 选择要导入的收藏夹
4. 确认导入，视频将批量添加到当前播放列表
</details>

<details>
<summary><b>管理B站账号</b></summary>

1. 在设置面板中找到B站账号部分
2. 点击登录按钮显示二维码
3. 使用B站手机APP扫描二维码登录
4. 登录后可访问和导入您的个人收藏夹
</details>

### 📝 笔记集成

<details>
<summary><b>创建时间戳和循环片段</b></summary>

1. 播放视频到需要标记的位置
2. 点击时间戳按钮创建时间戳，或点击循环片段按钮设置起点
3. 如创建循环片段，继续播放到结束位置再次点击循环片段按钮
4. 生成的链接会自动复制到剪贴板或插入到光标位置（根据设置）
</details>

<details>
<summary><b>创建媒体笔记</b></summary>

1. 播放您想要记录笔记的视频或音频
2. 点击控制栏中的"媒体笔记"按钮（或使用自定义快捷键）
3. 系统将根据您自定义的模板创建新笔记
4. 笔记中包含媒体信息，如标题、当前时间戳和缩略图
5. 根据设置，笔记将：
   - 插入到当前文档中（使用您设置的插入方式）
   - 或创建在您指定的笔记本中（可在设置中选择目标笔记本）
6. 您可以在设置中自定义笔记模板以适应您的工作流程
7. 可为媒体笔记功能指定快捷键，提高使用效率
</details>

### 🧠 高级功能

<details>
<summary><b>使用媒体助手（Pro版）</b></summary>

1. 在播放视频时点击控制栏中的媒体助手按钮
2. 在助手面板中浏览字幕列表或查看视频摘要
3. 点击字幕条目可跳转到对应时间点
4. 使用导出按钮将内容导出到笔记中
</details>

### ⌨️ 快捷键

<details>
<summary><b>播放器内置快捷键</b></summary>

- **空格键**：切换播放/暂停
- **方向键左/右**：视频快退/快进
- **方向键上/下**：增加/降低音量
</details>

<details>
<summary><b>自定义快捷键</b></summary>

您可以在思源笔记的设置中自定义以下功能的快捷键：

1. 打开思源设置 > 快捷键
2. 搜索"媒体播放器"或"siyuan-media-player"
3. 为以下功能设置自定义快捷键：
   - **⏱️ 创建时间戳**：生成当前播放时间的链接
   - **🔄 创建循环片段**：设置循环播放的起点和终点
   - **📸 截图**：捕获当前视频画面
   - **📔 创建媒体笔记**：为当前媒体创建笔记
   - **🧠 打开/关闭媒体助手**：显示或隐藏字幕和摘要面板（Pro版）
</details>
</details>

## ⚙️ 设置选项

<details>
<summary><b>点击展开设置选项</b></summary>

### 🛠️ 常规设置

- **🔊 音量**：设置默认播放音量
- **⏩ 播放速度**：设置默认播放速度
- **🔁 循环次数**：设置片段循环播放的次数
- **⏸️ 循环后暂停**：设置是否在循环播放结束后自动暂停
- **💬 显示字幕**：是否默认显示字幕
- **💭 启用弹幕**：是否默认显示弹幕

### 🎛️ 播放器设置

- **📺 播放器选择**：选择使用内置播放器、PotPlayer或浏览器
- **🔄 打开方式**：选择播放器标签页的打开方式：
  - **默认**：在新标签页中打开
  - **右侧**：在右侧标签页中打开
  - **底部**：在底部标签页中打开
  - **窗口**：在新窗口中打开
- **📌 插入方式**：选择内容插入方式：
  - **插入光标处**：在当前光标位置添加内容
  - **追加到块末尾**：将内容添加到当前块的末尾
  - **添加到块开头**：将内容添加到当前块的开头
  - **更新当前块**：替换当前块的内容
  - **插入到文档顶部**：将内容添加到文档的顶部
  - **插入到文档底部**：将内容添加到文档的底部
  - **复制到剪贴板**：仅复制到剪贴板而不插入文档
- **🔗 链接格式**：自定义生成的链接格式，支持添加表情符号和截图
- **📝 媒体笔记模板**：自定义创建媒体笔记的模板
- **📓 目标笔记本**：选择创建媒体笔记的目标笔记本
</details>

## ❓ 常见问题

<details>
<summary><b>视频无法播放</b></summary>

- 检查网络连接是否正常
- 对于B站视频，尝试刷新或重新添加链接
- 确认视频格式是否受支持
</details>

<details>
<summary><b>字幕不显示</b></summary>

- 确认字幕文件与视频文件同名且在同一目录下
- 检查字幕文件格式是否为.srt、.vtt或.ass
- 在设置中确认"显示字幕"选项已启用
</details>

<details>
<summary><b>弹幕不显示</b></summary>

- 确认"启用弹幕"选项已启用
- 只有B站视频支持弹幕功能
- 部分视频可能没有弹幕数据
</details>

<details>
<summary><b>导入收藏夹失败</b></summary>

- 确认已登录B站账号
- 检查网络连接
- 尝试重新登录账号
</details>

## 💡 高级技巧

<details>
<summary><b>点击展开高级技巧</b></summary>

### 🔗 自定义链接格式

在设置中，您可以自定义时间戳链接的显示格式。例如：

```
- [😄标题 时间 字幕](链接)  // 带有表情符号的链接
> 🕒 时间 | 标题 | 字幕     // 引用格式的链接
```

### 📝 自定义媒体笔记模板

您可以在设置中创建自己的媒体笔记模板，支持各种变量：

```
# 📽️ 标题的媒体笔记
- 📅 日 期：日期
- ⏱️ 时 长：时长
- 🎨 艺 术 家：艺术家
- 🔖 类 型：类型
- 🔗 链 接：[链接](链接)
- ![封面](封面)
- 📝 笔记内容：
```

可用的变量包括：
- 媒体标题、当前时间戳、艺术家名称、媒体URL、媒体时长、媒体缩略图、媒体类型、媒体ID、当前日期、当前日期和时间

### 🔄 列表排序功能

播放列表支持多种排序方式，点击播放列表顶部的排序按钮可切换不同排序模式：

- **默认排序**：按添加顺序排列
- **按名称排序**：按媒体标题字母顺序排列
- **按时间排序**：按添加时间排列，最新添加的在前面
- **按类型排序**：按媒体类型分组排列

排序时会保持置顶项目的位置，只对非置顶项目进行排序。

### ↔️ 面板调整

- 您可以通过拖动面板边缘来调整播放器面板大小
- 将鼠标悬停在面板边缘附近，直到光标变为调整大小光标
- 点击并拖动以调整面板大小
- 此功能适用于播放列表面板、设置面板和媒体助手面板
- 面板大小会在会话之间保持记忆

### 📚 多播放列表管理

- 创建主题相关的播放列表，如"学习资料"、"娱乐视频"等
- 使用置顶功能将常用列表固定在顶部
- 定期整理和清理不再需要的媒体内容

### 📥 批量处理技巧

- 使用本地文件夹导入功能一次添加多个视频
- 使用B站收藏夹导入快速添加系列视频
- 通过视图模式切换，在不同场景下高效浏览和管理媒体
</details>

## 💻 开发者API

<details>
<summary><b>点击展开开发者API</b></summary>

思源媒体播放器提供了丰富的API，供其他插件调用，实现更多自定义功能。

### 基本使用

```javascript
// 获取插件实例
const mp = window.siyuan.plugins.find(p => p.name === 'siyuan-media-player');

// 直接播放媒体
mp.api.playMedia('https://example.com/video.mp4', {
  title: '标题',        // 可选
  startTime: 30,       // 可选，开始秒数
  endTime: 60,         // 可选，结束秒数
  isLoop: true         // 可选，循环播放
});

// 添加到播放列表
mp.api.playMedia('https://example.com/music.mp3', {
  addToPlaylist: true,
  autoPlay: true       // 默认true
});
```

### 事件机制

```javascript
// 事件方式调用
window.dispatchEvent(new CustomEvent('directMediaPlay', { 
  detail: {id: `c-${Date.now()}`, title: '标题', url: '地址', type: 'video'}
}));

window.dispatchEvent(new CustomEvent('addMediaToPlaylist', { 
  detail: {url: '地址', autoPlay: true}
}));

// 注册事件监听
window.addEventListener('mediaPlayerStateChange', (e) => {
  const { playing, currentTime, duration } = e.detail;
  console.log(`播放状态: ${playing ? '播放中' : '已暂停'}, 时间: ${currentTime}/${duration}`);
});

window.addEventListener('mediaPlayerReady', (e) => {
  console.log('媒体播放器已就绪', e.detail);
});
```

### 扩展API

```javascript
// 高级控制
mp.api.getPlayer().then(player => {
  // 获取当前播放器实例
  console.log('当前媒体:', player.getCurrentMedia());
  
  // 控制播放
  player.pause();
  player.play();
  player.seek(120); // 跳转到2分钟位置
  
  // 设置音量和速度
  player.setVolume(0.8);
  player.setPlaybackRate(1.5);
});

// 播放列表管理
mp.api.getPlaylists().then(playlists => {
  console.log('所有播放列表:', playlists);
});

mp.api.getCurrentPlaylist().then(playlist => {
  console.log('当前播放列表:', playlist);
});
```
