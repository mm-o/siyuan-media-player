# [DOC 帮助文档 👈](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh)

# [ISSUE 反馈 交流](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-JcVadDDYzoViQNxltupcIrJxnSg)

# [CHANGELOG 更新日志](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-QBqHdeY0VoHRKYxW42ec1M7Anyh)

### v0.2.0 (2025.3.28)
- 新增国际化(i18n)支持
  - 完整支持中英文界面本地化
  - 根据系统设置动态切换语言
  - 切换语言时自动翻译播放列表名称

### v0.1.9 (2025.3.27)
- 新增本地文件夹批量导入媒体功能
- 新增播放列表清空功能
- 修复播放列表标签切换问题
- 修复/命令菜单错位问题

### v0.1.8 (2025.3.24)
- 增加B站DASH流支持
  - 解决音画不同步问题
  - 提升播放稳定性
- 优化链接处理
  - 修复时间戳和循环片段链接问题
  - 改进播放器标签页未打开时的链接点击行为
- 简化设置选项
  - 移除冗余设置项
  - 新增链接插入方式选择（光标位置或剪贴板）
- 修复已知问题并优化性能

# 打赏、鼓励、催更 🎉

<div>
<img src="https://745201.xyz/e43d21e2c04f47ddcc294cd62a64e6f.jpg" alt="alipay" width="300" />
</div>
<br>
<div>
<img src="https://745201.xyz/c42d51ea098d3a8687eb50012d1689e.jpg" alt="wechat" width="300" />
</div>

# [ACKNOWLEDGMENTS 鸣谢](https://vcne5rvqxi9z.feishu.cn/wiki/KZSMwZk7JiyzFtkgmPUc8rHxnVh#share-PKecdG4eboPDjAxo4Apc0vuTnJb)